//
//  PetDetailsNewViewController.swift
//  Zylo
//
//  Created by Sathish on 01/03/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit
import DropDown

enum Screen: Int {
    case Initial
    case Basic
    case Additional
    case Parent
    case Vet
    case Trainer
}

class PetDetailsNewViewController: BaseInnerViewController, dataProcessingDelegateProtocol {
    var petProfileId: Int = 0
    var vetId: Int = -1
    
    @IBOutlet weak var uploadPictureButton: NiceButton!
    @IBOutlet weak var segmentView: UIView!
    @IBOutlet weak var tabButtonOne: UIView!
    @IBOutlet weak var tabButtonTwo: UIView!
    @IBOutlet weak var tabButtonThree: UIView!
    @IBOutlet weak var tabButtonFour: UIView!
    @IBOutlet weak var tabButtonFive: UIView!
    @IBOutlet weak var basicInfoView: UIView!
    @IBOutlet weak var additionalInfoView: UIView!
    @IBOutlet weak var ownerInfoView: UIView!
    @IBOutlet weak var vetInfoView: UIView!
    @IBOutlet weak var trainerInfoView: UIView!
    @IBOutlet weak var nextAdditionalButton: UIButton!
    @IBOutlet weak var nextParentButton: UIButton!
    @IBOutlet weak var nextVetButton: UIButton!
    @IBOutlet weak var nextTrainerButton: UIButton!
    @IBOutlet weak var finishButton: UIButton!
    @IBOutlet weak var backBasicButton: UIButton!
    @IBOutlet weak var backAdditionalButton: UIButton!
    @IBOutlet weak var backParentButton: UIButton!
    @IBOutlet weak var backVetButton: UIButton!
    
    @IBOutlet weak var nameTextField: TextField!
    @IBOutlet weak var dogRadioButton: RadioButton!
    @IBOutlet weak var catRadioButton: RadioButton!
    @IBOutlet weak var maleRadioButton: RadioButton!
    @IBOutlet weak var femaleRadioButton: RadioButton!
    @IBOutlet weak var breedTextField: TextField!
    @IBOutlet weak var colorDropDownButton: NiceButton!
    @IBOutlet weak var adoptedSwitch: UISwitch!
    @IBOutlet weak var ownerNameTextField: TextField!
    @IBOutlet weak var ownerAddressTextField: TextField!
    @IBOutlet weak var ownerCityTextField: TextField!
    @IBOutlet weak var ownerStateTextField: TextField!
    @IBOutlet weak var ownerZipcodeTextField: TextField!
    @IBOutlet weak var ownerCountryTextField: TextField!
    @IBOutlet weak var contactNumberTextField: TextField!
    @IBOutlet weak var emailAddressTextField: TextField!
    @IBOutlet weak var vetFacilityTextField: TextField!
    @IBOutlet weak var vetAddressTextField: TextField!
    @IBOutlet weak var vetCityTextField: TextField!
    @IBOutlet weak var vetStateTextField: TextField!
    @IBOutlet weak var vetZipcodeTextField: TextField!
    @IBOutlet weak var vetCountryTextField: TextField!
    @IBOutlet weak var vetContactNumberTextField: TextField!
    @IBOutlet weak var vetDoctorNameTextField: TextField!
    @IBOutlet weak var petDOBTextField: DateTextField!
    @IBOutlet weak var petWeightTextField: TextField!
    @IBOutlet weak var petFoodTypeDropDownButton: UIButton!
    @IBOutlet weak var petFoodBrandTextField: TextField!
    @IBOutlet weak var petAllergiesTextField: TextField!
    @IBOutlet weak var petInsuranceSwitch: UISwitch!
    @IBOutlet weak var insuranceCompanyTextField: TextField!
    @IBOutlet weak var insurancePolicyNumberTextField: TextField!
    @IBOutlet weak var vaccineStatusSwitch: UISwitch!
    @IBOutlet weak var trainerNameTextField: TextField!
    @IBOutlet weak var trainerAddressTextField: TextField!
    @IBOutlet weak var trainerContactNumberTextField: TextField!
    @IBOutlet weak var setAsDefaultSwitch: UISwitch!
    @IBOutlet weak var microchipIdTextField: TextField!
    @IBOutlet weak var editView: UIView!
    
    var imagePicker: ImagePicker!
    var _petDetails: PetDetail? = nil
    var imageChanged: Bool = false
    
    let colorDropDown = DropDown()
    let petFoodTypeDropDown = DropDown()
    
    lazy var dropDowns: [DropDown] = {
        return [
            self.colorDropDown,
            self.petFoodTypeDropDown
        ]
    }()
    
    @IBAction func showColorDropDown(_ sender: AnyObject) {
        colorDropDown.show()
    }
    
    @IBAction func showPetFoodTypeDropDown(_ sender: AnyObject) {
        petFoodTypeDropDown.show()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(petProfileId > 0) {
            self.setScreenTitle(with: "Update Pet", color: .black)
        } else {
            self.setScreenTitle(with: "Add Pet", color: .black)
        }
        
        self.imageChanged = false
        self.imagePicker = ImagePicker(presentationController: self, delegate: self)
        
        adoptedSwitch.onTintColor = Constants().themeColor
        petInsuranceSwitch.onTintColor = Constants().themeColor
        
        setupColorDropDown()
        setupPetFoodTypeCountryDropDown()
        Utility.setupDropdownAppreance()
        
        dropDowns.forEach { $0.dismissMode = .onTap }
        dropDowns.forEach { $0.direction = .any }
        
        if(self.petProfileId <= 0) {
            self.ownerCountryTextField.text = "United States"
            self.vetCountryTextField.text = "United States"
        }
        
        self.setButtonCorner()
        self.showTab1Content()
        
        self.maleRadioButton.isSelected = true
        self.dogRadioButton.isSelected = true
        
        self.editView.bottomCornorRadius()
        if(self.petProfileId > 0) {
            self.uploadPictureButton.loadPetImage(petId: self.petProfileId)
            self.getPetDetailsFromServer(.Initial)
            Utility.setView(view: self.editView, hidden: false)
            let clickGesture = UITapGestureRecognizer(target: self, action:  #selector(self.editAction))
            self.editView.addGestureRecognizer(clickGesture)
            self.uploadPictureButton.setTitle("", for: .normal)
            self.uploadPictureButton.setImage(nil, for: .normal)
        } else {
            Utility.setView(view: self.editView, hidden: true)
            self.insuranceCompanyTextField.isEnabled = self.petInsuranceSwitch.isOn
            self.insurancePolicyNumberTextField.isEnabled = self.petInsuranceSwitch.isOn
            self.setPetDetails()
        }
        
        self.addBackButton()
        
        /*let leftRecognizer = UISwipeGestureRecognizer(target: self, action:
            #selector(swipeMade(_:)))
        leftRecognizer.direction = .left
        let rightRecognizer = UISwipeGestureRecognizer(target: self, action:
            #selector(swipeMade(_:)))
        rightRecognizer.direction = .right
        self.basicInfoView.addGestureRecognizer(leftRecognizer)
        self.basicInfoView.addGestureRecognizer(rightRecognizer)*/
    }
    
    func addBackButton() {
        let backButton = UIButton(type: .custom)
        backButton.setImage(UIImage(named: "back"), for: .normal) 
        backButton.setTitle(" Back", for: .normal)
        backButton.titleLabel?.font = UIFont.openSansBoldFontOfSize(size: 16.0)
        backButton.setTitleColor(Constants().headerButtonColor, for: .normal) // You can change the TitleColor
        backButton.addTarget(self, action: #selector(self.backAction(_:)), for: .touchUpInside)

        self.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: backButton)
    }

    @IBAction func backAction(_ sender: UIButton) {
        let basicCheck = self.checkChangesMade(.Basic)
        let additionalCheck = self.checkChangesMade(.Additional)
        let parentCheck = self.checkChangesMade(.Parent)
        let vetCheck = self.checkChangesMade(.Vet)
        let trainerCheck = self.checkChangesMade(.Trainer)
        if(basicCheck || additionalCheck || parentCheck || vetCheck || trainerCheck) {
            let dialogMessage = UIAlertController(title: "Confirm", message: "There are unsaved changes, do you want to save them?", preferredStyle: .alert)
            let yes = UIAlertAction(title: "Yes", style: .default, handler: { (action) -> Void in
                if(self.validateInputs()) {
                    if(self.petProfileId <= 0) {
                        self.createPetProfile(.Trainer)
                    } else {
                        self.updatePetProfile(.Trainer)
                    }
                } else {
                   self.showTab1Content()
               }
            })
            let no = UIAlertAction(title: "No", style: .cancel) { (action) -> Void in
                self.navigationController?.popViewController(animated: true)
            }
            dialogMessage.addAction(yes)
            dialogMessage.addAction(no)
            self.present(dialogMessage, animated: true, completion: nil)
        } else {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    /*@IBAction func swipeMade(_ sender: UISwipeGestureRecognizer) {
        if sender.direction == .left {
            self.showTab2Content()
        }
        if sender.direction == .right {
            print("right swipe made")
        }
    }*/
    
    @objc func editAction(_ sender: UIView) {
        self.imagePicker.present(from: sender)
    }
    
    @IBAction func saveButtonAction(_ sender: UIButton) {
        self.saveData(Screen.Trainer)
    }
    
    func saveData(_ step:Screen) {
        if(self.validateInputs()) {
            if(self.petProfileId <= 0) {
                self.createPetProfile(step)
            } else {
                if(self.checkChangesMade(step)) {
                    self.updatePetProfile(step)
                } else {
                    self.navigateScreen(step)
                }
            }
        } else {
            self.showTab1Content()
        }
    }
    
    func checkChangesMade(_ step:Screen) -> Bool {
        switch step {
        case .Basic:
            if(self.imageChanged) {
                return true
            }
            if(self._petDetails != nil) {
                if let petSummary = self._petDetails?.summaryData {
                    if (petSummary.isDeleted!) == false {
                        if(self.nameTextField.text != petSummary.profilePetName) {
                            return true
                        } else if(petSummary.profilePetType! == "Cat" && self.dogRadioButton.isSelected) {
                            return true
                        } else if(petSummary.profileSex! == "Male" && self.femaleRadioButton.isSelected) {
                            return true
                        } else if(self.breedTextField.text != petSummary.profilePetBreed) {
                            return true
                        } else if(self.colorDropDown.selectedValue != petSummary.profilePetColor) {
                            return true
                        } else if(self.microchipIdTextField.text != petSummary.profileMicrochipId!) {
                            return true
                        } else if(self.adoptedSwitch.isOn != petSummary.profilePetAdoptedInd) {
                            return true
                        } else if(self.setAsDefaultSwitch.isOn != petSummary.isDefault) {
                            return true
                        }
                        if let dynamicData = self._petDetails?.dynamicData {
                            if(self.petDOBTextField.getDate() != dynamicData.profilePetDob) {
                                return true
                            }
                            let weight: String = dynamicData.profilePetWeight != nil ? String(dynamicData.profilePetWeight!) : ""
                            if(self.petWeightTextField.text != weight) {
                                return true
                            }
                            if(self.petAllergiesTextField.text != dynamicData.profilePetAllergies!) {
                                return true
                            }
                        } else {
                            return true
                        }
                    } else {
                        return true
                    }
                } else {
                    return true
                }
            } else {
                return true
            }
            return false
        case .Additional:
            if(self._petDetails != nil) {
                if let petSummary = self._petDetails?.summaryData {
                    if (petSummary.isDeleted!) == false {
                        if let dynamicData = self._petDetails?.dynamicData {
                            if(self.petFoodTypeDropDown.selectedValue != dynamicData.profilePetFoodType!) {
                                return true
                            }
                            if(self.petFoodBrandTextField.text != dynamicData.profilePetFoodBrand!) {
                                return true
                            }
                            if(self.petInsuranceSwitch.isOn != dynamicData.profilePetInsuranceInd) {
                                return true
                            }
                            if(self.insuranceCompanyTextField.text != dynamicData.profilePetInsuranceCompany!) {
                                return true
                            }
                            if(self.insurancePolicyNumberTextField.text != dynamicData.profilePetInsurancePolicyNo!) {
                                return true
                            }
                            if(self.vaccineStatusSwitch.isOn != dynamicData.isVaccinated) {
                                return true
                            }
                        } else {
                            return true
                        }
                    } else {
                        return true
                    }
                } else {
                    return true
                }
            } else {
                return true
            }
            return false
        case .Parent:
            if(self._petDetails != nil) {
                if let petSummary = self._petDetails?.summaryData {
                    if (petSummary.isDeleted!) == false {
                        if let parentData = self._petDetails?.petParent {
                            if(self.ownerNameTextField.text != parentData.parentName) {
                                return true
                            }
                            if(self.ownerAddressTextField.text != parentData.parentStreetAddress) {
                                return true
                            }
                            if(self.ownerCityTextField.text != parentData.parentCity) {
                                return true
                            }
                            if(self.ownerStateTextField.text != parentData.parentState) {
                                return true
                            }
                            if(self.ownerZipcodeTextField.text != parentData.parentZipcode) {
                                return true
                            }
                            if(self.ownerCountryTextField.text != parentData.parentCountry) {
                                return true
                            }
                            if(self.emailAddressTextField.text != parentData.parentEmail) {
                                return true
                            }
                        } else {
                            return true
                        }
                        if let dynamicData = self._petDetails?.dynamicData {
                            if(self.contactNumberTextField.text != dynamicData.profilePetEmergencyContactNo) {
                                return true
                            }
                        } else {
                            return true
                        }
                    } else {
                        return true
                    }
                } else {
                    return true
                }
            } else {
                return true
            }
            return false
        case .Vet:
            if(self._petDetails != nil) {
                if let petSummary = self._petDetails?.summaryData {
                    if (petSummary.isDeleted!) == false {
                        if let vetData = self._petDetails?.vetData {
                            if(self.vetFacilityTextField.text != vetData.vetHospital) {
                                return true
                            }
                            if(self.vetAddressTextField.text != vetData.vetHospitalAddress) {
                                return true
                            }
                            if(self.vetCityTextField.text != vetData.vetCity) {
                                return true
                            }
                            if(self.vetStateTextField.text != vetData.vetState) {
                                return true
                            }
                            if(self.vetZipcodeTextField.text != vetData.vetZipcode) {
                                return true
                            }
                            if(self.vetCountryTextField.text != vetData.vetCountry) {
                                return true
                            }
                            if(self.vetContactNumberTextField.text != vetData.vetPocContactNumber) {
                                return true
                            }
                            if(self.vetDoctorNameTextField.text != vetData.vetPocName) {
                                return true
                            }
                        } else {
                            return true
                        }
                    } else {
                        return true
                    }
                } else {
                    return true
                }
            } else {
                return true
            }
            return false
        case .Trainer:
            if(self._petDetails != nil) {
                if let petSummary = self._petDetails?.summaryData {
                    if (petSummary.isDeleted!) == false {
                        if let trainerData = self._petDetails?.trainerData {
                            if(self.trainerNameTextField.text != trainerData.trainerName) {
                                return true
                            }
                            if(self.trainerAddressTextField.text != trainerData.trainerAddress) {
                                return true
                            }
                            if(self.trainerContactNumberTextField.text != trainerData.trainerPhoneNumber) {
                                return true
                            }
                        } else {
                            return true
                        }
                    } else {
                        return true
                    }
                } else {
                    return true
                }
            } else {
                return true
            }
            return false
        default:
            return false
        }
    }
    
    @IBAction func dogAction(_ sender: RadioButton) {
        if(sender.isSelected) {
            self.catRadioButton.isSelected = false
        }
    }
    
    @IBAction func catAction(_ sender: RadioButton) {
        if(sender.isSelected) {
            self.dogRadioButton.isSelected = false
        }
    }
    
    @IBAction func maleAction(_ sender: RadioButton) {
        if(sender.isSelected) {
            self.femaleRadioButton.isSelected = false
        }
    }
    
    @IBAction func femaleAction(_ sender: RadioButton) {
        if(sender.isSelected) {
            self.maleRadioButton.isSelected = false
        }
    }
    
    func setButtonCorner() {
        self.nextAdditionalButton.layer.masksToBounds = true
        self.nextAdditionalButton.layer.cornerRadius = 20
        self.nextParentButton.layer.masksToBounds = true
        self.nextParentButton.layer.cornerRadius = 20
        self.nextVetButton.layer.masksToBounds = true
        self.nextVetButton.layer.cornerRadius = 20
        self.nextTrainerButton.layer.masksToBounds = true
        self.nextTrainerButton.layer.cornerRadius = 20
        self.finishButton.layer.masksToBounds = true
        self.finishButton.layer.cornerRadius = 20
        
        self.backBasicButton.layer.masksToBounds = true
        self.backBasicButton.layer.cornerRadius = 20
        //self.backBasicButton.layer.opacity = 0.5
        self.backAdditionalButton.layer.masksToBounds = true
        self.backAdditionalButton.layer.cornerRadius = 20
        //self.backAdditionalButton.layer.opacity = 0.5
        self.backParentButton.layer.masksToBounds = true
        self.backParentButton.layer.cornerRadius = 20
        //self.backParentButton.layer.opacity = 0.5
        self.backVetButton.layer.masksToBounds = true
        self.backVetButton.layer.cornerRadius = 20
        //self.backVetButton.layer.opacity = 0.5
    }
    
    func setViewDefault() {
        self.basicInfoView.isHidden = true
        self.additionalInfoView.isHidden = true
        self.ownerInfoView.isHidden = true
        self.vetInfoView.isHidden = true
        self.trainerInfoView.isHidden = true
        self.tabButtonOne.backgroundColor = .lightGray
        self.tabButtonTwo.backgroundColor = .lightGray
        self.tabButtonThree.backgroundColor = .lightGray
        self.tabButtonFour.backgroundColor = .lightGray
        self.tabButtonFive.backgroundColor = .lightGray
        self.tabButtonOne.backgroundColor = Constants().themeColor
    }
    
    func setTabButtonDefault() {
        Utility.setView(view: self.basicInfoView, hidden: true)
        Utility.setView(view: self.additionalInfoView, hidden: true)
        Utility.setView(view: self.ownerInfoView, hidden: true)
        Utility.setView(view: self.vetInfoView, hidden: true)
        Utility.setView(view: self.trainerInfoView, hidden: true)
        self.tabButtonOne.backgroundColor = .lightGray
        self.tabButtonTwo.backgroundColor = .lightGray
        self.tabButtonThree.backgroundColor = .lightGray
        self.tabButtonFour.backgroundColor = .lightGray
        self.tabButtonFive.backgroundColor = .lightGray
        self.tabButtonOne.backgroundColor = Constants().themeColor
    }
    
    func showTab1Content() {
        setTabButtonDefault()
        Utility.setView(view: self.basicInfoView, hidden: false)
    }
    
    func showTab2Content() {
        setTabButtonDefault()
        self.tabButtonTwo.backgroundColor = Constants().themeColor
        Utility.setView(view: self.additionalInfoView, hidden: false)
    }
    
    func showTab3Content() {
        setTabButtonDefault()
        self.tabButtonTwo.backgroundColor = Constants().themeColor
        self.tabButtonThree.backgroundColor = Constants().themeColor
        Utility.setView(view: self.ownerInfoView, hidden: false)
    }
    
    func showTab4Content() {
        setTabButtonDefault()
        self.tabButtonTwo.backgroundColor = Constants().themeColor
        self.tabButtonThree.backgroundColor = Constants().themeColor
        self.tabButtonFour.backgroundColor = Constants().themeColor
        Utility.setView(view: self.vetInfoView, hidden: false)
    }
    
    func showTab5Content() {
        setTabButtonDefault()
        self.tabButtonTwo.backgroundColor = Constants().themeColor
        self.tabButtonThree.backgroundColor = Constants().themeColor
        self.tabButtonFour.backgroundColor = Constants().themeColor
        self.tabButtonFive.backgroundColor = Constants().themeColor
        Utility.setView(view: self.trainerInfoView, hidden: false)
    }
    
    @IBAction func tabButtonOneAction(_ sender: UIButton) {
        self.showTab1Content()
    }
    
    @IBAction func tabButtonTwoAction(_ sender: UIButton) {
        self.showTab2Content()
    }
    
    @IBAction func tabButtonThreeAction(_ sender: UIButton) {
        self.showTab3Content()
    }
    
    @IBAction func tabButtonFourAction(_ sender: UIButton) {
        self.showTab4Content()
    }
    
    @IBAction func tabButtonFiveAction(_ sender: UIButton) {
        self.showTab5Content()
    }
    
    @IBAction func basicNextAction(_ sender: UIButton) {
        self.saveData(.Basic)
    }
    
    @IBAction func additionalNextAction(_ sender: UIButton) {
        self.saveData(.Additional)
    }
    
    @IBAction func parentNextAction(_ sender: UIButton) {
        self.saveData(.Parent)
    }
    
    @IBAction func vetNextAction(_ sender: UIButton) {
        self.saveData(.Vet)
    }
    
    func validateInputs() -> Bool {
        var returnValue: Bool = true
        if(self.nameTextField.isEmpty()) {
            self.nameTextField.errorMessage = "Pet Name is required"
            returnValue = false
        } else {
            self.nameTextField.errorMessage = ""
        }
        if(self.breedTextField.isEmpty()) {
            self.breedTextField.errorMessage = "Pet Breed is required"
            returnValue = false
        } else {
            self.breedTextField.errorMessage = ""
        }
        if(self.colorDropDown.selectedValue.isEmpty) {
            self.colorDropDownButton.errorMessage = "Pet Color is required"
            returnValue = false
        } else {
            self.colorDropDownButton.errorMessage = ""
        }
        return returnValue
    }
    
    func getParamValues() -> NSDictionary {
        let summaryData: [String: Any] = ["profile_pet_type":(self.dogRadioButton.isSelected ? "Dog" : "Cat"), "profile_pet_name":self.nameTextField.text!, "profile_pet_breed":self.breedTextField.text!, "profile_pet_color":self.colorDropDown.selectedValue, "profile_microchip_id":self.microchipIdTextField.text!, "profile_sex":(self.maleRadioButton.isSelected ? "Male" : "Female"), "profile_pet_adopted_ind":self.adoptedSwitch.isOn, "is_default":self.setAsDefaultSwitch.isOn]
        let vetData: [String: Any] = ["vet_id":self.vetId, "vet_hospital":self.vetFacilityTextField.text!, "vet_poc_name": self.vetDoctorNameTextField.text!, "vet_poc_contact_number":self.vetContactNumberTextField.text!, "vet_hospital_address":self.vetAddressTextField.text!, "vet_city":self.vetCityTextField.text!, "vet_state":self.vetStateTextField.text!, "vet_zipcode":self.vetZipcodeTextField.text!, "vet_country":self.vetCountryTextField.text!]
        let trainerData: [String: Any] = ["trainer_name":self.trainerNameTextField.text!, "trainer_phone_number":self.trainerContactNumberTextField.text!, "trainer_address":self.trainerAddressTextField.text!]
        let parentData: [String: Any] = ["parent_name":self.ownerNameTextField.text!, "parent_phone_number":self.contactNumberTextField.text!, "parent_street_address":self.ownerAddressTextField.text!, "parent_city":self.ownerCityTextField.text!, "parent_state":self.ownerStateTextField.text!, "parent_zipcode":self.ownerZipcodeTextField.text!, "parent_country":self.ownerCountryTextField.text!, "parent_email":self.emailAddressTextField.text!]
        let dynamicData: [String:Any] = ["profile_pet_dob":self.petDOBTextField.getDate(), "profile_pet_weight":self.petWeightTextField.text!, "profile_pet_emergency_contact_no":self.contactNumberTextField.text!, "profile_pet_allergies":self.petAllergiesTextField.text!, "profile_pet_food_type":self.petFoodTypeDropDown.selectedValue, "profile_pet_food_brand":self.petFoodBrandTextField.text!, "is_vaccinated":self.vaccineStatusSwitch.isOn, "profile_pet_insurance_ind":self.petInsuranceSwitch.isOn, "profile_pet_insurance_company":self.insuranceCompanyTextField.text!, "profile_pet_insurance_policy_no":self.insurancePolicyNumberTextField.text!]
        
        let data:[String:Any] = ["summary":summaryData, "vet_data":vetData, "dynamic":dynamicData, "trainer_data":trainerData, "parent_data":parentData]
        
        if(self.imageChanged) {
            var base64String = ""
            if(self.uploadPictureButton.backgroundImage(for: .normal) != nil) {
                base64String = Utility.convertImageToBase64String(image: self.uploadPictureButton.backgroundImage(for: .normal)!)
            }
            if(!base64String.isEmpty) {
                base64String = "data:image/png;base64," + base64String
            }
            
            let postData:[String:Any] = ["data":data, "image_data":base64String]
                
            return postData as NSDictionary
        } else {
            let postData:[String:Any] = ["data":data]
                
            return postData as NSDictionary
        }
    }
    
    func createPetProfile(_ step:Screen) {
        self.showActivityIndicator()
        PetProfileService.CreatePet(postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let petData = try? decoder.decode(CreatePet.self, from: data) else { return }
            if let profileId = petData.profileId {
                if(profileId > 0) {
                    self.petProfileId = profileId
                    self.hideActivityIndicator()
                    self.imageChanged = false
                    self.setPetDetails()
                    self.navigateScreen(step)
                } else {
                   self.showErrorMessage(message: petData.message!)
               }
            } else {
                self.showErrorMessage(message: "Error in creating pet profile. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func setPetDetails() {
        if(self._petDetails == nil) {
            self._petDetails = PetDetail()
            self._petDetails?.summaryData = PetProfile()
            self._petDetails?.dynamicData = dynamicData()
            self._petDetails?.petParent = petParentData()
            self._petDetails?.vetData = vetData()
            self._petDetails?.trainerData = trainerData()
        }
        self._petDetails?.summaryData?.profileId = self.petProfileId
        self._petDetails?.summaryData?.isDeleted = false
        self._petDetails?.summaryData?.profilePetName = self.nameTextField.text
        self._petDetails?.summaryData?.profilePetType = (self.catRadioButton.isSelected ? "Cat" : "Dog")
        self._petDetails?.summaryData?.profilePetBreed = self.breedTextField.text
        self._petDetails?.summaryData?.profilePetColor = self.colorDropDown.selectedValue
        self._petDetails?.summaryData?.profilePetAdoptedInd = self.adoptedSwitch.isOn
        self._petDetails?.summaryData?.isDefault = self.setAsDefaultSwitch.isOn
        self._petDetails?.summaryData?.profileMicrochipId = self.microchipIdTextField.text
        self._petDetails?.summaryData?.profileSex = (self.femaleRadioButton.isSelected ? "Female" : "Male")
        
        self._petDetails?.dynamicData?.profilePetDob = self.petDOBTextField.getDate()
        self._petDetails?.dynamicData?.profilePetWeight = Int(self.petWeightTextField.text!)
        self._petDetails?.dynamicData?.profilePetAllergies = self.petAllergiesTextField.text
        self._petDetails?.dynamicData?.profilePetFoodType = self.petFoodTypeDropDown.selectedValue
        self._petDetails?.dynamicData?.profilePetFoodBrand = self.petFoodBrandTextField.text
        self._petDetails?.dynamicData?.profilePetInsuranceInd = self.petInsuranceSwitch.isOn
        self._petDetails?.dynamicData?.profilePetInsuranceCompany = self.insuranceCompanyTextField.text
        self._petDetails?.dynamicData?.profilePetInsurancePolicyNo = self.insurancePolicyNumberTextField.text
        self._petDetails?.dynamicData?.isVaccinated = self.vaccineStatusSwitch.isOn
        self._petDetails?.dynamicData?.profilePetEmergencyContactNo = self.contactNumberTextField.text
        
        self._petDetails?.petParent?.parentName = self.ownerNameTextField.text
        self._petDetails?.petParent?.parentStreetAddress = self.ownerAddressTextField.text
        self._petDetails?.petParent?.parentCity = self.ownerCityTextField.text
        self._petDetails?.petParent?.parentState = self.ownerStateTextField.text
        self._petDetails?.petParent?.parentZipcode = self.ownerZipcodeTextField.text
        self._petDetails?.petParent?.parentCountry = self.ownerCountryTextField.text
        self._petDetails?.petParent?.parentEmail = self.emailAddressTextField.text
        
        self._petDetails?.vetData?.vetHospital = self.vetFacilityTextField.text
        self._petDetails?.vetData?.vetHospitalAddress = self.vetAddressTextField.text
        self._petDetails?.vetData?.vetCity = self.vetCityTextField.text
        self._petDetails?.vetData?.vetState = self.vetStateTextField.text
        self._petDetails?.vetData?.vetZipcode = self.vetZipcodeTextField.text
        self._petDetails?.vetData?.vetCountry = self.vetCountryTextField.text
        self._petDetails?.vetData?.vetPocContactNumber = self.vetContactNumberTextField.text
        self._petDetails?.vetData?.vetPocName = self.vetDoctorNameTextField.text
        
        self._petDetails?.trainerData?.trainerName = self.trainerNameTextField.text
        self._petDetails?.trainerData?.trainerAddress = self.trainerAddressTextField.text
        self._petDetails?.trainerData?.trainerPhoneNumber = self.trainerContactNumberTextField.text
    }
    
    func navigateScreen(_ step:Screen) {
        self.uploadPictureButton.loadPetImage(petId: self.petProfileId)
        Utility.setView(view: self.editView, hidden: false)
        let clickGesture = UITapGestureRecognizer(target: self, action:  #selector(self.editAction))
        self.editView.addGestureRecognizer(clickGesture)
        self.uploadPictureButton.setTitle("", for: .normal)
        self.uploadPictureButton.setImage(nil, for: .normal)
        switch step {
        case .Initial:
            self.showTab1Content()
        case .Basic:
            self.showTab2Content()
        case .Additional:
            self.showTab3Content()
        case .Parent:
            self.showTab4Content()
        case .Vet:
            self.showTab5Content()
        case .Trainer:
            self.navigationController?.popViewController(animated: true)
            self.showSuccessMessage(message: "Pet profile details saved successfully")
        }
    }
    
    func updatePetProfile(_ step:Screen) {
        self.showActivityIndicator()
        PetProfileService.UpdatePet(petId: self.petProfileId, postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let petData = try? decoder.decode(UpdatePet.self, from: data) else { return }
            if let status = petData.status {
                if(status == 200) {
                    self.uploadPictureButton.removePetImageFromCache(petId: self.petProfileId)
                    self.hideActivityIndicator()
                    self.imageChanged = false
                    self.setPetDetails()
                    self.navigateScreen(step)
                } else {
                    self.showErrorMessage(message: petData.message!)
                }
            } else {
                self.showErrorMessage(message: "Error in updating pet profile. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func getPetDetailsFromServer(_ step: Screen) {
        if(self.petProfileId > 0) {
            self.showActivityIndicator()
            PetProfileService.getPetProfile(petId: self.petProfileId, onSuccess: {(data) in
                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase
                guard let petDetailData = try? decoder.decode(PetDetailData.self, from: data) else { return }
                if let petDetail = petDetailData.data {
                    self._petDetails = petDetail
                    self.bindPetDetails()
                } else {
                    self.showErrorMessage(message: "Error in getting pet details data. Please try again later.")
                }
                self.hideActivityIndicator()
                self.navigateScreen(step)
            }, onFailure: {_ in
                self.hideActivityIndicator()
            })
        }
    }
    
    func bindPetDetails() {
        if(self._petDetails != nil){
            if let petSummary = self._petDetails?.summaryData {
                if (petSummary.isDeleted!) == false {
                    self.nameTextField.text = petSummary.profilePetName
                    if(petSummary.profilePetType! == "Cat") {
                        self.catRadioButton.isSelected = true
                    }
                    self.breedTextField.text = petSummary.profilePetBreed
                    self.colorDropDown.setSelectedItem(list: Constants().petColorList, value: petSummary.profilePetColor!)
                    self.adoptedSwitch.isOn = petSummary.profilePetAdoptedInd!
                    self.setAsDefaultSwitch.isOn = petSummary.isDefault!
                    if(petSummary.profileMicrochipId != nil) {
                        self.microchipIdTextField.text = petSummary.profileMicrochipId!
                    }
                    if(petSummary.profileSex != nil) {
                        if(petSummary.profileSex! == "Female") {
                            self.femaleRadioButton.isSelected = true
                        }
                    }
                    
                    if let dynamicData = self._petDetails?.dynamicData {
                        if let petDOB = dynamicData.profilePetDob {
                            let DOB = Utility.getDateFromString(dateString: petDOB)
                            self.petDOBTextField.selectedDate = DOB
                        }
                        self.petWeightTextField.text = String(dynamicData.profilePetWeight!)
                        self.petAllergiesTextField.text = dynamicData.profilePetAllergies!
                        self.petFoodTypeDropDown.setSelectedItem(list: Constants().petFoodTypeList, value: dynamicData.profilePetFoodType!)
                        self.petFoodBrandTextField.text = dynamicData.profilePetFoodBrand
                        self.petInsuranceSwitch.isOn = dynamicData.profilePetInsuranceInd!
                        self.insuranceCompanyTextField.text = dynamicData.profilePetInsuranceCompany
                        self.insurancePolicyNumberTextField.text = dynamicData.profilePetInsurancePolicyNo
                        self.vaccineStatusSwitch.isOn = dynamicData.isVaccinated!
                        self.contactNumberTextField.text = dynamicData.profilePetEmergencyContactNo
                    }
                    
                    if let parentData = self._petDetails?.petParent {
                        self.ownerNameTextField.text = parentData.parentName
                        self.ownerAddressTextField.text = parentData.parentStreetAddress
                        self.ownerCityTextField.text = parentData.parentCity
                        self.ownerStateTextField.text = parentData.parentState
                        self.ownerZipcodeTextField.text = parentData.parentZipcode
                        self.ownerCountryTextField.text = parentData.parentCountry
                        self.emailAddressTextField.text = parentData.parentEmail
                    }
                    
                    if let vetData = self._petDetails?.vetData {
                        self.vetId = vetData.vetId!
                        self.vetFacilityTextField.text = vetData.vetHospital
                        self.vetAddressTextField.text = vetData.vetHospitalAddress
                        self.vetCityTextField.text = vetData.vetCity
                        self.vetStateTextField.text = vetData.vetState
                        self.vetZipcodeTextField.text = vetData.vetZipcode
                        self.vetCountryTextField.text = vetData.vetCountry
                        self.vetContactNumberTextField.text = vetData.vetPocContactNumber
                        self.vetDoctorNameTextField.text = vetData.vetPocName
                    }
                    
                    if let trainerData = self._petDetails?.trainerData {
                        self.trainerNameTextField.text = trainerData.trainerName
                        self.trainerAddressTextField.text = trainerData.trainerAddress
                        self.trainerContactNumberTextField.text = trainerData.trainerPhoneNumber
                    }
                }
            }
        }
        self.insuranceCompanyTextField.isEnabled = self.petInsuranceSwitch.isOn
        self.insurancePolicyNumberTextField.isEnabled = self.petInsuranceSwitch.isOn
    }
    
    // Delegate Method
    func processSelectedData(_ data: Search, type: String) {
        if(type == Constants().vetFacility) {
            self.vetId = data.id
            self.vetFacilityTextField.text = data.name
            self.vetAddressTextField.text = data.address
            self.vetCityTextField.text = data.city
            self.vetStateTextField.text = data.state
            self.vetZipcodeTextField.text = data.zipcode
            self.vetCountryTextField.text = data.country
            self.vetContactNumberTextField.text = data.phoneNumber
            self.vetDoctorNameTextField.text = data.ContactName
        } else if(type == Constants().petDogBreed || type == Constants().petCatBreed) {
            self.breedTextField.text = data.name
        } else if(type == Constants().petParentCountry) {
            self.ownerCountryTextField.text = data.name
        } else if(type == Constants().vetCountry) {
            self.vetCountryTextField.text = data.name
        }
    }
    
    func setupColorDropDown() {
        colorDropDown.anchorView = colorDropDownButton
        colorDropDown.bottomOffset = CGPoint(x: 0, y: colorDropDownButton.bounds.height)
        colorDropDown.dataSource = Constants().petColorList
        colorDropDown.selectionAction = { [weak self] (index, item) in
            self?.colorDropDownButton.setTitle(item, for: .normal)
        }
    }
    
    func setupPetFoodTypeCountryDropDown() {
        petFoodTypeDropDown.anchorView = petFoodTypeDropDownButton
        petFoodTypeDropDown.bottomOffset = CGPoint(x: 0, y: petFoodTypeDropDownButton.bounds.height)
        petFoodTypeDropDown.dataSource = Constants().petFoodTypeList
        petFoodTypeDropDown.selectionAction = { [weak self] (index, item) in
            self?.petFoodTypeDropDownButton.setTitle(item, for: .normal)
        }
    }
    
    @IBAction func showImagePicker(_ sender: UIButton) {
        self.imagePicker.present(from: sender)
    }
    
    @IBAction func searchVetFacility(_ sender: UIButton) {
        self.resignFirstResponder()
        let vc : PopupViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "PopUp") as! PopupViewController
        vc.delegate = self
        vc.type = Constants().vetFacility
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func searchPetBreed(_ sender: UIButton) {
        self.resignFirstResponder()
        let vc : PopupViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "PopUp") as! PopupViewController
        vc.delegate = self
        if(self.catRadioButton.isSelected) {
            vc.type = Constants().petCatBreed
        } else {
            vc.type = Constants().petDogBreed
        }
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func searchOwnerCountry(_ sender: UIButton) {
        self.resignFirstResponder()
        let vc : PopupViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "PopUp") as! PopupViewController
        vc.delegate = self
        vc.type = Constants().petParentCountry
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func searchVetCountry(_ sender: UIButton) {
        self.resignFirstResponder()
        let vc : PopupViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "PopUp") as! PopupViewController
        vc.delegate = self
        vc.type = Constants().vetCountry
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func enableInsuranceAction(_ sender: UISwitch) {
        //sender.isOn
        self.insuranceCompanyTextField.isEnabled = sender.isOn
        self.insurancePolicyNumberTextField.isEnabled = sender.isOn
    }
        
    // this method will be called from base class
    override func bindLocation() {
        self.ownerAddressTextField.text = self.street
        self.ownerCityTextField.text = self.city
        self.ownerStateTextField.text = self.state
        self.ownerCountryTextField.text = self.country
        self.ownerZipcodeTextField.text = self.zipcode
        self.hideActivityIndicator()
    }
}

extension PetDetailsNewViewController: ImagePickerDelegate {
    func didSelect(image: UIImage?) {
        if(image != nil) {
            self.uploadPictureButton.setBackgroundImage(image, for: .normal)
            let clickGesture = UITapGestureRecognizer(target: self, action:  #selector(self.editAction))
            self.editView.addGestureRecognizer(clickGesture)
            self.uploadPictureButton.setTitle("", for: .normal)
            self.uploadPictureButton.setImage(nil, for: .normal)
            Utility.setView(view: self.editView, hidden: false)
            self.imageChanged = true
        }
    }
}
