//
//  VaccineActivityListViewController.swift
//  Zylo
//
//  Created by Sathish on 21/07/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class VaccineActivityListViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var infoView: UIView!
    
    var vacList: [activityInformation] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setScreenTitle(with: "Vaccine Administration")
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.separatorColor = .clear
        self.tableView.backgroundColor = UIColor.clear
        self.tableView.estimatedRowHeight = 146
        
        self.infoView.backgroundColor = .white
        Utility.setView(view: self.infoView, hidden: true)
        Utility.setRightNavigationButton(target: self, image: UIImage(named: "add")!, action: #selector(self.addButtonAction))
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.loadList), name: NSNotification.Name(rawValue: Constants().reloadActivityDetails), object: nil)
        
        self.loadVaccineAdministrationList()
    }
    
    @objc func addButtonAction() {
        self.LoadActivity(activityId: 0)
    }
    
    @objc func loadList(notification: NSNotification){
        //load data here
        self.loadVaccineAdministrationList()
    }
    
    func loadVaccineAdministrationList() {
        self.vacList = []
        self.getVaccineAdministrationLog()
    }
    
    func getVaccineAdministrationLog() {
        self.showActivityIndicator()
        VaccineService.getPetVaccineActivity(petId: Utility.getDefaultPetId(), activityId: 0, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let vacData = try? decoder.decode(vaccineActivityList.self, from: data) else { self.hideActivityIndicator(); return }
            if let vacLst = vacData.data {
                var actId: [Int] = []
                for vac in vacLst {
                    if(vac.isDeleted != nil && vac.isDeleted! == false) {
                        if(!actId.contains(vac.activityId!)) {
                            actId.append(vac.activityId!)
                            self.vacList.append(vac)
                        }
                    }
                }
                
                self.tableView.reloadData()
            } else if vacData.status != 200 {
                self.showErrorMessage(message: "Error in getting vaccine administration log. Please try again later.")
            }
            if(self.vacList.count <= 0) {
                Utility.setView(view: self.infoView, hidden: false)
               // self.tableView.reloadData()
            } else {
                Utility.setView(view: self.infoView, hidden: true)
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }

    public func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }

    public func tableView(_ tableView: UITableView, numberOfRowsInSection sectionIndex: Int) -> Int {
        if(sectionIndex == 0){
            if(vacList.count > 0){
                return 1
            }else{
                return 0
            }
        }else{
            return (vacList.count-1)
        }
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if(section == 0){
            return "Recent"
        }else{
            return "Past"
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        view.tintColor = UIColor.red
        let header = view as! UITableViewHeaderFooterView
        header.textLabel?.textColor = .lightGray
        header.textLabel?.font = UIFont.openSansBoldFontOfSize(size: 16)
    }

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: VaccineAdministrativeListTableViewCell = tableView.dequeueReusableCell(withIdentifier: "ActivityCell", for: indexPath) as! VaccineAdministrativeListTableViewCell
        
        var vac:activityInformation = activityInformation()
        
        if(indexPath.section == 0){
            vac = vacList[indexPath.row] as activityInformation
        }else{
            vac = vacList[indexPath.row + 1] as activityInformation
        }
         
        cell.vetFacilityLabel.text = (vac.vetFacilityName != nil) ? vac.vetFacilityName : ""
        cell.vetFacilityAddressLabel.text = (vac.vetFacilityAddress != nil) ? vac.vetFacilityAddress : ""
        cell.vetFacilityAddressLabel.lineBreakMode = .byWordWrapping
        cell.vetFacilityAddressLabel.numberOfLines = 0
        cell.vetFacilityAddressLabel.preferredMaxLayoutWidth = view.frame.size.width - 40.0
        
        let dt = Utility.getDateFromString(dateString: ((vac.activityDate != nil) ? vac.activityDate! : "1970-01-01"))
        let dateformatter = DateFormatter()
        dateformatter.dateStyle = .medium
        cell.visitDateLabel.text = "Visit Date:  \(dateformatter.string(from: dt))"
        cell.activityId = vac.activityId!
        cell.selectionStyle = .none
        
        cell.deleteButton.layer.setValue(cell.activityId, forKey: "activityId")
        cell.deleteButton.addTarget(self, action: #selector(didTapDeleteButton), for: UIControl.Event.touchUpInside)
        
        cell.editButton.layer.setValue(cell.activityId, forKey: "activityId")
        cell.editButton.addTarget(self, action: #selector(didTapEditButton), for: UIControl.Event.touchUpInside)
        
        return cell
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell: VaccineAdministrativeListTableViewCell = tableView.cellForRow(at: indexPath) as! VaccineAdministrativeListTableViewCell
        self.LoadActivity(activityId: cell.activityId)
    }
    
    func LoadActivity(activityId:Int) {
        let vc : VaccineActivityViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "VaccineActivity") as! VaccineActivityViewController
        vc.activityId = activityId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func didTapEditButton(sender:UIButton){
        let actId : Int = (sender.layer.value(forKey: "activityId")) as! Int
        self.LoadActivity(activityId: actId)
    }
    
    @objc func didTapDeleteButton(sender:UIButton){
        self.resignFirstResponder()
        let dialogMessage = UIAlertController(title: "Confirm", message: "Are you sure you want to delete this activity details?", preferredStyle: .alert)
        let yes = UIAlertAction(title: "Yes", style: .default, handler: { (action) -> Void in
            let actId : Int = (sender.layer.value(forKey: "activityId")) as! Int
            self.deleteActivity(actId: actId)
        })
        let no = UIAlertAction(title: "No", style: .cancel) { (action) -> Void in
            print("Cancel button tapped")
        }
        dialogMessage.addAction(yes)
        dialogMessage.addAction(no)
        self.present(dialogMessage, animated: true, completion: nil)
    }
    
    func deleteActivity(actId:Int) {
        self.showActivityIndicator()
        VaccineService.DeleteVaccineActivity(petId: Utility.getDefaultPetId(), activityId: actId, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let remData = try? decoder.decode(vaccineActivityResponse.self, from: data) else { return }
            if let status = remData.status {
                self.hideActivityIndicator()
                if(status == 200) {
                    self.showSuccessMessage(message: "Vaccine administraton details deleted successfully")
                    self.loadVaccineAdministrationList()
                }
            } else {
                self.showErrorMessage(message: "Error in deleting vaccine administration details. Please try again later.")
                self.hideActivityIndicator()
            }
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
}
