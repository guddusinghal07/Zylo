//
//  MedicineDetailsViewController.swift
//  Zylo
//
//  Created by Sathish on 14/04/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit
import DropDown

class MedicineDetailsViewController: BaseInnerViewController,dataProcessingDelegateProtocol {
    
    var medicineId: Int = 0
    var frequencyValue: String = ""
    var frequencyList : [Frequency] = []
    var medicineData : Medicine!
    @IBOutlet weak var nameTextField: TextField!
    @IBOutlet weak var categoryTextField: TextField!
    @IBOutlet weak var adminTypeTextField: TextField!
    @IBOutlet weak var brandTextField: TextField!
    @IBOutlet weak var frequencyTextField: TextField!
    @IBOutlet weak var lastAdministrativeDateTextField: DateTextField!
    
    var txtName : String!
    var txtCategory : String!
    var txtAdminType : String!
    var txtBrand : String!
    var txtFrequnecy : String!
    var txtLastDate : String!
    
    var isTextChanged : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(self.medicineId > 0) {
            self.setScreenTitle(with: "Update Medicine", color: .black)
        } else {
            self.setScreenTitle(with: "Add Medicine", color: .black)
        }
        
        Utility.setRightNavigationButton(target: self, image: UIImage(named: "save")!, action: #selector(self.didTapSaveButton))
        
        if(self.medicineId > 0) {
            self.getMedicine()
        }
    }
    
    @objc func didTapSaveButton() {
        self.resignFirstResponder()
        
        if(self.medicineId > 0){
            if(!self.checkChangeInValue()){
                self.showErrorMessage(message: "Please change atleast one value to update the record!")
                return
            }
        }
        if(self.validateInputs()) {
            if(self.medicineId <= 0) {
                self.createMedicine()
            } else {
                self.updateMedicine()
            }
        }
    }
    
    func checkChangeInValue() -> Bool{
        let lastAdminDate = Utility.getStringFromDate(dateString: lastAdministrativeDateTextField!.selectedDate)
        if(nameTextField.text == txtName && brandTextField.text == txtBrand && adminTypeTextField.text == txtAdminType && frequencyTextField.text == txtFrequnecy && categoryTextField.text == txtCategory && txtLastDate == lastAdminDate){
            return false
        }else{
            return true
        }
    }
    
    func validateInputs() -> Bool {
        var returnValue: Bool = true
        if(self.nameTextField.isEmpty()) {
            self.nameTextField.errorMessage = "Medicine Name is required"
            returnValue = false
        } else {
            self.nameTextField.errorMessage = ""
        }
        if(self.categoryTextField.isEmpty()) {
            self.categoryTextField.errorMessage = "Medicine Category is required"
            returnValue = false
        } else {
            self.categoryTextField.errorMessage = ""
        }
        if(self.adminTypeTextField.isEmpty()) {
            self.adminTypeTextField.errorMessage = "Administrative Type is required"
            returnValue = false
        } else {
            self.adminTypeTextField.errorMessage = ""
        }
        if(self.frequencyTextField.isEmpty()) {
            self.frequencyTextField.errorMessage = "Frequency is required"
            returnValue = false
        } else if((self.frequencyValue.integerValue!) <= 0) {
            self.frequencyTextField.errorMessage = "Frequency should be greater than zero"
            returnValue = false
        } else {
            self.frequencyTextField.errorMessage = ""
        }
        return returnValue
    }
    
    func getMedicine() {
        if(self.medicineId > 0) {
            self.showActivityIndicator()
            MedicineService.getMedicine(petId: Utility.getDefaultPetId(), medId: self.medicineId, onSuccess: {(data) in
                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase
                guard let medData = try? decoder.decode(MedicineList.self, from: data) else { return }
                if let medLst = medData.data {
                    if(medLst.count > 0) {
                        let med = medLst[0]
                        self.medicineData = med
                        self.nameTextField.text = med.medName
                        self.categoryTextField.text = med.medCategory
                        self.adminTypeTextField.text = med.medAdminType
                        self.brandTextField.text = med.medBrand
                        for frequencyData in self.frequencyList{
                            if frequencyData.frequencyDays == med.medAdminFrequency!{
                                self.frequencyTextField.text = frequencyData.frequencyDaysValue
                                
                                if let frequency = frequencyData.frequencyDays {
                                   self.frequencyValue = String(frequency )
                                }
                                else{
                                   self.frequencyValue = "";
                                }                                
                                break
                            }
                        }
                        
                        let lastAdminDate = Utility.getDateFromString(dateString: med.lastAdministrationDate!)
                        self.lastAdministrativeDateTextField.selectedDate = lastAdminDate
                        
                        self.setData(med)
                        
                    }
                }
                self.hideActivityIndicator()
            }, onFailure: {_ in
                self.hideActivityIndicator()
            })
        }
    }
    
    func createMedicine() {
        self.showActivityIndicator()
        MedicineService.addMedicine(petId: Utility.getDefaultPetId(), postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let medData = try? decoder.decode(MedicineResponse.self, from: data) else { return }
            if let medId = medData.medicineId {
                if(medId > 0) {
                    self.navigationController?.popViewController(animated: true)
                    self.showSuccessMessage(message: "Medicine details saved successfully")
                } else {
                   self.showErrorMessage(message: medData.message!)
               }
            } else {
                self.showErrorMessage(message: "Error in creating medicine details. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func updateMedicine() {
        self.showActivityIndicator()
        MedicineService.UpdateMedicine(petId: Utility.getDefaultPetId(), medId: self.medicineId, postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let medData = try? decoder.decode(MedicineResponse.self, from: data) else { return }
            if let medId = medData.medicineId {
                if(medId > 0) {
                    self.navigationController?.popViewController(animated: true)
                    self.showSuccessMessage(message: "Medicine details updated successfully")
                } else {
                   self.showErrorMessage(message: medData.message!)
               }
            } else {
                self.showErrorMessage(message: medData.message!)
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func getParamValues() -> NSDictionary {
        let data:[String:Any] = ["med_name":self.nameTextField.text!, "med_category":self.categoryTextField.text!, "med_admin_type":self.adminTypeTextField.text!, "med_brand":self.brandTextField.text!, "med_admin_frequency":self.frequencyValue, "last_administration_date":self.lastAdministrativeDateTextField.getDate()]
        
        let postData:[String:Any] = ["data":data]
            
        return postData as NSDictionary
    }
}

extension MedicineDetailsViewController{
    
    func setData(_ sender : Medicine){
        let medData = sender
        txtName = medData.medName
        txtCategory = medData.medCategory
        txtAdminType = medData.medAdminType
        txtBrand = medData.medBrand
        for frequencyData in self.frequencyList{
            if frequencyData.frequencyDays == medData.medAdminFrequency!{
                self.frequencyTextField.text = frequencyData.frequencyDaysValue
                
                if frequencyData.frequencyDays != nil {
                   txtFrequnecy = frequencyData.frequencyDaysValue
                }
                else{
                   txtFrequnecy = "";
                }
                break
            }
        }
        txtLastDate = medData.lastAdministrationDate
    }
    
    @IBAction func selectFrequencyData(_ sender: UIButton) {
        self.resignFirstResponder()
        let vc : PopupViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "PopUp") as! PopupViewController
        vc.delegate = self
        vc.frequencyList = self.frequencyList
        vc.type = Constants().frequency
        self.present(vc, animated: true, completion: nil)
    }
    
    func processSelectedData(_ data: Search, type: String) {
        self.frequencyTextField.text = data.name
        self.frequencyValue = String(data.id)
    }
}

