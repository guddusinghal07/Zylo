//
//  VaccineViewController.swift
//  Zylo
//
//  Created by Sathish on 28/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class VaccineViewController: BaseViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet var collection: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setScreenTitle(with: "Vaccination")
        
        collection.delegate = self
        collection.dataSource = self
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical //.horizontal
        layout.minimumLineSpacing = 20
        layout.minimumInteritemSpacing = 20
        collection.setCollectionViewLayout(layout, animated: true)
        
        let isfirstTime = UserDefaults.standard.object(forKey: "firstTimeLoggedIn") as! Bool
        
        if(isfirstTime){
            UserDefaults.standard.set(false, forKey: "firstTimeLoggedIn")
            let vc : VaccineAssociationViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "VaccineAssociation") as! VaccineAssociationViewController
            self.navigationController?.pushViewController(vc, animated: false)
        }
        
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        if (size.width != self.view.frame.size.width) {
            DispatchQueue.main.async {
                self.collection.reloadData()
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 20.0, left: 20.0, bottom: 20.0, right: 20.0)//here your custom value for spacing
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let lay = collectionViewLayout as! UICollectionViewFlowLayout
        let widthPerItem = collectionView.frame.width / 2 - (lay.minimumInteritemSpacing * 2.0)
        return CGSize(width: widthPerItem + 10.0, height: 170.0)
    }
        
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: VaccineCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "VaccineCell", for: indexPath) as! VaccineCollectionViewCell
        //cell.backgroundColor = UIColor.red
        cell.layer.cornerRadius = 10
        cell.layer.borderWidth = 1.0
        cell.layer.borderColor = Constants().themeColor.cgColor //UIColor.lightGray.cgColor

        cell.layer.backgroundColor = UIColor.white.cgColor
        cell.layer.shadowColor = UIColor.gray.cgColor
        cell.layer.shadowOffset = CGSize(width: 1.0, height: 2.0)
        cell.layer.shadowRadius = 2.0
        cell.layer.shadowOpacity = 1.0
        cell.layer.masksToBounds = false
                
        cell.titleLabel.numberOfLines = 0
        cell.titleLabel.lineBreakMode = .byWordWrapping
        cell.titleLabel.preferredMaxLayoutWidth = cell.frame.size.width - 30.0
        cell.titleLabel.font = UIFont.openSansBoldFontOfSize(size: 15.0)
        
        switch indexPath.row {
//        case 0:
//            cell.titleLabel.text = "Vaccine Association"
//            cell.vaccineImage.image = UIImage(named: "vaccine-associate")
        case 0:
            cell.titleLabel.text = "Vaccine Administration"
            cell.vaccineImage.image = UIImage(named: "vaccine-admin")
        case 1:
            cell.titleLabel.text = "Insights"
            cell.vaccineImage.image = UIImage(named: "report")
        default:
            break
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        if indexPath.row == 0 {
//            let vc : VaccineAssociationViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "VaccineAssociation") as! VaccineAssociationViewController
//            self.navigationController?.pushViewController(vc, animated: true)
//        } else
            if indexPath.row == 0 {
            let vc : VaccineActivityListViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "VaccineActivityList") as! VaccineActivityListViewController
            self.navigationController?.pushViewController(vc, animated: true)
        } else if indexPath.row == 1 {
            let vc : UpcomingVaccineViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "UpcomingVaccine") as! UpcomingVaccineViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
