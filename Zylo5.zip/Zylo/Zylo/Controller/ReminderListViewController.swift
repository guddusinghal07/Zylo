//
//  ReminderListViewController.swift
//  Zylo
//
//  Created by Sathish on 09/06/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class ReminderListViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var infoView: UIView!
    
    var reminderList: [Reminder] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setScreenTitle(with: "Manage Reminder")
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.separatorColor = .clear
        self.tableView.backgroundColor = UIColor.clear
        self.tableView.estimatedRowHeight = 146
        
        self.infoView.backgroundColor = .white
        Utility.setView(view: self.infoView, hidden: true)
        Utility.setRightNavigationButton(target: self, image: UIImage(named: "add")!, action: #selector(self.addButtonAction))
        
        self.loadReminderList()
        
        NotificationCenter.default.addObserver(self, selector: #selector(loadList), name: NSNotification.Name(rawValue: Constants().reloadReminderDetails), object: nil)
    }
    
    @objc func loadList(notification: NSNotification){
        //load data here
        self.loadReminderList()
    }
    
    func loadReminderList() {
        self.reminderList = []
        self.getReminderList()
    }
    
    func getReminderList() {
        self.showActivityIndicator()
        ReminderService.getReminder(reminderId: 0, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let remData = try? decoder.decode(ReminderList.self, from: data) else { return }
            if let remLst = remData.data {
                for rem in remLst {
                    if(rem.isDeleted != nil && rem.isDeleted! == false) {
                        self.reminderList.append(rem)
                    }
                }
                self.tableView.reloadData()
            } else if remData.status != 200 {
                self.showErrorMessage(message: "Error in getting reminder data. Please try again later.")
            }
            if(self.reminderList.count <= 0) {
                Utility.setView(view: self.infoView, hidden: false)
            } else {
                Utility.setView(view: self.infoView, hidden: true)
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    @objc func addButtonAction() {
        self.LoadReminder(reminderId: 0)
    }

    private func LoadReminder(reminderId: Int) {
        self.resignFirstResponder()
        let vc : ReminderViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "Reminder") as! ReminderViewController
        vc.reminderId = reminderId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    public func tableView(_ tableView: UITableView, numberOfRowsInSection sectionIndex: Int) -> Int {
        return reminderList.count
    }

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: ReminderListTableViewCell = tableView.dequeueReusableCell(withIdentifier: "ReminderCell", for: indexPath) as! ReminderListTableViewCell
        
        let rem:Reminder = reminderList[indexPath.row]
        if(rem.medicineId != nil && rem.medicineId! > 0) {
            cell.profileNameLabel.text = "\(rem.profilePetName!) - (\(rem.medName!))"
        } else if(rem.vaccineId != nil && rem.vaccineId! > 0) {
            cell.profileNameLabel.text = "\(rem.profilePetName!) - (\(rem.vaccineName!))"
        }
        let dateformatter = DateFormatter()
        dateformatter.dateStyle = .medium
        if let startDate = rem.reminderStartDate {
            let dt = Utility.getDateFromString(dateString: startDate)
            cell.reminderFromDateLabel.text = "Reminder Start Date: \(dateformatter.string(from: dt))"
        }
        if let endDate = rem.reminderEndDate {
            let dt = Utility.getDateFromString(dateString: endDate)
            cell.reminderToDateLabel.text = "Reminder End Date: \(dateformatter.string(from: dt))"
        }
        cell.frequencyLabel.text = "\(rem.reminderFrequency!) day(s)"
        cell.reminderId = rem.reminderId!
        cell.selectionStyle = .none
        
        cell.deleteButton.layer.setValue(cell.reminderId, forKey: "reminderId")
        cell.deleteButton.addTarget(self, action: #selector(didTapDeleteButton), for: UIControl.Event.touchUpInside)
        
        return cell
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell: ReminderListTableViewCell = tableView.cellForRow(at: indexPath) as! ReminderListTableViewCell
        self.LoadReminder(reminderId: cell.reminderId)
    }
    
    @objc func didTapDeleteButton(sender:UIButton){
        self.resignFirstResponder()
        let dialogMessage = UIAlertController(title: "Confirm", message: "Are you sure you want to delete this reminder details?", preferredStyle: .alert)
        let yes = UIAlertAction(title: "Yes", style: .default, handler: { (action) -> Void in
            let remId : Int = (sender.layer.value(forKey: "reminderId")) as! Int
            self.deleteReminder(remId: remId)
        })
        let no = UIAlertAction(title: "No", style: .cancel) { (action) -> Void in
            print("Cancel button tapped")
        }
        dialogMessage.addAction(yes)
        dialogMessage.addAction(no)
        self.present(dialogMessage, animated: true, completion: nil)
    }
    
    func deleteReminder(remId:Int) {
        self.showActivityIndicator()
        ReminderService.DeleteReminder(reminderId: remId, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let remData = try? decoder.decode(ReminderResponse.self, from: data) else { return }
            if let status = remData.status {
                self.hideActivityIndicator()
                if(status == 200) {
                    self.showSuccessMessage(message: "Reminder details deleted successfully")
                    self.loadReminderList()
                }
            } else {
                self.showErrorMessage(message: "Error in deleting reminder details. Please try again later.")
                self.hideActivityIndicator()
            }
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
}
