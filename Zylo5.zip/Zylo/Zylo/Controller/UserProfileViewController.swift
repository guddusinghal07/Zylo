//
//  UserProfileViewController.swift
//  Zylo
//
//  Created by Sathish on 28/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class UserProfileViewController: BaseInnerViewController, dataProcessingDelegateProtocol {

    @IBOutlet weak var uploadPictureButton: NiceButton!
    @IBOutlet weak var emailAddressTextField: TextField!
    @IBOutlet weak var firstNameTextField: TextField!
    @IBOutlet weak var lastNameTextField: TextField!
    @IBOutlet weak var profileNameTextField: TextField!
    @IBOutlet weak var DOBTextField: DateTextField!
    @IBOutlet weak var phoneNumberTextField: TextField!
    @IBOutlet weak var addressTextField: TextField!
    @IBOutlet weak var cityTextField: TextField!
    @IBOutlet weak var stateTextField: TextField!
    @IBOutlet weak var countryTextField: TextField!
    @IBOutlet weak var zipcodeTextField: TextField!
    @IBOutlet weak var editView: UIView!
    
    var imagePicker: ImagePicker!
    var isNavigatedFromMenu: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setScreenTitle(with: "User Profile", color: .black)
        // Do any additional setup after loading the view.
        
        self.uploadPictureButton.loadUserImage()
        
        self.imagePicker = ImagePicker(presentationController: self, delegate: self)
        
        self.editView.bottomCornorRadius()
        let clickGesture = UITapGestureRecognizer(target: self, action:  #selector(self.editAction))
        self.editView.addGestureRecognizer(clickGesture)
        
        Utility.setRightNavigationButton(target: self, image: UIImage(named: "save")!, action: #selector(self.saveProfileAction))
        
        self.getUserFromServer()
    }
    
    @objc func editAction(_ sender: UIView) {
        self.imagePicker.present(from: sender)
    }
    
    @objc func saveProfileAction() {
        self.resignFirstResponder()
        if(self.validateInputs()) {
            self.updateUserProfile()
        }
    }
    
    func validateInputs() -> Bool {
        var returnValue: Bool = true
        if(self.firstNameTextField.isEmpty()) {
            self.firstNameTextField.errorMessage = "First Name is required"
            returnValue = false
        } else {
            self.firstNameTextField.errorMessage = ""
        }
        if(self.lastNameTextField.isEmpty()) {
            self.lastNameTextField.errorMessage = "Last Name is required"
            returnValue = false
        } else {
            self.lastNameTextField.errorMessage = ""
        }
        if(self.profileNameTextField.isEmpty()) {
            self.profileNameTextField.errorMessage = "Profile Name is required"
            returnValue = false
        } else {
            self.profileNameTextField.errorMessage = ""
        }
        return returnValue
    }
    
    func updateUserProfile() {
        self.showActivityIndicator()
        UserService.UpdateUser(userId: Utility.getCurrentUserId(), postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let userData = try? decoder.decode(SaveUser.self, from: data) else { return }
            if let status = userData.status {
                if(status == 200) {
                    Utility.setLoggedInUserDetails(userName: self.profileNameTextField.text!, givenName: self.firstNameTextField.text!, familyName: self.lastNameTextField.text!)
                    Utility.setLoggedInUserImageUrl(userImageUrl:Utility.getCurrentUserImageUrl())
                    self.uploadPictureButton.removeUserImageFromCache()
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: Constants().reloadUser), object: nil)
                    if(!self.isNavigatedFromMenu) {
                        self.navigationController?.popViewController(animated: true)
                    }
                    self.showSuccessMessage(message: "User details updated successfully")
                }
            } else {
                self.showErrorMessage(message: "Error in updating user profile. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func getParamValues() -> NSDictionary {
        let data:[String:Any] = ["user_first_name":self.firstNameTextField.text!, "user_last_name":self.lastNameTextField.text!, "user_profile_name":self.profileNameTextField.text!, "user_dob":self.DOBTextField.getDate(), "user_phone_number":self.phoneNumberTextField.text!, "user_address":self.addressTextField.text!, "user_city":self.cityTextField.text!, "user_state":self.stateTextField.text!, "user_country":self.countryTextField.text!, "user_zipcode":self.zipcodeTextField.text!]
        
        var base64String = ""
        if(self.uploadPictureButton.backgroundImage(for: .normal) != nil) {
            base64String = Utility.convertImageToBase64String(image: self.uploadPictureButton.backgroundImage(for: .normal)!)
        }
        if(!base64String.isEmpty) {
            base64String = "data:image/png;base64," + base64String
        }
        
        let postData:[String:Any] = ["data":data, "image_data":base64String]
            
        return postData as NSDictionary
    }
    
    func getUserFromServer() {
        self.showActivityIndicator()
        UserService.getUser(useOldData: false, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let UserData = try? decoder.decode(UserData.self, from: data) else { return }
            if let user = UserData.data {
                if(user.isDeleted! == false) {
                    self.emailAddressTextField.text = user.userEmail
                    self.firstNameTextField.text = user.userFirstName
                    self.lastNameTextField.text = user.userLastName
                    self.profileNameTextField.text = user.userProfileName
                    if let usrDOB = user.userDob {
                        let DOB = Utility.getDateFromString(dateString: usrDOB)
                        self.DOBTextField.selectedDate = DOB
                    }
                    self.phoneNumberTextField.text = user.userPhoneNumber
                    self.addressTextField.text = user.userAddress
                    self.cityTextField.text = user.userCity
                    self.stateTextField.text = user.userState
                    self.countryTextField.text = user.userCountry
                    self.zipcodeTextField.text = user.userZipcode
                }
            } else {
                self.showErrorMessage(message: "Error in getting user data. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    @IBAction func showImagePicker(_ sender: UIButton) {
        self.resignFirstResponder()
        self.imagePicker.present(from: sender)
    }
    
    override func bindLocation() {
        self.addressTextField.text = self.street
        self.cityTextField.text = self.city
        self.stateTextField.text = self.state
        self.countryTextField.text = self.country
        self.zipcodeTextField.text = self.zipcode
        self.hideActivityIndicator()
    }
    
    @IBAction func searchCountry(_ sender: UIButton) {
        self.resignFirstResponder()
        let vc : PopupViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "PopUp") as! PopupViewController
        vc.delegate = self
        vc.type = Constants.userCountry
        self.present(vc, animated: true, completion: nil)
    }
    
    // Delegate Method
    func processSelectedData(_ data: Search, type: String) {
        if(type == Constants.userCountry) {
            self.countryTextField.text = data.name
        }
    }
}

extension UserProfileViewController: ImagePickerDelegate {
    func didSelect(image: UIImage?) {
        if(image != nil) {
            self.uploadPictureButton.setBackgroundImage(image, for: .normal)
        }
    }
}
