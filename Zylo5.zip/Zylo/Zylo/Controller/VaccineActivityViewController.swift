//
//  VaccineActivityViewController.swift
//  Zylo
//
//  Created by Sathish on 15/04/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class VaccineActivityViewController: BaseInnerViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var tableView: UITableView!
    @IBOutlet weak var uploadCertificateButton: NiceButton!
    @IBOutlet weak var addDescriptionButton: NiceButton!
    @IBOutlet weak var headerViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var editView: UIView!
    
    var imagePicker: ImagePicker!
    var entries: [PetVaccine] = []
    var imageChanged: Bool = false
    var lastContentOffset: CGFloat = 0.0
    var activityId: Int = 0
    var rabiesVaccineId: Int = 0
    var actInfo = activityInformation()
    var isRabiesClosed : Bool = true
    var descriptionString : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setScreenTitle(with: "Vaccine Administration", color: .black)
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.separatorColor = .clear
        
        self.editView.bottomCornorRadius()
        Utility.setView(view: self.editView, hidden: true)
        
        self.imagePicker = ImagePicker(presentationController: self, delegate: self)
        
        Utility.setRightNavigationButton(target: self, image: UIImage(named: "save")!, action: #selector(self.saveButtonAction))
        
        NotificationCenter.default.addObserver(self, selector: #selector(loadList), name: NSNotification.Name(rawValue: Constants.reloadDescription), object: nil)
        
        entries = []
        if(self.activityId > 0) {
            self.addDescriptionButton.alpha = 0.0
            uploadCertificateButton.frame = CGRect.init(x: uploadCertificateButton.frame.origin.x, y: uploadCertificateButton.frame.origin.y, width: 160, height: 160)
            self.getVaccineActivity(activityId: self.activityId)
            self.view.layoutIfNeeded()
        } else {
            self.getPetVaccine()
        }
    }
    
    @objc func loadList(notification: NSNotification){
        let description = UserDefaults.standard.value(forKey: Constants.url) as? String
        self.descriptionString = description!
        
        if(description != nil){
            DispatchQueue.main.async(execute: {
                self.addDescriptionButton.isHidden = false
                self.addDescriptionButton.isUserInteractionEnabled = false
                self.addDescriptionButton.alpha = 1.0
                self.addDescriptionButton.setTitle(description!, for: .normal)
            })
        }
    }
    
    func getPetVaccine() {
        self.showActivityIndicator()
        VaccineService.getPetVaccine(petId: Utility.getDefaultPetId(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let vacData = try? decoder.decode(PetVaccineList.self, from: data) else { self.hideActivityIndicator(); return }
            if let vacList = vacData.data {
                if let petList = vacList.vaccineAssociation {
                    for vac in petList {
                        if(vac.isActive == true && vac.isDeleted! == false) {
                            vac.givenDate = Date()
                            vac.isSelected = true
                            self.entries.append(vac)
                        }
                    }
                }
                if let vet = vacList.vetDetails {
                    self.actInfo = activityInformation()
                    self.actInfo.vetFacilityName = vet.vetHospital
                    var address = "\(vet.vetHospitalAddress!) \(vet.vetCity!) \(vet.vetState!) \(vet.vetZipcode!)"
                    let trimmedString = address.trimmingCharacters(in: .whitespaces)
                    if(trimmedString == ""){
                        address = "Not Provided"
                    }
                    self.actInfo.vetFacilityAddress = address
                    
                    self.actInfo.vetDoctorName = vet.vetPocName
                    
                    if(vet.vetPocName == ""){
                        self.actInfo.vetDoctorName = "Not Provided"
                    }
                    
                    
                }else{
                    self.actInfo.vetFacilityAddress = "Not Provided"
                }
                self.tableView.reloadData()
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func validateFields() -> Bool{
        let path = IndexPath(item: 0, section: 0)
        let cell = self.tableView.cellForRow(at: path) as? VaccineAdministrativeTableViewCell
        
        if(cell?.facilityTextField.text == ""){
            cell?.facilityTextField.errorMessage = "Facility Name is required"
            return false
        }
        
        return true
    }
    
    @objc func saveButtonAction() {
        self.resignFirstResponder()
        
        if(self.validateFields()){
            if(self.activityId > 0) {
                self.updateVaccineActivity()
            } else {
                self.createVaccineActivity()
            }
        }
    }
    
    func getVaccineActivity(activityId: Int) {
        self.showActivityIndicator()
        self.uploadCertificateButton.loadVaccineImage(petId: Utility.getDefaultPetId(), activityId: activityId)
        self.uploadCertificateButton.setTitle("", for: .normal)
        self.uploadCertificateButton.setImage(nil, for: .normal)
        Utility.setView(view: self.editView, hidden: false)
        let clickGesture = UITapGestureRecognizer(target: self, action:  #selector(self.editAction))
        self.editView.addGestureRecognizer(clickGesture)
        VaccineService.getPetVaccineActivity(petId: Utility.getDefaultPetId(), activityId: activityId, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let vacData = try? decoder.decode(vaccineActivity.self, from: data) else { self.hideActivityIndicator(); return }
            if let vacList = vacData.data {
                for vac in vacList.vaccineLogs! {
                    let pv:PetVaccine = PetVaccine()
                    pv.isActive = (vac.isActive!)
                    pv.vaccineId = vac.vaccineId
                    pv.vaccineName = vac.vaccineName
                    pv.givenDate = vac.dateVaccineGiven?.toDate
                    pv.dueDate = vac.dateVaccineDue?.toDate
                    pv.isRabies = (vac.isRabies!)
                    pv.isSelected = vac.isGiven
                    pv.isGiven = vac.isGiven
                    pv.vaccineAdminFreq = vac.vaccineAdminFreq
                    if let rab = vacList.rabiesData {
                        pv.rabiesTagNumber = rab.tagNumber
                        pv.rabiesSerialNumber = rab.serialNumber
                        pv.rabiesVaccineName = rab.vaccineName
                        pv.rabiesVaccineType = rab.vaccineType
                        pv.rabiesVaccineProducer = rab.vaccineProducer
                        if let label = rab.rabiesVaccineId {
                            self.rabiesVaccineId = label
                        }
                    }
                    self.actInfo = vacList.activityInformation!
                    self.entries.append(pv)
                }
                self.tableView.reloadData()
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func createVaccineActivity() {
        self.showActivityIndicator()
        VaccineService.addVaccineActivity(petId: Utility.getDefaultPetId(), postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let actData = try? decoder.decode(activityResponse.self, from: data) else { self.hideActivityIndicator(); return }
            if(actData.status == 200) {
                self.navigationController?.popViewController(animated: true)
                self.showSuccessMessage(message: "Vaccine administration details saved successfully")
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: Constants().reloadActivityDetails), object: nil)
             } else {
                if(actData.message != nil) {
                    self.showErrorMessage(message: actData.message!)
                }
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func updateVaccineActivity() {
        self.showActivityIndicator()
        VaccineService.updateVaccineActivity(petId: Utility.getDefaultPetId(), activityId: self.activityId, postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let actData = try? decoder.decode(activityResponse.self, from: data) else { self.hideActivityIndicator(); return }
            if(actData.status == 200) {
                self.navigationController?.popViewController(animated: true)
                self.showSuccessMessage(message: "Vaccine administration details saved successfully")
                if(self.imageChanged) {
                    self.uploadCertificateButton.removeVaccineImageFromCache(petId: Utility.getDefaultPetId(), activityId: self.activityId)
                }
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: Constants().reloadActivityDetails), object: nil)
             } else {
                if(actData.message != nil) {
                    self.showErrorMessage(message: actData.message!)
                }
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func getParamValues() -> NSDictionary {
        var vaccineData = [[String: Any]]()
        var rabiesData = [String: Any]()
        var isRabiesDataExist:Bool = false
        var vaccineName : [String] = []
        for i in 0..<entries.count {
            let vac = entries[i]
            if(vac.isSelected!) {
                if(vac.isRabies!) {
                    isRabiesDataExist = true
                    rabiesData = ["operation": self.rabiesVaccineId,
                                  "rabies_vaccine_id": self.rabiesVaccineId,
                                  "date_given": vac.givenDate?.getDate() as Any,
                                  "tag_number": vac.rabiesTagNumber as Any,
                                  "serial_number": vac.rabiesSerialNumber as Any,
                                  "vaccine_type": vac.rabiesVaccineType as Any,
                                  "vaccine_name": vac.rabiesVaccineName as Any,
                                  "vaccine_producer": vac.rabiesVaccineProducer as Any]
                    
                        vaccineName.append(vac.rabiesVaccineName!)
                }
                vaccineName.append(vac.vaccineName!)
                vaccineData.append(["vaccine_id": String(vac.vaccineId!), "date_vaccine_given": vac.givenDate?.getDate() as Any,
                    "date_vaccine_due":vac.dueDate?.getDate() as Any])
            }
        }
        
        let path = IndexPath(item: 0, section: 0)
        let cell = self.tableView.cellForRow(at: path) as? VaccineAdministrativeTableViewCell
        
        let activityInformation:[String:Any] = [
            "is_rabies_given": isRabiesDataExist,
            "activity_date": cell?.visitDateTextFiled.getDate() as Any,
            "vet_facility_name": cell?.facilityTextField.text as Any,
            "vet_doctor_name": cell?.doctorNameTextField.text as Any,
            "vet_doctor_licence_number": cell?.doctorLicenseNumberTextField.text as Any,
            "vet_facility_address": cell?.vetHospital.text as Any]
    
        
        if(self.imageChanged) {
            var base64String = ""
            if(self.uploadCertificateButton.backgroundImage(for: .normal) != nil) {
                base64String = Utility.convertImageToBase64String(image: self.uploadCertificateButton.backgroundImage(for: .normal)!)
            }
            if(!base64String.isEmpty) {
                base64String = "data:image/png;base64," + base64String
            }
            
            let joined = vaccineName.joined(separator: ", ")
            let certificateMetaData:[String:Any] = [
                "pet_name": Utility.getDefaultPetName(),
                "user_name": Utility.getCurrentUserFullName(),
                "activity_description": self.descriptionString,
                "given_vaccine": joined]
            
            let certificateInformation:[String:Any] = [
            "vaccine_certificate_metadata": certificateMetaData,
            "vaccine_certificate": base64String]
            
            
            let data:[String:Any] = ["activity_information":activityInformation, "vaccine_logs":vaccineData, "rabies_data":rabiesData, "vaccine_certificate_data": certificateInformation]
            let postData:[String:Any] = ["data":data]
            return postData as NSDictionary
        } else {
            let data:[String:Any] = ["activity_information":activityInformation, "vaccine_logs":vaccineData, "rabies_data":rabiesData]
            let postData:[String:Any] = ["data":data]
            return postData as NSDictionary
        }
    }
    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if((indexPath.section == 1 && isRabiesClosed == true && self.rabiesVaccineId == 0) ){
            let vac:PetVaccine = entries[indexPath.row]
            if(vac.isRabies == true)
            {
                return 150
            }
            return UITableView.automaticDimension
        }
        
        return UITableView.automaticDimension
    }

    public func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

    public func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }

    public func tableView(_ tableView: UITableView, numberOfRowsInSection sectionIndex: Int) -> Int {
        if(sectionIndex == 0) {
            return 1
        } else {
            return entries.count
        }
    }

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if(indexPath.section == 0) {
            let cell: VaccineAdministrativeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "VaccineAdministrativeHeader", for: indexPath) as! VaccineAdministrativeTableViewCell
            cell.selectionStyle = .none
            cell.vaccineAdministrativeLabel.text = "Establish Vaccine Administrative details for \(Utility.getDefaultPetName())"
            cell.vaccineAdministrativeLabel.lineBreakMode = .byWordWrapping
            cell.vaccineAdministrativeLabel.numberOfLines = 0
            cell.vaccineAdministrativeLabel.preferredMaxLayoutWidth = view.frame.size.width - 40.0
            
            if(self.actInfo.activityDate != nil) {
                cell.visitDateTextFiled.selectedDate =  self.actInfo.activityDate?.toDate
            }
            cell.facilityTextField.text = self.actInfo.vetFacilityName
            cell.vetHospital.text = self.actInfo.vetFacilityAddress
            cell.doctorNameTextField.text = self.actInfo.vetDoctorName
            cell.doctorLicenseNumberTextField.text = self.actInfo.vetDoctorLicenceNumber
            
            cell.visitDateTextFiled.callback = { newValue in
                self.tableViewUpdate()
            }
            cell.facilityTextField.updateCallback = { newValue in
                self.tableViewUpdate()
            }
            cell.vetHospital.updateCallback = { newValue in
                self.tableViewUpdate()
            }
            cell.doctorNameTextField.updateCallback = { newValue in
                self.tableViewUpdate()
            }
            cell.doctorLicenseNumberTextField.updateCallback = { newValue in
                self.tableViewUpdate()
            }
            return cell
        } else {
            let cell: VaccineAdministrativeDetailTableViewCell = tableView.dequeueReusableCell(withIdentifier: "VaccineAdministrativeDetailCell", for: indexPath) as! VaccineAdministrativeDetailTableViewCell
            cell.selectionStyle = .none
            
            let vac:PetVaccine = entries[indexPath.row]
            
            if(isRabiesClosed == true && self.rabiesVaccineId == 0 && vac.isRabies == true){
                cell.rabiesView?.isHidden = true
                cell.rabiesHeightConstraint.constant = 0
                cell.dateDueTextField.isHidden = true
                cell.dateGivenTextField.isHidden = true
                cell.rabiesInfoButton.isHidden = true
                cell.associationId = vac.vaccineId!
                cell.vaccineLabel.text = vac.vaccineName
                vac.isSelected = false
                cell.layoutIfNeeded()
                cell.tagNumberTextField.text = vac.rabiesTagNumber
                if(vac.rabiesSerialNumber != nil) {
                    cell.serialNumberTextField.text = String(vac.rabiesSerialNumber!)
                }
                
                if(vac.givenDate == nil){
                    vac.givenDate = Date()
                }

                cell.dateGivenTextField.selectedDate = vac.givenDate
               let dueDate : Date
                if(vac.dueDate == nil){
                    dueDate = vac.givenDate!.addDay(n: vac.vaccineAdminFreq!)
                    vac.dueDate = dueDate
                }else{
                    dueDate = vac.dueDate!
                }
                cell.dateDueTextField.selectedDate = dueDate
                
                cell.vaccineTypeTextField.text = vac.rabiesVaccineType
                cell.vaccineNameTextField.text = vac.rabiesVaccineName
                cell.vaccineProducerTextField.text = vac.rabiesVaccineProducer
                cell.rabiesCallback = { newValue in
                    if(newValue) {
                        self.tableViewUpdate()
                    }
                }
                cell.dateGivenTextField.callback = { newValue in
                    vac.givenDate = newValue
                    let dueDate = newValue.addDay(n: vac.vaccineAdminFreq!)
                //    cell.dateDueTextField.selectedDate = dueDate
                //    vac.dueDate = dueDate
                }
                cell.dateDueTextField.callback = { newValue in
                    vac.dueDate = newValue
                }
                cell.tagNumberChangeCallback = { newValue in
                    vac.rabiesTagNumber = newValue
                }
                cell.serialNumberChangeCallback = { newValue in
                    vac.rabiesSerialNumber = newValue
                }
                cell.vaccineTypeChangeCallback = { newValue in
                    vac.rabiesVaccineType = newValue
                }
                cell.vaccineNameChangeCallback = { newValue in
                    vac.rabiesVaccineName = newValue
                }
                cell.vaccineProducerChangeCallback = { newValue in
                    vac.rabiesVaccineProducer = newValue
                }
                cell.callback = { newValue in
                    if(!newValue){
                        self.isRabiesClosed = !newValue
                        vac.isSelected = newValue
                        cell.dateDueTextField.isHidden = true
                        cell.dateGivenTextField.isHidden = true
                        cell.rabiesInfoButton.isHidden = true
                        cell.rabiesView?.isHidden = true
                        cell.rabiesHeightConstraint.constant = 0
                        self.tableViewUpdate()
                    }else{
                        self.isRabiesClosed = !newValue
                        vac.isSelected = true
                        cell.dateDueTextField.isHidden = false
                        cell.dateGivenTextField.isHidden = false
                        cell.rabiesInfoButton.isHidden = false
                        cell.rabiesView?.isHidden = false
                        cell.rabiesHeightConstraint.constant = cell.rabiesViewHeight
                        self.tableViewUpdate()
                    }
                   
                }
                return cell
            }
            
            cell.dateDueTextField.isHidden = false
            cell.dateGivenTextField.isHidden = false
            cell.rabiesInfoButton.isHidden = false
            cell.associationId = vac.vaccineId!
            cell.vaccineLabel.text = vac.vaccineName
            if(vac.isGiven != nil) {
                cell.associationSwitch.isOn = vac.isGiven!
            }else{
                cell.associationSwitch.isOn = vac.isSelected!
            }
            cell.rabiesInfoButton.isHidden = !vac.isRabies!
            if(vac.isRabies!) {
                cell.rabiesView?.isHidden = false
                cell.rabiesHeightConstraint.constant = cell.rabiesViewHeight
                cell.layoutIfNeeded()
                cell.tagNumberTextField.text = vac.rabiesTagNumber
                if(vac.rabiesSerialNumber != nil) {
                    cell.serialNumberTextField.text = String(vac.rabiesSerialNumber!)
                }
                cell.vaccineTypeTextField.text = vac.rabiesVaccineType
                cell.vaccineNameTextField.text = vac.rabiesVaccineName
                cell.vaccineProducerTextField.text = vac.rabiesVaccineProducer
            } else {
                cell.rabiesView?.isHidden = true
                cell.rabiesHeightConstraint.constant = 0
                cell.layoutIfNeeded()
            }
                        
            if(vac.givenDate == nil){
                vac.givenDate = Date()
            }

            cell.dateGivenTextField.selectedDate = vac.givenDate
            
            let dueDate : Date
            if(vac.dueDate == nil){
                dueDate = vac.givenDate!.addDay(n: vac.vaccineAdminFreq!)
                vac.dueDate = dueDate
            }else{
                dueDate = vac.dueDate!
            }
            cell.dateDueTextField.selectedDate = dueDate
            cell.callback = { newValue in
                if(indexPath.row == 0){
                    print("Index 0")
                }
                 vac.isSelected = newValue
            }
            cell.rabiesCallback = { newValue in
                if(newValue) {
                    self.tableViewUpdate()
                }
            }
            cell.dateGivenTextField.callback = { newValue in
                vac.givenDate = newValue
                let dueDate = newValue.addDay(n: vac.vaccineAdminFreq!)
              //  cell.dateDueTextField.selectedDate = dueDate
              //  vac.dueDate = dueDate
            }
            cell.dateDueTextField.callback = { newValue in
                vac.dueDate = newValue
            }
            cell.tagNumberChangeCallback = { newValue in
                vac.rabiesTagNumber = newValue
            }
            cell.serialNumberChangeCallback = { newValue in
                vac.rabiesSerialNumber = newValue
            }
            cell.vaccineTypeChangeCallback = { newValue in
                vac.rabiesVaccineType = newValue
            }
            cell.vaccineNameChangeCallback = { newValue in
                vac.rabiesVaccineName = newValue
            }
            cell.vaccineProducerChangeCallback = { newValue in
                vac.rabiesVaccineProducer = newValue
            }
         //   self.tableViewUpdate()
            return cell
        }
    }
    
    func tableViewUpdate() {
        self.tableView.beginUpdates()
        self.tableView.endUpdates()
    }
    
    @IBAction func showImagePicker(_ sender: UIButton) {
        self.resignFirstResponder()
        self.imagePicker.present(from: sender)
    }
    
    @IBAction func showDescription(_ sender: UIButton){
        let alertVC = UIAlertController(title: "Add Certificate Description", message: "", preferredStyle: .alert)
        alertVC.addTextField { (textField) in
            textField.placeholder = "Enter Description"
        }
        let submitAction = UIAlertAction(title: "Save", style: .default, handler: {
            (alert) -> Void in
            
            let emailTextField = alertVC.textFields![0] as UITextField
            self.descriptionString = emailTextField.text!
            print("Email -- \(emailTextField.text!)")
            self.addDescriptionButton.setTitle(emailTextField.text, for: .normal)
        })
        alertVC.addAction(submitAction)
        alertVC.view.tintColor = UIColor.black
        present(alertVC, animated: true)
    }
    
    // this delegate is called when the scrollView (i.e your UITableView) will start scrolling
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        self.lastContentOffset = scrollView.contentOffset.y
    }
    
    // while scrolling this delegate is being called so you may now check which direction your scrollView is being scrolled to
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if self.lastContentOffset < scrollView.contentOffset.y {
            UIView.animate(withDuration: 0.5, delay: 0, options: UIView.AnimationOptions(), animations: {
                self.uploadCertificateButton.isHidden = true
                self.addDescriptionButton.alpha = 0.0
                self.headerViewHeightConstraint.constant = 0
                self.view.layoutIfNeeded()
            }, completion: nil)
        } else if self.lastContentOffset > scrollView.contentOffset.y {
            UIView.animate(withDuration: 0.5, delay: 0, options: UIView.AnimationOptions(), animations: {
                self.uploadCertificateButton.isHidden = false
                if(self.activityId <= 0){
                    self.addDescriptionButton.alpha = 1.0
                }
                self.headerViewHeightConstraint.constant = 254
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
    }
    
    /*func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        if (self.lastContentOffset < scrollView.contentOffset.y) {
             //Code will work without the animation block.I am using animation block incase if you want to set any delay to it.
            UIView.animate(withDuration: 0.2, delay: 0, options: UIView.AnimationOptions(), animations: {
                self.uploadCertificateButton.isHidden = true
                self.headerViewHeightConstraint.constant = 0
                self.view.layoutIfNeeded()
             }, completion: nil)

         } else if self.lastContentOffset < 300 {
            UIView.animate(withDuration: 0.2, delay: 0, options: UIView.AnimationOptions(), animations: {
                self.uploadCertificateButton.isHidden = false
                self.headerViewHeightConstraint.constant = 200
                self.view.layoutIfNeeded()
             }, completion: nil)
        }
    }*/
    
    @objc func editAction(_ sender: UIView) {
        self.imagePicker.present(from: sender)
    }
}

extension VaccineActivityViewController: ImagePickerDelegate {
    func didSelect(image: UIImage?) {
        if(image != nil) {
            self.addDescriptionButton.alpha = 1.0
            self.addDescriptionButton.isHidden = false
            self.uploadCertificateButton.setBackgroundImage(image, for: .normal)
            let clickGesture = UITapGestureRecognizer(target: self, action:  #selector(self.editAction))
            self.editView.addGestureRecognizer(clickGesture)
            self.uploadCertificateButton.setTitle("", for: .normal)
            self.uploadCertificateButton.setImage(nil, for: .normal)
            Utility.setView(view: self.editView, hidden: false)
            self.imageChanged = true
        }
    }
}
