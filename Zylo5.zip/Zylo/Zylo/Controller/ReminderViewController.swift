//
//  ReminderViewController.swift
//  Zylo
//
//  Created by Sathish on 06/06/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit
import DropDown

class ReminderViewController: BaseInnerViewController {

    @IBOutlet weak var medicineRadioButton: RadioButton!
    @IBOutlet weak var vaccineRadioButton: RadioButton!
    @IBOutlet weak var daycareRadioButton: RadioButton!
    @IBOutlet weak var medicineDropDownButton: NiceButton!
    @IBOutlet weak var emailAddressTextFiled: TextField!
    @IBOutlet weak var reminderFromDateTextField: DateTextField!
    @IBOutlet weak var reminderToDateTextField: DateTextField!
    @IBOutlet weak var frequencyInDaysTextField: TextField!
    @IBOutlet weak var reminderInDaysTextField: TextField!
    @IBOutlet weak var reminderFrequencyInDaysTextField: TextField!
    @IBOutlet weak var pushNotificationRadioButton: RadioButton!
    @IBOutlet weak var emailsRadioButton: RadioButton!
    @IBOutlet weak var alexaRadioButton: RadioButton!
    @IBOutlet weak var inappNotificationRadioButton: RadioButton!
    @IBOutlet weak var medicineAdministeredRadioButton: RadioButton!
    @IBOutlet weak var numberOfTimesRadioButton: RadioButton!
    @IBOutlet weak var numberOfTimesTextField: UITextField!
    @IBOutlet weak var dismissedManuallyRadioButton: RadioButton!
    
    var reminderId: Int = 0
    var entries: [ReminderItem] = []
    
    let medicineDropDown = DropDown()
    lazy var dropDowns: [DropDown] = {
        return [
            self.medicineDropDown
        ]
    }()
    
    @IBAction func showMedicineDropDown(_ sender: AnyObject) {
        medicineDropDown.show()
    }
    
    @IBAction func medicineAction(_ sender: RadioButton) {
        if(sender.isSelected) {
            self.vaccineRadioButton.isSelected = false
            self.daycareRadioButton.isSelected = false
            self.medicineDropDownButton.setTitle("Select Medicine", for: .normal)
            self.getMedicineList()
        }
    }
    
    @IBAction func vaccineAction(_ sender: RadioButton) {
        if(sender.isSelected) {
            self.medicineRadioButton.isSelected = false
            self.daycareRadioButton.isSelected = false
            self.medicineDropDownButton.setTitle("Select Vaccine", for: .normal)
            self.getVaccineList()
        }
    }
    
    @IBAction func daycareAction(_ sender: RadioButton) {
        if(sender.isSelected) {
            self.medicineRadioButton.isSelected = false
            self.vaccineRadioButton.isSelected = false
        }
    }
    
    @IBAction func medicineAdministeredAction(_ sender: RadioButton) {
        if(sender.isSelected) {
            self.numberOfTimesRadioButton.isSelected = false
            self.dismissedManuallyRadioButton.isSelected = false
        }
    }
    
    @IBAction func numberOfTimesAction(_ sender: RadioButton) {
        if(sender.isSelected) {
            self.medicineAdministeredRadioButton.isSelected = false
            self.dismissedManuallyRadioButton.isSelected = false
        }
    }
    
    @IBAction func dismissedManuallyAction(_ sender: RadioButton) {
        if(sender.isSelected) {
            self.medicineAdministeredRadioButton.isSelected = false
            self.numberOfTimesRadioButton.isSelected = false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Utility.setupDropdownAppreance()
        
        dropDowns.forEach { $0.dismissMode = .onTap }
        dropDowns.forEach { $0.direction = .any }
        
        self.medicineRadioButton.isSelected = true
        if(self.reminderId > 0) {
            self.getReminder()
            self.setScreenTitle(with: "Update Reminder", color: .black)
        } else {
            self.getMedicineList()
            self.setScreenTitle(with: "Add Reminder", color: .black)
            self.emailAddressTextFiled.text = Utility.getCurrentUserEmail()
        }
        self.numberOfTimesTextField.setBottomBorder(borderColor: .lightGray)
        Utility.setRightNavigationButton(target: self, image: UIImage(named: "save")!, action: #selector(self.didTapSaveButton))
    }
    
    func getMedicineList(medicineId:Int = 0) {
        self.entries = []
        self.showActivityIndicator()
        MedicineService.getMedicine(petId: Utility.getDefaultPetId(), medId: 0, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let medData = try? decoder.decode(MedicineList.self, from: data) else { return }
            if let medLst = medData.data {
                for med in medLst {
                    if(med.isDeleted != nil && med.isDeleted! == false) {
                        var item = ReminderItem()
                        item.itemId = med.medicineId
                        item.itemText = med.medName
                        self.entries.append(item)
                    }
                }
            }
            self.setupDropDown()
            if(medicineId > 0) {
                self.setSelectedItem(list: self.entries, value: medicineId)
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func getVaccineList(vaccineId: Int = 0) {
        self.entries = []
        self.showActivityIndicator()
        VaccineService.getPetVaccine(petId: Utility.getDefaultPetId(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let vacData = try? decoder.decode(PetVaccineList.self, from: data) else { self.hideActivityIndicator(); return }
            if let vacList = vacData.data {
                if let petList = vacList.vaccineAssociation {
                    for vac in petList {
                        if(vac.isActive == true && vac.isDeleted! == false) {
                            var item = ReminderItem()
                            item.itemId = vac.vaccineId
                            item.itemText = vac.vaccineName
                            self.entries.append(item)
                        }
                    }
                }
            }
            self.setupDropDown()
            if(vaccineId > 0) {
                self.setSelectedItem(list: self.entries, value: vaccineId)
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }

    @objc func didTapSaveButton() {
        self.resignFirstResponder()
        if(self.validateInputs()) {
            if(self.reminderId > 0) {
                self.updateReminder()
            } else {
                self.createReminder()
            }
        }
    }
    
    func validateInputs() -> Bool {
        var returnValue: Bool = true
        if(self.medicineDropDown.indexForSelectedRow == nil) {
            if(self.medicineRadioButton.isSelected) {
                self.medicineDropDownButton.errorMessage = "Medicine is required"
            } else {
                self.medicineDropDownButton.errorMessage = "Vaccine is required"
            }
            returnValue = false
        } else {
            self.medicineDropDownButton.errorMessage = ""
        }
        if(self.emailAddressTextFiled.isEmpty()) {
            self.emailAddressTextFiled.errorMessage = "Email address is required"
            returnValue = false
        } else {
            self.emailAddressTextFiled.errorMessage = ""
        }
        if(self.frequencyInDaysTextField.isEmpty()) {
            self.frequencyInDaysTextField.errorMessage = "Frequency(in days) is required"
            returnValue = false
        } else {
            self.frequencyInDaysTextField.errorMessage = ""
        }
        if(self.reminderInDaysTextField.isEmpty()) {
            self.reminderInDaysTextField.errorMessage = "Reminder(in days) is required"
            returnValue = false
        } else {
            self.reminderInDaysTextField.errorMessage = ""
        }
        if(self.reminderFrequencyInDaysTextField.isEmpty()) {
            self.reminderFrequencyInDaysTextField.errorMessage = "Reminder Frequency(in days) is required"
            returnValue = false
        } else {
            self.reminderFrequencyInDaysTextField.errorMessage = ""
        }
        return returnValue
    }
    
    func getParamValues() -> NSDictionary {
        let selectedId: String = String(self.entries[self.medicineDropDown.indexForSelectedRow!].itemId!)
        let data:[String:Any] = ["profile_id": Utility.getDefaultPetId(), "reminder_start_date": self.reminderFromDateTextField.getDate(), "reminder_end_date": self.reminderToDateTextField.getDate(), "reminder_frequency": Int(self.frequencyInDaysTextField.text!) as Any,
            "advance_reminder_day": Int(self.reminderInDaysTextField.text!) as Any,
            "advance_reminder_frequency": Int(self.reminderFrequencyInDaysTextField.text!) as Any,
            "reminder_push_notification": self.pushNotificationRadioButton.isSelected,
            "reminder_alexa": self.alexaRadioButton.isSelected,
            "reminder_email": self.emailsRadioButton.isSelected,
            "reminder_in_app_notification": self.inappNotificationRadioButton.isSelected,
            "reminder_email_address": self.emailAddressTextFiled.text!,
            "medicine_id": (self.medicineRadioButton.isSelected) ? selectedId : "",
            "vaccine_id": (self.vaccineRadioButton.isSelected) ? selectedId : "",
            "dc_id":"",
            "dismiss_manually": self.dismissedManuallyRadioButton.isSelected,
            "dismiss_at_admin": self.medicineAdministeredRadioButton.isSelected,
            "dismiss_after_n_count": self.numberOfTimesRadioButton.isSelected,
            "dismiss_count": Int(self.numberOfTimesTextField.text!) as Any]
        
        let postData:[String:Any] = ["data":data]
            
        return postData as NSDictionary
    }
    
    func createReminder() {
        self.showActivityIndicator()
        ReminderService.addReminder(postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let remData = try? decoder.decode(ReminderResponse.self, from: data) else { return }
            if let remId = remData.reminderId {
                if(remId > 0) {
                    self.navigationController?.popViewController(animated: true)
                    self.showSuccessMessage(message: "Reminder details saved successfully")
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: Constants().reloadReminderDetails), object: nil)
                } else {
                   self.showErrorMessage(message: remData.message!)
               }
            } else {
                self.showErrorMessage(message: "Error in creating reminder details. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func updateReminder() {
        self.showActivityIndicator()
        ReminderService.UpdateReminder(reminderId: self.reminderId, postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let remData = try? decoder.decode(ReminderResponse.self, from: data) else { return }
            if let remId = remData.reminderId {
                if(remId > 0) {
                    self.navigationController?.popViewController(animated: true)
                    self.showSuccessMessage(message: "Reminder details updated successfully")
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: Constants().reloadReminderDetails), object: nil)
                } else {
                   self.showErrorMessage(message: remData.message!)
               }
            } else {
                self.showErrorMessage(message: "Error in updating reminder details. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func setupDropDown() {
        self.medicineDropDown.anchorView = medicineDropDownButton
        self.medicineDropDown.bottomOffset = CGPoint(x: 0, y: self.medicineDropDownButton.bounds.height)
        self.medicineDropDown.dataSource = self.entries.map { "\($0.itemId!) - \($0.itemText!)" }
        // And if you use custom cells:
        self.medicineDropDown.customCellConfiguration = { (index: Index, item: String, cell: DropDownCell) -> Void in
            // Get your model for this cell the same way as above:
            let med = self.entries[index]
            // Setup your custom UI components
            cell.optionLabel.text = med.itemText!
        }
        self.medicineDropDown.selectionAction = { [weak self] (index, item) in
            let selectedItem = self!.entries[index]
            self?.medicineDropDownButton.setTitle(selectedItem.itemText, for: .normal)
        }
    }
    
    func setSelectedItem(list:[ReminderItem], value:Int) {
        for (index, _) in list.enumerated() { self.medicineDropDown.deselectRow(at:index) }
        if let index = list.firstIndex(where: { $0.itemId == value }) {
            self.medicineDropDown.reloadAllComponents()
            self.medicineDropDown.selectRow(index)
            self.medicineDropDown.selectionAction?(index, String(list[index].itemId!))
        }
    }
    
    func getReminder() {
        self.showActivityIndicator()
        ReminderService.getReminder(reminderId: self.reminderId, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let remData = try? decoder.decode(ReminderList.self, from: data) else { return }
            if let remLst = remData.data {
                if(remLst.count > 0) {
                    let rem = remLst[0]
                    if(rem.medicineId != nil && rem.medicineId! > 0) {
                        self.hideActivityIndicator()
                        self.medicineRadioButton.isSelected = true
                        self.vaccineRadioButton.isSelected = false
                        self.daycareRadioButton.isSelected = false
                        self.getMedicineList(medicineId: rem.medicineId!)
                    } else if(rem.vaccineId != nil && rem.vaccineId! > 0) {
                        self.hideActivityIndicator()
                        self.medicineRadioButton.isSelected = false
                        self.vaccineRadioButton.isSelected = true
                        self.daycareRadioButton.isSelected = false
                        self.getVaccineList(vaccineId: rem.vaccineId!)
                    }
                    self.emailAddressTextFiled.text = rem.reminderEmailAddress
                    let startDate = Utility.getDateFromString(dateString: rem.reminderStartDate!)
                    self.reminderFromDateTextField.selectedDate = startDate
                    let endDate = Utility.getDateFromString(dateString: rem.reminderEndDate!)
                    self.reminderToDateTextField.selectedDate = endDate
                    self.frequencyInDaysTextField.text = String(rem.reminderFrequency!)
                    self.reminderInDaysTextField.text = String(rem.advanceReminderDay!)
                    self.reminderFrequencyInDaysTextField.text = String(rem.advanceReminderFrequency!)
                    self.medicineAdministeredRadioButton.isSelected = rem.dismissAtAdmin!
                    self.numberOfTimesRadioButton.isSelected = rem.dismissAfterNCount!
                    if(rem.dismissCount != nil && rem.dismissCount! > 0) {
                        self.numberOfTimesTextField.text = String(rem.dismissCount!)
                    }
                    self.dismissedManuallyRadioButton.isSelected = rem.dismissManually!
                    self.pushNotificationRadioButton.isSelected = rem.reminderPushNotification!
                    self.emailsRadioButton.isSelected = rem.reminderEmail!
                    self.alexaRadioButton.isSelected = rem.reminderAlexa!
                    self.inappNotificationRadioButton.isSelected = rem.reminderInAppNotification!
                }
            } else if remData.status != 200 {
                self.showErrorMessage(message: "Error in getting reminder data. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
}
