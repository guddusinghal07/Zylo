//
//  ProfileViewController.swift
//  Zylo
//
//  Created by Sathish on 05/06/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class ProfileViewController: BaseViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var profileImage: ImageView!
    @IBOutlet weak var collection: UICollectionView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var dobLabel: UILabel!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var logoutButton: UIButton!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.tintColor = UIColor.black
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setScreenTitle(with: "Profile", color: .black)

        self.collection.delegate = self
        self.collection.dataSource = self
        self.collection.backgroundColor = .clear
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 20
        layout.minimumInteritemSpacing = 20
        collection.setCollectionViewLayout(layout, animated: true)
        
        Utility.setRightNavigationButton(target: self, image: UIImage(named: "edit")!, action: #selector(self.editButtonAction))
        
        self.logoutButton.layer.cornerRadius = 20.0
        self.logoutButton.layer.masksToBounds = true
        
        self.profileImage.loadUserImage()
        self.getUser()
        
        NotificationCenter.default.addObserver(self, selector: #selector(loadUser), name: NSNotification.Name(rawValue: Constants().reloadUser), object: nil)
    }
    
    @objc func loadUser(notification: NSNotification){
        //load data here
        self.profileImage.loadUserImage()
        self.getUser()
    }
    
    @objc func editButtonAction() {
        let vc : UserProfileViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "UserProfile") as! UserProfileViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func getUser() {
        self.showActivityIndicator()
        UserService.getUser(useOldData: false, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let UserData = try? decoder.decode(UserData.self, from: data) else { return }
            if let user = UserData.data {
                if(user.isDeleted! == false) {
                    self.emailLabel.text = user.userEmail
                    self.nameLabel.text = user.userProfileName
                    if let usrDOB = user.userDob {
                        let DOB = Utility.getDateFromString(dateString: usrDOB)
                        let dateformatter = DateFormatter()
                        dateformatter.dateStyle = .medium
                        self.dobLabel.text = dateformatter.string(from: DOB)
                    }
                    self.phoneLabel.text = user.userPhoneNumber
                    let address: String = "\(user.userAddress!), \(user.userCity!), \(user.userState!), \(user.userCountry!), \(user.userZipcode!)"
                    self.addressLabel.text = address
                }
            } else {
                self.showErrorMessage(message: "Error in getting user data. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 20.0, left: 25.0, bottom: 20.0, right: 25.0)//here your custom value for spacing
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let lay = collectionViewLayout as! UICollectionViewFlowLayout
        let widthPerItem = collectionView.frame.width / 2 - (lay.minimumInteritemSpacing * 2.0)
        return CGSize(width: widthPerItem, height: 170.0)
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: ActivityCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProfileCell", for: indexPath) as! ActivityCollectionViewCell
        cell.layer.cornerRadius = 20
        cell.layer.borderWidth = 1.0
        cell.layer.borderColor = UIColor.white.cgColor

        cell.layer.backgroundColor = UIColor.white.cgColor
        cell.layer.shadowColor = UIColor.white.cgColor
        cell.layer.shadowOffset = CGSize(width: 1.0, height: 2.0)
        cell.layer.shadowRadius = 2.0
        cell.layer.shadowOpacity = 1.0
        cell.layer.masksToBounds = false
        
        if indexPath.row == 0 {
            cell.backgroundColor = UIColor(red: 84.0/255.0, green: 167.0/255.0, blue: 217.0/255.0, alpha: 1.0)
            cell.activityImage.image = UIImage(named: "profile-pet")
            cell.activityLabel.text = "My Pets"
        } else if indexPath.row == 1 {
            cell.backgroundColor = UIColor(red: 98.0/255.0, green: 209.0/255.0, blue: 229.0/255.0, alpha: 1.0)
            cell.activityImage.image = UIImage(named: "profile-settings")
            cell.activityLabel.text = "Settings"
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if(indexPath.row == 0) {
            let vc : PetProfileViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "PetProfileNew") as! PetProfileViewController
            self.navigationController?.pushViewController(vc, animated: true)
        } else if (indexPath.row == 1) {
            let vc : SettingsViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "Settings") as! SettingsViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func logoutAction(_ sender: UIButton) {
        self.logoutUser()
    }
}
