//
//  PetProfileViewController.swift
//  Zylo
//
//  Created by Sathish on 21/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class PetProfileViewController: BaseTabViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet var collection: UICollectionView!
    @IBOutlet var infoView: UIView!
    @IBOutlet var addPetButton: NiceButton!
    var petList: [PetProfile] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.collection.delegate = self
        self.collection.dataSource = self
        self.collection.backgroundColor = .clear
        
        Utility.setView(view: self.infoView, hidden: true)
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical //.horizontal
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 10
        collection.setCollectionViewLayout(layout, animated: true)
    }
    
    @IBAction func addPetAction(_ sender: UIButton) {
        self.resignFirstResponder()
        let vc : PetDetailsNewViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "PetDetailsNew") as! PetDetailsNewViewController
        vc.petProfileId = 0
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.loadCollection()
    }
    
    func loadCollection() {
        self.petList = []
        self.getPetFromServer()
    }
        
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        if (size.width != self.view.frame.size.width) {
            DispatchQueue.main.async {
                self.collection.reloadData()
            }
        }
    }
    
    func getPetFromServer() {
        self.showActivityIndicator()
        PetProfileService.getPetProfile(petId: 0, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let petData = try? decoder.decode(PetProfileData.self, from: data) else { return }
            if let petLst = petData.data {
                for pet in petLst {
                    if(pet.isDeleted != nil && pet.isDeleted! == false) {
                        self.petList.append(pet)
                    }
                    if(pet.isDefault!) {
                        Utility.setDefaultPet(petId: pet.profileId!, petName: pet.profilePetName!)
                    }
                }
                self.collection.reloadData()
                if(self.petList.count <= 0) {
                    Utility.setView(view: self.infoView, hidden: false)
                } else {
                    Utility.setView(view: self.infoView, hidden: true)
                }
            } else {
                self.showErrorMessage(message: "Error in getting pet data. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
        
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 10.0, left: 10.0, bottom: 10.0, right: 10.0)//here your custom value for spacing
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let lay = collectionViewLayout as! UICollectionViewFlowLayout
        let widthPerItem = collectionView.frame.width / 2 - (lay.minimumInteritemSpacing * 2.0)
        return CGSize(width: widthPerItem, height: widthPerItem)
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return petList.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: PetCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "profileCell", for: indexPath) as! PetCollectionViewCell
        //cell.backgroundColor = UIColor.red
        cell.layer.cornerRadius = 15
        cell.layer.borderWidth = 1.0
        cell.layer.borderColor = UIColor.lightGray.cgColor

        cell.layer.backgroundColor = UIColor.white.cgColor
        cell.layer.shadowColor = UIColor.gray.cgColor
        cell.layer.shadowOffset = CGSize(width: 1.0, height: 2.0)
        cell.layer.shadowRadius = 2.0
        cell.layer.shadowOpacity = 1.0
        cell.layer.masksToBounds = false
                
        let pet:PetProfile = petList[indexPath.row]
        cell.titleLabel.text = pet.profilePetName
        cell.titleLabel.numberOfLines = 0
        cell.titleLabel.lineBreakMode = .byWordWrapping
        cell.titleLabel.preferredMaxLayoutWidth = cell.frame.size.width - 20.0
        cell.typeLabel.text = pet.profilePetType
        cell.typeLabel.numberOfLines = 0
        cell.typeLabel.lineBreakMode = .byWordWrapping
        cell.typeLabel.preferredMaxLayoutWidth = cell.frame.size.width - 20.0
        cell.petProfileId = pet.profileId!
        cell.petImage.loadPetImage(petId: pet.profileId!)
        cell.defaultView.isHidden = !pet.isDefault!
        cell.deleteButton.layer.setValue(cell.petProfileId, forKey: "profileId")
        cell.deleteButton.addTarget(self, action: #selector(didTapDeleteButton), for: UIControl.Event.touchUpInside)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell : PetCollectionViewCell = collectionView.cellForItem(at: indexPath)! as! PetCollectionViewCell
        let vc : PetDetailsNewViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "PetDetailsNew") as! PetDetailsNewViewController
        vc.petProfileId = cell.petProfileId
        self.navigationController?.pushViewController(vc, animated: true)
    }

    @objc func didTapDeleteButton(sender:UIButton){
        self.resignFirstResponder()
        let dialogMessage = UIAlertController(title: "Confirm", message: "Are you sure you want to delete this pet profile?", preferredStyle: .alert)
        let yes = UIAlertAction(title: "Yes", style: .default, handler: { (action) -> Void in
            let petId : Int = (sender.layer.value(forKey: "profileId")) as! Int
            self.deletePetProfile(petProfileId: petId)
        })
        let no = UIAlertAction(title: "No", style: .cancel) { (action) -> Void in
            print("Cancel button tapped")
        }
        dialogMessage.addAction(yes)
        dialogMessage.addAction(no)
        self.present(dialogMessage, animated: true, completion: nil)
    }
    
    func deletePetProfile(petProfileId:Int) {
        self.showActivityIndicator()
        PetProfileService.DeletePet(petId: petProfileId, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let petData = try? decoder.decode(UpdatePet.self, from: data) else { return }
            if let status = petData.status {
                self.hideActivityIndicator()
                if(status == 200) {
                    self.showSuccessMessage(message: "Pet profile details deleted successfully")
                    self.loadCollection()
                }
            } else {
                self.showErrorMessage(message: "Error in deleting pet profile. Please try again later.")
                self.hideActivityIndicator()
            }
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
}
