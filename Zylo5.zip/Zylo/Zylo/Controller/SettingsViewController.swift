//
//  SettingsViewController.swift
//  Zylo
//
//  Created by Sathish on 27/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class SettingsViewController: BaseInnerViewController {
    
    @IBOutlet weak var deleteBtn: UIButton!
    @IBOutlet weak var vaccineBtn: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setScreenTitle(with: "Settings", color: .black)
        
        self.deleteBtn.layer.masksToBounds = true
        self.deleteBtn.layer.cornerRadius = 20
        
        self.vaccineBtn.layer.masksToBounds = true
        self.vaccineBtn.layer.cornerRadius = 20
    }
    
    @IBAction func vaccineButtonTapAction(_ sender: UIButton){
         let vc : VaccineAssociationViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "VaccineAssociation") as! VaccineAssociationViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func deleteProfileAction(_ sender: UIButton) {
        self.resignFirstResponder()
        let dialogMessage = UIAlertController(title: "Confirm", message: "Are you sure you want to delete this user profile?", preferredStyle: .alert)
        let yes = UIAlertAction(title: "Yes", style: .default, handler: { (action) -> Void in
            self.deleteUserProfile()
        })
        let no = UIAlertAction(title: "No", style: .cancel) { (action) -> Void in
            print("Cancel button tapped")
        }
        dialogMessage.addAction(yes)
        dialogMessage.addAction(no)
        self.present(dialogMessage, animated: true, completion: nil)
    }
    
    func deleteUserProfile() {
        self.showActivityIndicator()
        UserService.DeleteUser(onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let userData = try? decoder.decode(SaveUser.self, from: data) else { return }
            if let status = userData.status {
                if(status == 200) {
                    self.logoutUser()
                    self.showSuccessMessage(message: "User details deleted successfully")
                }
            } else {
                self.showErrorMessage(message: "Error in deleting user profile. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
}
