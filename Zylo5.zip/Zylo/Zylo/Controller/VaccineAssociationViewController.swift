//
//  VaccineAssociationViewController.swift
//  Zylo
//
//  Created by Sathish on 15/04/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class VaccineAssociationViewController: BaseInnerViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var tableView: UITableView!
    var entries: [VaccineAdditional] = []
    var pvList: [PetVaccine] = []
    var associationId: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setScreenTitle(with: "Vaccine Association", color: .black)
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.separatorColor = .clear
        
        Utility.setRightNavigationButton(target: self, image: UIImage(named: "save")!, action: #selector(self.saveButtonAction))
        
        entries = []
        self.getPetVaccine()
    }
    
    func getPetVaccine() {
        self.showActivityIndicator()
        VaccineService.getPetVaccine(petId: Utility.getDefaultPetId(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let pData = try? decoder.decode(PetVaccineList.self, from: data) else { return }
            if let pList = pData.data {
                if let petList = pList.vaccineAssociation {
                    self.pvList = petList
                    if(self.pvList.count > 0){
                        self.associationId = 1
                    }
                }
            }
            self.getAllVaccines()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func getAllVaccines() {
        //self.showActivityIndicator()
        VaccineService.getVaccine(vaccineId: 0, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let vacData = try? decoder.decode(VaccineList.self, from: data) else { return }
            if let vacList = vacData.data {
                for vac in vacList {
                    if(vac.isDeleted != nil && vac.isDeleted! == false) {
                        let va = VaccineAdditional()
                        va.vaccineId = vac.vaccineId
                        va.vaccineName = vac.vaccineName
                        va.vaccineAdminFreq = vac.vaccineAdminFreq
                        va.isDeleted = vac.isDeleted
                        va.isRabies = vac.isRabies
                        if(self.pvList.count > 0){
                            if let pv = self.pvList.firstIndex(where: {$0.vaccineId == vac.vaccineId}) {
                                va.isSelected = self.pvList[pv].isActive
                            } else {
                                va.isSelected = false
                            }
                        } else {
                            va.isSelected = false
                        }
                        self.entries.append(va)
                    }
                }
                self.tableView.reloadData()
            } else if vacData.status != 200 {
                self.showErrorMessage(message: "Error in getting pet data. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    @objc func saveButtonAction() {
        self.resignFirstResponder()
        if(self.associationId > 0) {
            self.updateVaccineAssociation()
        } else {
            self.createVaccineAssociation()
        }
    }
    
    func createVaccineAssociation() {
        self.showActivityIndicator()
        VaccineService.addVaccineAssociation(petId: Utility.getDefaultPetId(), postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let vacData = try? decoder.decode(associationResponse.self, from: data) else { return }
            if(vacData.status == 200) {
                 self.showSuccessMessage(message: "Vaccine association details saved successfully")
             } else {
                self.showErrorMessage(message: vacData.message!)
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func getParamValues() -> NSDictionary {
        var vaccineData = [[String: Any]]()
        for i in 0..<entries.count {
            let vac = entries[i]
            vaccineData.append(["vaccine_id": String(vac.vaccineId!), "is_active": vac.isSelected as Any])
        }
        let data:[String:Any] = ["vaccine_association_data":vaccineData]
        let postData:[String:Any] = ["data":data]
            
        return postData as NSDictionary
    }
    
    func updateVaccineAssociation() {
        self.showActivityIndicator()
        VaccineService.UpdateVaccineAssociation(petId: Utility.getDefaultPetId(), postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let vacData = try? decoder.decode(associationResponse.self, from: data) else { return }
            if(vacData.status == 200) {
                 self.showSuccessMessage(message: "Vaccine association details updated successfully")
             } else {
                self.showErrorMessage(message: vacData.message!)
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.section == 0) {
            return 280.0
        } else {
            return 100
        }
    }

    public func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }

    public func tableView(_ tableView: UITableView, numberOfRowsInSection sectionIndex: Int) -> Int {
        if(sectionIndex == 0) {
            return 1
        } else {
            return entries.count
        }
    }

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if(indexPath.section == 0) {
            let cell: VaccineAssociationTableViewCell = tableView.dequeueReusableCell(withIdentifier: "VaccineAssociationCell", for: indexPath) as! VaccineAssociationTableViewCell
            cell.selectionStyle = .none
            cell.titleLabel.text = "Establish Vaccine Association for \(Utility.getDefaultPetName())"
            cell.titleLabel.lineBreakMode = .byWordWrapping
            cell.titleLabel.numberOfLines = 0
            cell.titleLabel.preferredMaxLayoutWidth = view.frame.size.width - 40.0
            cell.selectionStyle = .none
            if(Utility.getDefaultPetId() > 0) {
                cell.petImageView.loadPetImage(petId: Utility.getDefaultPetId())
            }
            return cell
        } else {
            let cell: VaccineAssociationDetailTableViewCell = tableView.dequeueReusableCell(withIdentifier: "VaccineAssociationDetailCell", for: indexPath) as! VaccineAssociationDetailTableViewCell
            cell.selectionStyle = .none
            
            let vac:VaccineAdditional = entries[indexPath.row]
            cell.associationId = vac.vaccineId!
            cell.vaccineLabel.text = vac.vaccineName
            cell.associationSwitch.isOn = vac.isSelected!
            // the callback updates the model and is called when the value of the switch changes
            cell.callback = { newValue in
                 vac.isSelected = newValue
            }
            cell.selectionStyle = .none
            return cell
        }
    }
}
