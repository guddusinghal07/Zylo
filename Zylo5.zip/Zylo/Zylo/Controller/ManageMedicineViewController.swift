//
//  ManageMedicineViewController.swift
//  Zylo
//
//  Created by Sathish on 14/04/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class ManageMedicineViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var infoView: UIView!
    
    var medList: [Medicine] = []
    var frequencyList : [Frequency] = []
    
    var calendar = Calendar(identifier: Calendar.Identifier.iso8601)
    var selectedDate: Date! = Date()
    var selectedMedicineId: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setScreenTitle(with: "Manage Medicine")
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.separatorColor = .clear
        self.tableView.backgroundColor = UIColor.clear
        
        self.infoView.backgroundColor = .white
        Utility.setView(view: self.infoView, hidden: true)
        Utility.setRightNavigationButton(target: self, image: UIImage(named: "add")!, action: #selector(self.addButtonAction))
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.loadMedicineList()
    }
    
    @objc func loadList(notification: NSNotification){
        //load data here
        self.loadMedicineList()
    }
    
    func loadMedicineList() {
        self.medList = []
        self.getMedicineFromServer()
    }
    
    func getMedicineFromServer() {
        self.showActivityIndicator()
        MedicineService.getMedicine(petId: Utility.getDefaultPetId(), medId: 0, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let medData = try? decoder.decode(MedicineList.self, from: data) else { return }
            if let medLst = medData.data {
                for med in medLst {
                    if(med.isDeleted != nil && med.isDeleted! == false) {
                        self.medList.append(med)
                    }
                }
            } else if medData.status != 200 {
                self.showErrorMessage(message: "Error in getting pet data. Please try again later.")
            }
            if(self.medList.count <= 0) {
                Utility.setView(view: self.infoView, hidden: false)
            } else {
                Utility.setView(view: self.infoView, hidden: true)
            }
            self.getFrequencyDataFromServer()
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    /* Get Frequency Data from Server*/
    func getFrequencyDataFromServer() {
        MedicineService.getFrequencyData(onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let frequencyData = try? decoder.decode(FrequencyList.self, from: data) else { return }
            if let frequencyLst = frequencyData.data {
                for frequency in frequencyLst {
                        self.frequencyList.append(frequency)
                }
                self.tableView.reloadData()
            } else if frequencyData.status != 200 {
                self.showErrorMessage(message: "Error in getting pet data. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            print("Failed to get the data from the server")
        })
    }
    
    @objc func addButtonAction() {
        self.LoadMedicineEntry(medicineId: 0)
    }
    
    private func LoadMedicineEntry(medicineId: Int) {
        self.resignFirstResponder()
        let vc : MedicineDetailsViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "MedicineDetails") as! MedicineDetailsViewController
        vc.medicineId = medicineId
        vc.frequencyList = self.frequencyList
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

    public func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    public func tableView(_ tableView: UITableView, numberOfRowsInSection sectionIndex: Int) -> Int {
        return medList.count
    }

    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell: MedicineListTableViewCell = tableView.cellForRow(at: indexPath) as! MedicineListTableViewCell
        self.LoadMedicineEntry(medicineId: cell.medicineId)
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: MedicineListTableViewCell = tableView.dequeueReusableCell(withIdentifier: "MedicineList", for: indexPath) as! MedicineListTableViewCell
        
        let med:Medicine = medList[indexPath.row]
        cell.medNameLabel.text = med.medName!
        cell.brandLabel.text = med.medBrand! + " / " + med.medCategory!
        for frequencyData in self.frequencyList{
            if frequencyData.frequencyDays == med.medAdminFrequency!{
                cell.frequencyLabel.text = frequencyData.frequencyDaysValue
                break
            }
        }
       // cell.frequencyLabel.text = "\(med.medAdminFrequency!) day(s)"
        let dt = Utility.getDateFromString(dateString: med.lastAdministrationDate!)
        let dateformatter = DateFormatter()
        dateformatter.dateStyle = .medium
        let lastAdministrationDate: String = dateformatter.string(from: dt)
        cell.lastAdministrationLabel.attributedText = "Last Administration: \(lastAdministrationDate)".attributedText(boldString: lastAdministrationDate, font: cell.lastAdministrationLabel.font)
        let nextAdministrationDate: String = dateformatter.string(from: dt.addDay(n: med.medAdminFrequency!))
        cell.nextAdministrationLabel.attributedText = "Next Administration: \(nextAdministrationDate)".attributedText(boldString: nextAdministrationDate, font: cell.nextAdministrationLabel.font)
        cell.medicineId = med.medicineId!
        cell.selectionStyle = .none
        
        cell.deleteButton.layer.setValue(cell.medicineId, forKey: "medicineId")
        cell.deleteButton.addTarget(self, action: #selector(didTapDeleteButton), for: UIControl.Event.touchUpInside)
        
        cell.editButton.layer.setValue(cell.medicineId, forKey: "medicineId")
        cell.editButton.addTarget(self, action: #selector(didTapEditButton), for: UIControl.Event.touchUpInside)
        
        cell.addAdministrationLogButton.layer.setValue(cell.medicineId, forKey: "medicineId")
        cell.addAdministrationLogButton.addTarget(self, action: #selector(didTapAddActivity), for: UIControl.Event.touchUpInside)
        
        cell.showAdministrationLogButton.layer.setValue(cell.medicineId, forKey: "medicineId")
        cell.showAdministrationLogButton.addTarget(self, action: #selector(didTapShowActivityButton), for: UIControl.Event.touchUpInside)
        
        return cell
    }
    
    @objc func didTapEditButton(sender:UIButton) {
        self.resignFirstResponder()
        let medId : Int = (sender.layer.value(forKey: "medicineId")) as! Int
        self.LoadMedicineEntry(medicineId: medId)
    }
    
    @objc func didTapAddActivity(sender:UIButton) {
        self.resignFirstResponder()
        self.selectedMedicineId = (sender.layer.value(forKey: "medicineId")) as! Int
        self.showCalendar()
    }
    
    @objc func didTapShowActivityButton(sender:UIButton){
        self.resignFirstResponder()
        let medId : Int = (sender.layer.value(forKey: "medicineId")) as! Int
        let vc : MedicineAdministrationListViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "MedicineAdministrationList") as! MedicineAdministrationListViewController
        vc.medicineId = medId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func didTapDeleteButton(sender:UIButton){
        self.resignFirstResponder()
        let dialogMessage = UIAlertController(title: "Confirm", message: "Are you sure you want to delete this medicine details?", preferredStyle: .alert)
        let yes = UIAlertAction(title: "Yes", style: .default, handler: { (action) -> Void in
            let medId : Int = (sender.layer.value(forKey: "medicineId")) as! Int
            self.deleteMedicine(medId: medId)
        })
        let no = UIAlertAction(title: "No", style: .cancel) { (action) -> Void in
            print("Cancel button tapped")
        }
        dialogMessage.addAction(yes)
        dialogMessage.addAction(no)
        self.present(dialogMessage, animated: true, completion: nil)
    }
    
    func deleteMedicine(medId:Int) {
        self.showActivityIndicator()
        MedicineService.DeleteMedicine(petId: Utility.getDefaultPetId(), medId: medId, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let medData = try? decoder.decode(MedicineResponse.self, from: data) else { return }
            if let status = medData.status {
                self.hideActivityIndicator()
                if(status == 200) {
                    self.showSuccessMessage(message: "Medicine details deleted successfully")
                    self.loadMedicineList()
                }
            } else {
                self.showErrorMessage(message: "Error in deleting medicine details. Please try again later.")
                self.hideActivityIndicator()
            }
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func showCalendar() {
        let xibView = Bundle.main.loadNibNamed("CalendarPopUp", owner: nil, options: nil)?[0] as! CalendarPopUp
        xibView.calendarDelegate = self
        xibView.selected = selectedDate
        PopupContainer.generatePopupWithView(xibView).show(self.view)
    }
}

extension ManageMedicineViewController: CalendarPopUpDelegate {
    func dateChaged(date: Date) {
        selectedDate = date
        self.createMedicineAdministration()
    }
    
    func getParamValues() -> NSDictionary {
        let data:[String:Any] = ["medicine_id":String(self.selectedMedicineId), "medicine_administration_date":self.selectedDate.getDate()]
        let postData:[String:Any] = ["data":data]
        return postData as NSDictionary
    }
    
    func createMedicineAdministration() {
        self.showActivityIndicator()
        MedicineService.addMedicineAdministration(petId: Utility.getDefaultPetId() , postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let adminData = try? decoder.decode(MedicineAdministration.self, from: data) else { return }
            if(adminData.status == 200) {
                if(adminData.activityId! > 0) {
                    self.hideActivityIndicator()
                     self.showSuccessMessage(message: "Medicine administration details saved successfully")
                    self.loadMedicineList()
                 } else {
                    self.hideActivityIndicator()
                    self.showErrorMessage(message: adminData.message!)
                }
            } else if(adminData.status == 400) {
                self.hideActivityIndicator()
                self.showErrorMessage(message: adminData.message!)
            } else {
                self.hideActivityIndicator()
                self.showErrorMessage(message: "Error in creating medicine administration details. Please try again later.")
            }
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
}
