//
//  DashboardViewController.swift
//  Zylo
//
//  Created by Sathish on 18/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class DashboardViewController: BaseTabViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet var collection: UICollectionView!
    @IBOutlet weak var heightConstraints: NSLayoutConstraint!
    var petList: [PetProfile] = []
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.loadCollection()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.collection.delegate = self
        self.collection.dataSource = self
        self.collection.backgroundColor = .clear
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 10
        collection.setCollectionViewLayout(layout, animated: true)
    }
    
    func loadCollection() {
        self.petList = []
        self.getPetFromServer()
    }
        
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        if (size.width != self.view.frame.size.width) {
            DispatchQueue.main.async {
                self.collection.reloadData()
            }
        }
    }
    
    func getPetFromServer() {
        self.showActivityIndicator()
        PetProfileService.getPetProfile(petId: 0, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let petData = try? decoder.decode(PetProfileData.self, from: data) else { return }
            if let petLst = petData.data {
                for pet in petLst {
                    if(pet.isDeleted != nil && pet.isDeleted! == false) {
                        self.petList.append(pet)
                        if(pet.isDefault!) {
                            Utility.setDefaultPet(petId: pet.profileId!, petName: pet.profilePetName!)
                        }
                    }
                }
                self.collection.reloadData()
            } else {
                self.showErrorMessage(message: "Error in getting pet data. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
        
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 10.0, left: 10.0, bottom: 10.0, right: 10.0)//here your custom value for spacing
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let lay = collectionViewLayout as! UICollectionViewFlowLayout
        let widthPerItem = collectionView.frame.width / 2 - (lay.minimumInteritemSpacing * 2.0)
        self.heightConstraints.constant = widthPerItem
        return CGSize(width: widthPerItem, height: widthPerItem)
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return petList.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: PetCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "profileCell", for: indexPath) as! PetCollectionViewCell
        
        let pet:PetProfile = petList[indexPath.row]
        cell.titleLabel.text = pet.profilePetName
        cell.titleLabel.numberOfLines = 0
        cell.titleLabel.lineBreakMode = .byWordWrapping
        cell.titleLabel.preferredMaxLayoutWidth = cell.frame.size.width - 20.0
        cell.typeLabel.text = pet.profilePetType
        cell.typeLabel.numberOfLines = 0
        cell.typeLabel.lineBreakMode = .byWordWrapping
        cell.typeLabel.preferredMaxLayoutWidth = cell.frame.size.width - 20.0
        cell.petProfileId = pet.profileId!
        cell.petImage.loadPetImage(petId: pet.profileId!)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        /*let cell : PetCollectionViewCell = collectionView.cellForItem(at: indexPath)! as! PetCollectionViewCell
        let vc : PetDetailsNewViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "PetDetailsNew") as! PetDetailsNewViewController
        vc.petProfileId = cell.petProfileId
        self.navigationController?.pushViewController(vc, animated: true)*/
    }
}
