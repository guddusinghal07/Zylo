//
//  ActivityViewController.swift
//  Zylo
//
//  Created by Sathish on 13/05/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class ActivityViewController: BaseTabViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet var collection: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.collection.delegate = self
        self.collection.dataSource = self
        self.collection.backgroundColor = .clear
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical //.horizontal
        layout.minimumLineSpacing = 20
        layout.minimumInteritemSpacing = 20
        collection.setCollectionViewLayout(layout, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 20.0, left: 25.0, bottom: 20.0, right: 25.0)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let lay = collectionViewLayout as! UICollectionViewFlowLayout
        let widthPerItem = collectionView.frame.width / 2 - (lay.minimumInteritemSpacing * 2.0)
        return CGSize(width: widthPerItem, height: widthPerItem)
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: ActivityCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ActivityCell", for: indexPath) as! ActivityCollectionViewCell
        cell.layer.cornerRadius = 20
        cell.layer.borderWidth = 1.0
        cell.layer.borderColor = UIColor.lightGray.cgColor

        cell.layer.backgroundColor = UIColor.white.cgColor
        cell.layer.shadowColor = UIColor.gray.cgColor
        cell.layer.shadowOffset = CGSize(width: 1.0, height: 2.0)
        cell.layer.shadowRadius = 2.0
        cell.layer.shadowOpacity = 1.0
        cell.layer.masksToBounds = false
        
        cell.activityLabel.font = UIFont.openSansBoldFontOfSize(size: 16.0)
        
        if indexPath.row == 0 {
            cell.backgroundColor = UIColor(red: 84.0/255.0, green: 167.0/255.0, blue: 217.0/255.0, alpha: 1.0)
            cell.activityImage.image = UIImage(named: "activity-medicine")
            cell.activityLabel.text = "Medicine"
        } else if indexPath.row == 1 {
            cell.backgroundColor = UIColor(red: 98.0/255.0, green: 209.0/255.0, blue: 229.0/255.0, alpha: 1.0)
            cell.activityImage.image = UIImage(named: "activity-vaccination")
            cell.activityLabel.text = "Vaccination"
        } else if indexPath.row == 2 {
            cell.backgroundColor = UIColor(red: 237.0/255.0, green: 193.0/255.0, blue: 132.0/255.0, alpha: 1.0)
            cell.activityImage.image = UIImage(named: "activity-daycare")
            cell.activityLabel.text = "Daycare"
        } else {
            cell.backgroundColor = UIColor(red: 237.0/255.0, green: 96.0/255.0, blue: 96.0/255.0, alpha: 1.0)
            cell.activityImage.image = UIImage(named: "activity-reminder")
            cell.activityLabel.text = "Reminder"
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if(indexPath.row == 0) {
            /*let vc : MedicineDashboardViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "MedicineDashboard") as! MedicineDashboardViewController
            self.navigationController?.pushViewController(vc, animated: true)*/
            let vc : ManageMedicineViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "ManageMedicineNew") as! ManageMedicineViewController
            self.navigationController?.pushViewController(vc, animated: true)
        } else if (indexPath.row == 1) {
            let vc : ScrollableTabViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "ScrollableTabViewController") as! ScrollableTabViewController
            self.navigationController?.pushViewController(vc, animated: true)
        } else if (indexPath.row == 2) {
            let vc : DaycareViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "Daycare") as! DaycareViewController
            //let vc: DaycareNewViewController = DaycareNewViewController()
            self.navigationController?.pushViewController(vc, animated: true)
        } else if (indexPath.row == 3) {
            let vc: ReminderListViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "ReminderList") as! ReminderListViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}
