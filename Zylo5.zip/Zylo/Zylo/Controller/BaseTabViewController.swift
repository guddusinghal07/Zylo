//
//  BaseTabViewController.swift
//  Zylo
//
//  Created by Sathish on 12/05/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class BaseTabViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        Utility.setUserNameNavigationItem(target: self)
    }

}
