//
//  HomeViewController.swift
//  Zylo
//
//  Created by Sathish on 10/05/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class HomeViewController: UITabBarController, UITabBarControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        // Do any additional setup after loading the view.
        self.tabBar.layer.masksToBounds = true
        self.tabBar.isTranslucent = true
        self.tabBar.barStyle = .default
        self.tabBar.layer.cornerRadius = 20
        
        UserDefaults.standard.set(true, forKey: "firstTimeLoggedIn")
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.tabBar.invalidateIntrinsicContentSize()
    }

    // UITabBarControllerDelegate
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {

        let selectedIndex = tabBarController.viewControllers?.firstIndex(of: viewController)!
        switch selectedIndex {
        case 0:
            let vc : DashboardViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "DashboardNew") as! DashboardViewController
            self.navigationController?.pushViewController(vc, animated: true)
        case 1:
            let vc : PetProfileViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "PetProfileNew") as! PetProfileViewController
            self.navigationController?.pushViewController(vc, animated: true)
        case 2:
            let vc : ActivityViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "Activity") as! ActivityViewController
            self.navigationController?.pushViewController(vc, animated: true)
        case 3:
            let vc : NotificationViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "Notification") as! NotificationViewController
            self.navigationController?.pushViewController(vc, animated: true)
        default:
            break
        }
    }
}
