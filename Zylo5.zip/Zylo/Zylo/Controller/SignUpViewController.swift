//
//  SignUpViewController.swift
//  Zylo
//
//  Created by Sathish on 13/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit
import Firebase
import GoogleSignIn

class SignUpViewController: BaseViewController, GIDSignInDelegate {

    @IBOutlet weak var googleBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        GIDSignIn.sharedInstance().clientID = FirebaseApp.app()?.options.clientID
        GIDSignIn.sharedInstance().delegate = self
        
        self.googleBtn.layer.masksToBounds = true
        self.googleBtn.layer.cornerRadius = 20
        
        // Do any additional setup after loading the view.
    }
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if let error = error {
            print(error.localizedDescription)
            return
        }
        //self.showLoading(title: "Authenticating, please wait")
        guard (user.authentication) != nil else { return }
        
        let userToken: String = user.userID
        let fullName: String = user.profile.name
        let givenName: String = user.profile.givenName
        let familyName: String = user.profile.familyName
        let email: String = user.profile.email
        var base64String = ""
        if user.profile.hasImage {
            let imageUrl = user.profile.imageURL(withDimension: 120)
            Utility.getImage(from: imageUrl!, onSuccess: {(image) in
                base64String = image.toBase64(format: .png)!
            })
        }
        
        self.showActivityIndicator()
        Utility.setLoggedInUserDetails(userToken: userToken, userName: fullName, givenName: givenName, familyName: familyName, email: email)
        
        let userData: [String: String] = ["user_email":email, "user_first_name":givenName, "user_last_name":familyName, "user_profile_name" :fullName, "user_dob":"", "user_phone_number":"", "user_address":"", "user_city":"", "user_state":"", "user_country":"", "user_zipcode":""]
        let postData: [String: Any] = ["data":userData, "image_data":base64String]
        
        UserService.CreateUser(postData: postData as NSDictionary, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let UserData = try? decoder.decode(SaveUser.self, from: data) else { return }
            if let userId = UserData.userId {
                Utility.setLoggedInUserId(userId: userId)
                Utility.setLoggedInUserImageUrl(userImageUrl: "https://zylo-app-data.s3.amazonaws.com/zylo_app_data/\(userId)/profile_image")
                self.navigateToDashboard()
            } else {
                self.showErrorMessage(message: "Error in creating user data. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
        //Utility.setPetProfileToShow() // todo: this need to be removed with API integration
    }
        
    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!, withError error: Error!) {
        if let error = error {
            print(error.localizedDescription)
            return
        }
        
        let firebaseAuth = Auth.auth()
        do {
          try firebaseAuth.signOut()
        } catch let signOutError as NSError {
          print ("Error signing out: %@", signOutError)
        }
    }
    
    @IBAction func googleLoginAction(_ sender: UIButton) {
        GIDSignIn.sharedInstance()?.presentingViewController = self
        //GIDSignIn.sharedInstance()?.restorePreviousSignIn()
        GIDSignIn.sharedInstance().signIn()
    }
    
    func navigateToDashboard() {
        let vc = Constants().storyBoard.instantiateViewController(withIdentifier: "Home") as! HomeViewController
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
}


