//
//  ScrollableTabViewController.swift
//  Zylo
//
//  Created by Abhishek Goyal on 16/09/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class ScrollableTabViewController: BaseViewController,UIScrollViewDelegate {

    let screenWidth = UIScreen.main.bounds.size.width
    let DefaultEdgeInset:UIEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)//Set edge insets to menu button
    let menuArray = ["Status","Administration"] // Menu button titles
    let font = UIFont.openSansBoldFontOfSize(size: 16.0)// Font size for button title text
    
    @IBOutlet weak var menuScrollView: UIScrollView!
    @IBOutlet weak var containerScrollView: UIScrollView!
    
    var vcUpcoming = UpcomingVaccineViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setScreenTitle(with: "Vaccination")
        //Add buttons to MenuScrollView:
        self.addButtonsToMenuScrollView(menuArray)
        
        self.navigationItem.rightBarButtonItem = nil
        
//        let isfirstTime = UserDefaults.standard.object(forKey: "firstTimeLoggedIn") as! Bool
               
//        if(isfirstTime){
//            UserDefaults.standard.set(false, forKey: "firstTimeLoggedIn")
//            let vc : VaccineAssociationViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "VaccineAssociation") as! VaccineAssociationViewController
//            self.navigationController?.pushViewController(vc, animated: false)
//        }
        
        //Instantiate view controllers those want to add in Page Controller.
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let firstVC = storyboard.instantiateViewController(withIdentifier: "UpcomingVaccine")
        vcUpcoming = firstVC as! UpcomingVaccineViewController
        let secondVC = storyboard.instantiateViewController(withIdentifier: "VaccineActivityList")
        
        self.addControllersToMainScrollView([firstVC,secondVC])

        // Do any additional setup after loading the view.
    }
    
    @objc func addButtonAction() {
        self.LoadActivity(activityId: 0)
    }

    func LoadActivity(activityId:Int) {
        let vc : VaccineActivityViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "VaccineActivity") as! VaccineActivityViewController
        vc.activityId = activityId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func addRighbutton(_ toAdd:Bool ){
        if(toAdd){
            Utility.setRightNavigationButton(target: self, image: UIImage(named: "add")!, action: #selector(self.addButtonAction))
        }else{
            self.navigationItem.rightBarButtonItem = nil
        }
    }
    
    // MARK: - Add buttons to scroll View
        
        func addButtonsToMenuScrollView(_ array:[String]) {
            let bHeight: CGFloat = self.menuScrollView.bounds.size.height
            var cWidth: CGFloat = 0.0
            for i in 0...array.count - 1 {
                
                let bWidth: CGFloat = self.calculateButtonWidth(array[i], DefaultEdgeInset) // Width of button considering attributes
                let frame: CGRect = CGRect(x: cWidth, y: 0, width: bWidth, height: bHeight)
                let menuButton = self.createButtonProgramaticallyAndCustomise(array[i], frame, i)
                menuButton.backgroundColor = .clear
                self.menuScrollView.addSubview(menuButton)
                
                //Add bottom view to button to show selected status
                let bottomViewFrame = CGRect(x: 0, y: menuButton.frame.size.height - 5, width: menuButton.frame.size.width, height: 5)
                let selectionView = self.createButtonBottomView(bottomViewFrame)
                menuButton.addSubview(selectionView)
                
                if i == 0 {
                    menuButton.isSelected = true
                    selectionView.isHidden = false
                } else {
                    selectionView.isHidden = true
                }
                cWidth += bWidth
            }
            
            self.menuScrollView.contentSize = CGSize(width: cWidth, height: self.menuScrollView.bounds.size.height)
        }
        
        func createButtonProgramaticallyAndCustomise(_ title:String, _ frame: CGRect, _ tag: Int) -> UIButton {
            //Create button programatically and add to Menu ScrollView
            let button: UIButton = UIButton(type: .custom)
            button.frame = frame
            button.setTitle(title, for: .normal)
            button.titleLabel?.font = font
            button.titleLabel?.textAlignment = .center
            //Set selected and normat color propreties to button
            button.setTitleColor(UIColor.gray, for: .normal)
            button.setTitleColor(UIColor.white, for: .selected)
            button.addTarget(self, action: #selector(buttonTapped(sender:)), for: .touchUpInside)
            button.tag = tag
            
            return button
        }
        
        func createButtonBottomView(_ btnViewFrame: CGRect) -> UIView {
            let bottomView = UIView(frame: btnViewFrame)
            bottomView.backgroundColor = UIColor.white
            bottomView.tag = 999
            return bottomView
        }
        
        @objc func buttonTapped(sender: UIButton) {
            let bWidth: CGFloat = 0
            
            for case let btn as UIButton in self.menuScrollView.subviews {
                let btmView = btn.viewWithTag(999)
                if btn.tag == sender.tag {
                    btn.isSelected = true
                    btmView?.isHidden = false
                    self.addRighbutton(true)
                } else {
                    self.addRighbutton(false)
                    vcUpcoming.viewWillAppear(true)
                    btn.isSelected  = false
                    btmView?.isHidden = true
                }
            }
            
            let width = screenWidth * CGFloat(sender.tag)
            self.containerScrollView.setContentOffset(CGPoint(x:width, y:0), animated: true)
            let xCordinate = screenWidth * CGFloat(sender.tag) * (bWidth / screenWidth) - bWidth
            self.menuScrollView.scrollRectToVisible(CGRect(x:xCordinate, y:0, width:screenWidth, height:self.menuScrollView.frame.size.height), animated: true)
        }
        
        func calculateButtonWidth(_ title: String, _ buttonEdgeInsets: UIEdgeInsets) -> CGFloat {
            
            let size: CGSize = title.size(withAttributes: [NSAttributedString.Key.font: font])
            let dividedSize = (screenWidth / CGFloat(menuArray.count))
            return (dividedSize < size.width) ? (size.width + buttonEdgeInsets.left + buttonEdgeInsets.right) : (dividedSize + buttonEdgeInsets.left + buttonEdgeInsets.right)
        }
        
        func addControllersToMainScrollView(_ viewController:[UIViewController]) {
            for i in 0...viewController.count - 1 {
                let vc = viewController[i]
                var frame = CGRect(x: 0, y: 0, width: self.containerScrollView.frame.size.width, height: self.containerScrollView.frame.size.height)
                frame.origin.x = screenWidth * CGFloat(i)
                vc.view.frame = frame
                self.addChild(vc)
                
                self.containerScrollView.addSubview(vc.view)
                vc.didMove(toParent: self)
            }
            self.containerScrollView.contentSize = CGSize(width: screenWidth * CGFloat(viewController.count), height:0)
            self.containerScrollView.delegate = self
            self.containerScrollView.isPagingEnabled = true
        }
        
        //MARK: - ScrollView Delegate Methods:
        func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
            let page = Int((scrollView.contentOffset.x / screenWidth))
            
            if(page == 0){
                self.addRighbutton(false)
                vcUpcoming.viewWillAppear(true)
            }else{
                self.addRighbutton(true)
            }
            
            var buttonWidth: CGFloat = 0.0
            for case let button as UIButton in self.menuScrollView.subviews {
                let btmView = button.viewWithTag(999)
                if button.tag == page {
                    button.isSelected = true
                    buttonWidth = button.frame.size.width
                    btmView?.isHidden =  false
                } else {
                    button.isSelected = false
                    btmView?.isHidden = true
                }
            }
            let xCoordinate = scrollView.contentOffset.x * (buttonWidth / screenWidth) - buttonWidth
            self.menuScrollView.scrollRectToVisible(CGRect(x:xCoordinate, y:0, width:screenWidth, height:self.menuScrollView.frame.size.height), animated: true)
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }

    }
