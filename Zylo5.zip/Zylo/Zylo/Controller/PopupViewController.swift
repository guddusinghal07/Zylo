//
//  PopupViewController.swift
//  Zylo
//
//  Created by Sathish on 12/03/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

protocol dataProcessingDelegateProtocol {
    func processSelectedData(_ data: Search, type: String)
}

class PopupViewController: BaseViewController, UISearchResultsUpdating, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var tableView: UITableView!
    var delegate: dataProcessingDelegateProtocol? = nil
    var type: String = ""
    
    var entries: [Search] = []
        
    // An empty tuple that will be updated with search results.
    var searchResults : [Search] = []
    
    var frequencyList : [Frequency] = []
    
    let searchController = UISearchController(searchResultsController: nil)
    
    var isSearchBarEmpty: Bool {
      return searchController.searchBar.text?.isEmpty ?? true
    }
    
    var isFiltering: Bool {
      return searchController.isActive && !isSearchBarEmpty
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.separatorColor = .clear
        self.tableView.backgroundColor = UIColor.clear
        
        entries = []
        if(type == Constants().vetFacility) {
            self.getVetListFromServer()
        } else if(type == Constants().petDogBreed) {
            for breed in Constants().dogBreedsList {
                entries.append(Search(id:-1, name:breed, address:"", city:"", state:"", zipcode:"", country:"", phoneNumber:"", ContactName:""))
            }
        } else if(type == Constants().petCatBreed) {
            for breed in Constants().catBreedsList {
                entries.append(Search(id:-1, name:breed, address:"", city:"", state:"", zipcode:"", country:"", phoneNumber:"", ContactName:""))
            }
        } else if(type == Constants().petParentCountry || type == Constants().vetCountry || type == Constants.userCountry) {
            entries.append(Search(id:-1, name:"United States", address:"", city:"", state:"", zipcode:"", country:"", phoneNumber:"", ContactName:""))
            for countryName in Constants().countryList {
                if(countryName != "United States") {
                    entries.append(Search(id:-1, name:countryName, address:"", city:"", state:"", zipcode:"", country:"", phoneNumber:"", ContactName:""))
                }
            }
        } else if (type == Constants().frequency){
            for frequency in frequencyList {
                if(frequency.frequencyDays! > 0) {
                    entries.append(Search(id:frequency.frequencyDays ?? 0, name:frequency.frequencyDaysValue ?? "", address:"", city:"", state:"", zipcode:"", country:"", phoneNumber:"", ContactName:""))
                }
            }
            self.tableView.reloadData()
        }
        
        // 1
        searchController.searchResultsUpdater = self
        // 2
        if #available(iOS 9.1, *) {
            searchController.obscuresBackgroundDuringPresentation = false
        }
        // 3
        searchController.searchBar.placeholder = "Search"
        // 4
        if #available(iOS 11.0, *) {
            navigationItem.searchController = searchController
        }
        self.definesPresentationContext = true

        // Place the search bar in the table view's header.
        self.tableView.tableHeaderView = searchController.searchBar
        
        // Set the content offset to the height of the search bar's height
        // to hide it when the view is first presented.
        //self.tableView.contentOffset = CGPoint(x: 0, y: searchController.searchBar.frame.height)
    }
    
    func getVetListFromServer() {
        self.showActivityIndicator()
        VetService.getVetList(vetId: 0, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let vetList = try? decoder.decode(VetListData.self, from: data) else { return }
            if let vetLst = vetList.data {
                for vet in vetLst {
                    if(!vet.vetHospital!.isEmpty) {
                        self.entries.append(Search(id:vet.vetId!, name:vet.vetHospital!, address:vet.vetHospitalAddress!, city:vet.vetCity!, state:vet.vetState!, zipcode:vet.vetZipcode!, country:vet.vetCountry!, phoneNumber:vet.vetPocContactNumber!, ContactName:vet.vetPocName!))
                    }
                }
                self.tableView.reloadData()
            } else {
                self.showErrorMessage(message: "Error in getting pet data. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    @IBAction func didTapCloseButton(_ sender: UIButton){
        self.closeModal()
    }
    
    func closeModal() {
        self.dismiss(animated: true, completion: nil)
        // if search controller exist in modal, it is not closing properly
        // so dismiss modal twice
        self.dismiss(animated: true, completion: nil)
    }
    
    func filterContent(for searchText: String) {
        // Update the searchResults array with matches
        // in our entries based on the title value.
        searchResults = entries.filter({ (Contact) -> Bool in
            let match = Contact.name.range(of: searchText, options: .caseInsensitive)
            // Return the tuple if the range contains a match.
            return match != nil
        })
    }

    // MARK: - UISearchResultsUpdating method
    func updateSearchResults(for searchController: UISearchController) {
        // If the search bar contains text, filter our data with the string
        if let searchText = searchController.searchBar.text {
            filterContent(for: searchText)
            // Reload the table view with the search result data.
            tableView.reloadData()
        }
    }
    
    // MARK: - UITableView method
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as! PopupTableViewCell
        cell.titleLabel?.font = UIFont.openSansBoldFontOfSize(size: 18.0)
        cell.titleLabel?.numberOfLines = 0
        cell.titleLabel?.lineBreakMode = .byWordWrapping
        cell.titleLabel?.preferredMaxLayoutWidth = tableView.frame.size.width
        cell.detailLabel?.font = UIFont.openSansFontOfSize(size: 16.0)
        cell.detailLabel?.numberOfLines = 0
        cell.detailLabel?.lineBreakMode = .byWordWrapping
        cell.detailLabel?.preferredMaxLayoutWidth = tableView.frame.size.width
        cell.selectionStyle = .none
        
        if isFiltering {
            let entry = searchResults[indexPath.row]
            cell.titleLabel?.text = entry.name
            if(type == Constants().vetFacility) {
                cell.detailLabel?.text = String(format: "%@, %@, %@, %@, %@", entry.address, entry.city, entry.state, entry.zipcode, entry.country)
                cell.detailLabel?.isHidden = false
            } else {
                cell.detailLabel?.text = ""
                cell.detailLabel?.isHidden = true
            }
        } else {
            let entry = entries[indexPath.row]
            cell.titleLabel?.text = entry.name
            if(type == Constants().vetFacility) {
                cell.detailLabel?.text = String(format: "%@, %@, %@, %@, %@", entry.address, entry.city, entry.state, entry.zipcode, entry.country)
                cell.detailLabel?.isHidden = false
            } else {
                cell.detailLabel?.text = ""
                cell.detailLabel?.isHidden = true
            }
        }
        //cell.imageView?.image = UIImage(named: entry.image)
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isFiltering {
            return searchResults.count
        }
        return entries.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (self.delegate != nil) {
            if isFiltering {
                let entry = searchResults[indexPath.row]
                self.delegate?.processSelectedData(entry, type: type)
            } else {
                let entry = entries[indexPath.row]
                self.delegate?.processSelectedData(entry, type: type)
            }
            self.closeModal()
        }
    }
    
}
