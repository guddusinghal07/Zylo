//
//  UpcomingVaccineViewController.swift
//  Zylo
//
//  Created by Sathish on 31/07/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class UpcomingVaccineViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var viewStatic : UIView!
    
    var upcomingList:[upcomingDataStats] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setScreenTitle(with: "Insights")
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.separatorColor = .clear
        self.tableView.backgroundColor = UIColor.clear
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.upcomingList = []
        self.getUpcomingVaccineList()
    }
    
    func getUpcomingVaccineList() {
        self.showActivityIndicator()
        VaccineService.getVaccineStats(petId:  Utility.getDefaultPetId(), vaccineId: 0, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let vacData = try? decoder.decode(upcomingVaccineStats.self, from: data) else { self.hideActivityIndicator(); return }
            var isActivityID : Int = 0
            if let vacLst = vacData.data {
                if(vacLst.count > 0) {
                    for vac in vacLst {
                        if(vac.isDeleted != nil && vac.isDeleted! == false) {
                            self.upcomingList.append(vac)
                        }
                        if(vac.activityId! < 0){
                            isActivityID = isActivityID + 1
                        }
                    }
                }
                if(isActivityID == vacLst.count){
                    self.tableView.isHidden = true
                    self.viewStatic.isHidden = false
                }else{
                    self.viewStatic.isHidden = true
                    self.tableView.isHidden = false
                    self.tableView.reloadData()
                }
            } else if vacData.status != 200 {
                self.showErrorMessage(message: "Error in getting vaccine upcoming details. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60//UITableView.automaticDimension
    }

    public func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60//UITableView.automaticDimension
    }
    
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    public func tableView(_ tableView: UITableView, numberOfRowsInSection sectionIndex: Int) -> Int {
        return upcomingList.count
    }

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: UpcomingVaccineListTableViewCell = tableView.dequeueReusableCell(withIdentifier: "UpcomingList", for: indexPath) as! UpcomingVaccineListTableViewCell
        
        let vac:upcomingDataStats = upcomingList[indexPath.row]
        cell.vaccineNameLabel.text = vac.vaccineName
        cell.lastAdministrationLabel.text =  self.getProperDateString(vac.dateVaccineGiven)
        cell.nextAdministrationLabel.text =  self.getProperDateString(vac.dateVaccineDue)
        cell.activityId = vac.activityId!
        
        switch vac.color {
        case "gray":
            cell.statusView.backgroundColor = .gray
        case "green":
            cell.statusView.backgroundColor = .green
        case "red":
            cell.statusView.backgroundColor = .red
        case "orange":
            cell.statusView.backgroundColor = .orange
        default:
            cell.statusView.backgroundColor = .gray
        }
        
        cell.selectionStyle = .none
        
        return cell
    }
    
    func getProperDateString(_ dateResponse: String?) -> String {
        if(dateResponse?.lowercased() == "unknown") {
            return dateResponse!
        } else {
            let dt = Utility.getDateFromString(dateString: dateResponse!)
            let dateformatter = DateFormatter()
            dateformatter.dateStyle = .medium
            return  dateformatter.string(from: dt)
        }
    }
}
