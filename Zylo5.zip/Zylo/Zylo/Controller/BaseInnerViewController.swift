//
//  BaseInnerViewController.swift
//  Zylo
//
//  Created by Sathish on 07/06/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class BaseInnerViewController: BaseViewController {

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.tintColor = UIColor.black
        // Remove the background color.
        self.navigationController?.navigationBar.setBackgroundImage(UIColor.white   .as1ptImage(), for: .default)
        // Set the shadow color.
        self.navigationController?.navigationBar.shadowImage = UIColor.white.as1ptImage()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
