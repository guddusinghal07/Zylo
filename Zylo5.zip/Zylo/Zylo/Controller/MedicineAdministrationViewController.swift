//
//  MedicineAdministrationViewController.swift
//  Zylo
//
//  Created by Sathish on 04/06/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit
import DropDown

class MedicineAdministrationViewController: BaseInnerViewController {
    
    @IBOutlet weak var medicineDropDownButton: NiceButton!
    @IBOutlet weak var administrativeDateTextField: DateTextField!
    var medList: [Medicine] = []
    
    var activityId: Int = 0
    var medicineId: Int = 0
    var administeredDate: String = ""
    
    let medicineDropDown = DropDown()
    lazy var dropDowns: [DropDown] = {
        return [
            self.medicineDropDown
        ]
    }()
    
    @IBAction func showMedicineDropDown(_ sender: AnyObject) {
        medicineDropDown.show()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if(self.activityId > 0) {
            self.setScreenTitle(with: "Update Activity", color: .black)
        } else {
            self.setScreenTitle(with: "Add Activity", color: .black)
        }
        
        self.getMedicineList()
        Utility.setupDropdownAppreance()
        
        dropDowns.forEach { $0.dismissMode = .onTap }
        dropDowns.forEach { $0.direction = .any }
        
        if(!administeredDate.isEmpty) {
            let actDate = Utility.getDateFromString(dateString: administeredDate)
            self.administrativeDateTextField.selectedDate = actDate
        }
        
        Utility.setRightNavigationButton(target: self, image: UIImage(named: "save")!, action: #selector(self.didTapSaveButton))
    }
    
    @objc func didTapSaveButton() {
        self.resignFirstResponder()
        if(self.validateInputs()) {
            if(self.activityId <= 0) {
                self.createMedicineAdministration()
            } else {
                self.updateMedicineAdministration()
            }
        }
    }
    
    func validateInputs() -> Bool {
        var returnValue: Bool = true
        if(self.medicineDropDown.indexForSelectedRow == nil) {
            self.medicineDropDownButton.errorMessage = "Medicine is required"
            returnValue = false
        } else {
            self.medicineDropDownButton.errorMessage = ""
        }
        return returnValue
    }
    
    func getMedicineList() {
        self.showActivityIndicator()
        MedicineService.getMedicine(petId: Utility.getDefaultPetId(), medId: 0, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let medData = try? decoder.decode(MedicineList.self, from: data) else { return }
            if let medLst = medData.data {
                for med in medLst {
                    if(med.isDeleted != nil && med.isDeleted! == false) {
                        self.medList.append(med)
                    }
                }
                self.setupMedicineDropDown()
                self.setSelectedItem(list: self.medList, value: self.medicineId)
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func setupMedicineDropDown() {
        medicineDropDown.anchorView = medicineDropDownButton
        medicineDropDown.bottomOffset = CGPoint(x: 0, y: medicineDropDownButton.bounds.height)
        medicineDropDown.dataSource = self.medList.map { "\($0.medicineId!) - \($0.medName!)" }
        // And if you use custom cells:
        medicineDropDown.customCellConfiguration = { (index: Index, item: String, cell: DropDownCell) -> Void in
            // Get your model for this cell the same way as above:
            let med = self.medList[index]
            // Setup your custom UI components
            cell.optionLabel.text = med.medName!
        }
        medicineDropDown.selectionAction = { [weak self] (index, item) in
            let selectedMedicine = self!.medList[index]
            self?.medicineDropDownButton.setTitle(selectedMedicine.medName, for: .normal)
        }
    }
    
    func setSelectedItem(list:[Medicine], value:Int) {
        for (index, _) in list.enumerated() { self.medicineDropDown.deselectRow(at:index) }
        if let index = list.firstIndex(where: {$0.medicineId == value}) {
            self.medicineDropDown.reloadAllComponents()
            self.medicineDropDown.selectRow(index)
            self.medicineDropDown.selectionAction?(index, list[index].medName!)
        }
    }
    
    func getParamValues() -> NSDictionary {
        let data:[String:Any] = ["medicine_id":String(self.medList[self.medicineDropDown.indexForSelectedRow!].medicineId!), "medicine_administration_date":self.administrativeDateTextField.getDate()]
        let postData:[String:Any] = ["data":data]
        return postData as NSDictionary
    }
    
    func createMedicineAdministration() {
        self.showActivityIndicator()
        MedicineService.addMedicineAdministration(petId: Utility.getDefaultPetId() , postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let adminData = try? decoder.decode(MedicineAdministration.self, from: data) else { return }
            if(adminData.status == 200) {
                if(adminData.activityId! > 0) {
                     self.navigationController?.popViewController(animated: true)
                     self.showSuccessMessage(message: "Medicine administration details saved successfully")
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: Constants.reloadMedicineAdministration), object: nil)
                 } else {
                    self.showErrorMessage(message: adminData.message!)
                }
            } else if(adminData.status == 400) {
                self.showErrorMessage(message: adminData.message!)
            } else {
                self.showErrorMessage(message: "Error in creating medicine administration details. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    func updateMedicineAdministration() {
        self.showActivityIndicator()
        MedicineService.updateMedicineAdministration(petId: Utility.getDefaultPetId(), actId: self.activityId, postData: self.getParamValues(), onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let adminData = try? decoder.decode(MedicineAdministration.self, from: data) else { return }
            if(adminData.status == 200) {
                if(adminData.activityId! > 0) {
                     self.navigationController?.popViewController(animated: true)
                     self.showSuccessMessage(message: "Medicine administration details updated successfully")
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: Constants.reloadMedicineAdministration), object: nil)
                 } else {
                    self.showErrorMessage(message: adminData.message!)
                }
            } else if(adminData.status == 400) {
                self.showErrorMessage(message: adminData.message!)
            } else {
                self.showErrorMessage(message: "Error in updating medicine administration details. Please try again later.")
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
}
