//
//  BaseViewController.swift
//  Zylo
//
//  Created by Sathish on 10/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit
import SwiftMessages
import Firebase
import GoogleSignIn
import MapKit

class BaseViewController: UIViewController, CLLocationManagerDelegate {
    var locationManager:CLLocationManager!
    var geoCoder = CLGeocoder()
    var street = String()
    var city = String()
    var state = String()
    var country = String()
    var zipcode = String()
    
    var activityIndicatorContainer: UIView!
    var activityIndicator: UIActivityIndicatorView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        UINavigationBar.appearance().tintColor = UIColor.white
        self.navigationController?.navigationBar.tintColor = UIColor.white
        
        // Remove the background color.
        self.navigationController?.navigationBar.setBackgroundImage(UIColor.clear   .as1ptImage(), for: .default)
        // Set the shadow color.
        self.navigationController?.navigationBar.shadowImage = UIColor.clear.as1ptImage()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white // Constants.backgroundColor
        
        Utility.setUserNavigationButton(target: self, action: #selector(self.didTapUserImage))
        
        GIDSignIn.sharedInstance().clientID = FirebaseApp.app()?.options.clientID
    }
    
    @objc func didTapUserImage(){
        self.resignFirstResponder()
        let vc : ProfileViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "Profile") as! ProfileViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func setScreenTitle(with:String, color: UIColor = .white) {
        let customTitleView = UIView()
        let titleLabel = UILabel(frame: CGRect(x: 0.0, y: 0.0, width: 200.0, height: 30.0))
        titleLabel.text = with
        titleLabel.font = UIFont.openSansBoldFontOfSize(size: 16.0)
        titleLabel.backgroundColor = UIColor.clear
        titleLabel.textAlignment = .center
        titleLabel.textColor = color
        //titleLabel.shadowColor = UIColor(red: 0.0 / 255.0, green: 0.0 / 255.0, blue: 0.0 / 255.0, alpha: 0.25)
        //titleLabel.shadowOffset = CGSize(width: 0.0, height: -1.0)
        titleLabel.sizeToFit()

        customTitleView.frame = CGRect(x: (self.navigationItem.titleView?.frame.size.width ?? 0.0) / 2 - titleLabel.frame.size.width / 2, y: (self.navigationItem.titleView?.frame.size.height ?? 0.0) / 2 - titleLabel.frame.size.height / 2, width: titleLabel.frame.size.width, height: titleLabel.frame.size.height)

        customTitleView.addSubview(titleLabel)

        self.navigationItem.titleView = customTitleView
    }
    
    func showActivityIndicator() {
        self.activityIndicatorContainer = UIView(frame: CGRect(x: 0, y: 0, width: 80, height: 80))
        self.activityIndicatorContainer.center.x = self.view.center.x
        // Need to subtract 44 because WebKitView is pinned to SafeArea
        //   and we add the toolbar of height 44 programatically
        self.activityIndicatorContainer.center.y = self.view.center.y - 44
        self.activityIndicatorContainer.backgroundColor = Constants().themeColor
        self.activityIndicatorContainer.alpha = 0.8
        self.activityIndicatorContainer.layer.cornerRadius = 10
        
        self.activityIndicator = UIActivityIndicatorView()
        self.activityIndicator.hidesWhenStopped = true
        self.activityIndicator.transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
        self.activityIndicator.color = UIColor.white
        self.activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        self.activityIndicator.startAnimating()
        
        self.activityIndicatorContainer.addSubview(self.activityIndicator)
        self.view.addSubview(self.activityIndicatorContainer)

        // Constraints
        self.activityIndicator.centerXAnchor.constraint(equalTo: self.activityIndicatorContainer.centerXAnchor).isActive = true
        self.activityIndicator.centerYAnchor.constraint(equalTo: self.activityIndicatorContainer.centerYAnchor).isActive = true
    }
    
    func hideActivityIndicator() {
        if(self.activityIndicatorContainer != nil) {
            self.activityIndicatorContainer.removeFromSuperview()
        }
    }
    
    func showSuccessMessage(message:String) {
        showMessage(theme: .success, message: message)
    }
    
    func showErrorMessage(message:String) {
        showMessage(theme: .error, message: message)
    }
    
    func showWarningMessage(message:String) {
        showMessage(theme: .warning, message: message)
    }
    
    private func showMessage(theme:Theme, message:String) {
        let cardView = MessageView.viewFromNib(layout: .cardView)
        cardView.configureTheme(theme)
        cardView.configureDropShadow()
        switch theme {
        case .success:
            cardView.configureContent(title: "Success", body: message)
        case .error:
            cardView.configureContent(title: "Error", body: message)
        default:
            cardView.configureContent(title: "Warning", body: message)
        }
        cardView.bodyLabel?.font = UIFont.openSansFontOfSize(size: 16)
        cardView.titleLabel?.font = UIFont.openSansBoldFontOfSize(size: 18)
        cardView.button?.isHidden = true
        cardView.titleLabel?.isHidden = true
        var defaultConfig = SwiftMessages.defaultConfig
        defaultConfig.presentationStyle = .top
        defaultConfig.presentationContext = .window(windowLevel: .statusBar)
        SwiftMessages.show(config: defaultConfig, view: cardView)
    }
    
    func logoutUser() {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
            GIDSignIn.sharedInstance()?.signOut()
            Utility.LogoutCurrentUser()
            
            let vc : SignUpViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "SignUp") as! SignUpViewController
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated:true, completion:nil)
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
    }
    
    @IBAction func locationAction(_ sender: AnyObject) {
        if (Utility.isInternetAvailable()) {
            if CLLocationManager.locationServicesEnabled() {
                switch(CLLocationManager.authorizationStatus()) {
                case .notDetermined, .restricted, .denied:
                    self.getLocation()
                case .authorizedAlways, .authorizedWhenInUse:
                    self.getLocation()
                default:
                    self.hideActivityIndicator()
                }
            } else {
                self.getLocation()
            }
        }
    }
    
    func getLocation() {
        self.showActivityIndicator()
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
        } else {
            self.hideActivityIndicator()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let userLocation:CLLocation = locations[0] as CLLocation
        geoCoder.reverseGeocodeLocation(userLocation, completionHandler: {(placemarks: [CLPlacemark]?, error: Error?) -> Void in
            guard error == nil else {
                self.hideActivityIndicator()
                return
            }
            let pm = placemarks! as [CLPlacemark]
            if pm.count > 0 {
                let pm = placemarks![0]
                if pm.subLocality != nil {
                    self.street = pm.subLocality!
                }
                if pm.thoroughfare != nil {
                  self.street += ", " + pm.thoroughfare!
                }
                if pm.locality != nil {
                    self.city = pm.locality!
                }
                if pm.country != nil {
                    self.country = pm.country!
                }
                if pm.postalCode != nil {
                    self.zipcode = pm.postalCode!
                }
                if let state = pm.administrativeArea {
                    self.state = state
                }
            }
            self.bindLocation() // this method will be overridden in subclass
            self.locationManager.stopUpdatingLocation()
        })
    }
}

protocol LocationDelegate: class {
    func bindLocation() // Method that can be override
}

extension BaseViewController: LocationDelegate {
    // Default implementation
    @objc func bindLocation() {
        print("base class method which need to be override")
        self.hideActivityIndicator()
    }
}
