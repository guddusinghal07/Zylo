//
//  MedicineAdministrationListViewController.swift
//  Zylo
//
//  Created by Sathish on 07/08/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class MedicineAdministrationListViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var infoView: UIView!
    
    var medList: [MedicineProfile] = []
    var medicineId: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setScreenTitle(with: "Activity Log")
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.separatorColor = .clear
        self.tableView.backgroundColor = UIColor.clear
        
        self.infoView.backgroundColor = .white
        Utility.setView(view: self.infoView, hidden: true)
        Utility.setRightNavigationButton(target: self, image: UIImage(named: "add")!, action: #selector(self.addButtonAction))
        
        self.loadMedicineLogList()
        
        NotificationCenter.default.addObserver(self, selector: #selector(loadList), name: NSNotification.Name(rawValue: Constants.reloadMedicineAdministration), object: nil)
    }
    
    @objc func loadList(notification: NSNotification){
        self.loadMedicineLogList()
    }
    
    func loadMedicineLogList() {
        self.medList = []
        self.getMedicineLog()
    }
    
    func getMedicineLog() {
        self.showActivityIndicator()
        MedicineService.getMedicineLog(petId: Utility.getDefaultPetId(), medicineId: self.medicineId, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let medData = try? decoder.decode(MedicineProfileList.self, from: data) else { self.hideActivityIndicator(); return }
            if let medLst = medData.data {
                for med in medLst {
                    if(med.isDeleted != nil && med.isDeleted! == 0) {
                        self.medList.append(med)
                    }
                }
                self.tableView.reloadData()
            } else if medData.status != 200 {
                self.showErrorMessage(message: "Error in getting medicine log data. Please try again later.")
            }
            if(self.medList.count <= 0) {
                Utility.setView(view: self.infoView, hidden: false)
            } else {
                Utility.setView(view: self.infoView, hidden: true)
            }
            self.hideActivityIndicator()
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
    
    @objc func addButtonAction() {
        self.resignFirstResponder()
        self.loadAdministrationDetails(activityId: 0, activityDate: "")
    }
    
    func loadAdministrationDetails(activityId: Int, activityDate: String) {
        let vc : MedicineAdministrationViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "MedicineAdministration") as! MedicineAdministrationViewController
        vc.activityId = activityId
        vc.medicineId = self.medicineId
        vc.administeredDate = activityDate
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

    public func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    public func tableView(_ tableView: UITableView, numberOfRowsInSection sectionIndex: Int) -> Int {
        return medList.count
    }

    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell: MedicineListTableViewCell = tableView.cellForRow(at: indexPath) as! MedicineListTableViewCell
        self.loadAdministrationDetails(activityId: cell.activityId, activityDate: cell.activityDate)
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: MedicineListTableViewCell = tableView.dequeueReusableCell(withIdentifier: "MedicineList", for: indexPath) as! MedicineListTableViewCell
        
        let med:MedicineProfile = medList[indexPath.row]
        cell.medNameLabel.text = med.medName! + "(" + med.medCategory! + ")"
        cell.frequencyLabel.text = "\(med.medAdminFrequency!) day(s)"
        let dt = Utility.getDateFromString(dateString: med.medicineAdministrationDate!)
        let dateformatter = DateFormatter()
        dateformatter.dateStyle = .medium
        let lastAdministrationDate: String = dateformatter.string(from: dt)
        cell.lastAdministrationLabel.attributedText = "Administration Date: \(lastAdministrationDate)".attributedText(boldString: lastAdministrationDate, font: cell.lastAdministrationLabel.font)
        cell.medicineId = med.medicineId!
        cell.activityId = med.activityId!
        cell.activityDate = med.medicineAdministrationDate!
        cell.selectionStyle = .none
        
        cell.deleteButton.layer.setValue(cell.activityId, forKey: "activityId")
        cell.deleteButton.addTarget(self, action: #selector(didTapDeleteButton), for: UIControl.Event.touchUpInside)
        
        cell.editButton.layer.setValue(cell.activityId, forKey: "activityId")
        cell.editButton.layer.setValue(cell.activityDate, forKey: "activityDate")
        cell.editButton.addTarget(self, action: #selector(didTapEditButton), for: UIControl.Event.touchUpInside)
        
        return cell
    }
    
    @objc func didTapEditButton(sender:UIButton){
        let actId : Int = (sender.layer.value(forKey: "activityId")) as! Int
        let activityDate: String = (sender.layer.value(forKey: "activityDate")) as! String
        self.loadAdministrationDetails(activityId: actId, activityDate: activityDate)
    }
    
    @objc func didTapDeleteButton(sender:UIButton){
        self.resignFirstResponder()
        let dialogMessage = UIAlertController(title: "Confirm", message: "Are you sure you want to delete this administration details?", preferredStyle: .alert)
        let yes = UIAlertAction(title: "Yes", style: .default, handler: { (action) -> Void in
            let actId : Int = (sender.layer.value(forKey: "activityId")) as! Int
            self.deleteAdministration(actId: actId)
        })
        let no = UIAlertAction(title: "No", style: .cancel) { (action) -> Void in
            print("Cancel button tapped")
        }
        dialogMessage.addAction(yes)
        dialogMessage.addAction(no)
        self.present(dialogMessage, animated: true, completion: nil)
    }
    
    func deleteAdministration(actId:Int) {
        self.showActivityIndicator()
        MedicineService.DeleteActivity(petId: Utility.getDefaultPetId(), actId: actId, onSuccess: {(data) in
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            guard let medData = try? decoder.decode(MedicineResponse.self, from: data) else { return }
            if let status = medData.status {
                self.hideActivityIndicator()
                if(status == 200) {
                    self.showSuccessMessage(message: "Medicine activity details deleted successfully")
                    self.loadMedicineLogList()
                }
            } else {
                self.showErrorMessage(message: "Error in deleting medicine activity details. Please try again later.")
                self.hideActivityIndicator()
            }
        }, onFailure: {_ in
            self.hideActivityIndicator()
        })
    }
}
