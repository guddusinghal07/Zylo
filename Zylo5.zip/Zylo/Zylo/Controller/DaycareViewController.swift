//
//  DaycareViewController.swift
//  Zylo
//
//  Created by Sathish on 28/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit
import DropDown

class DaycareViewController: BaseInnerViewController {

    @IBOutlet weak var petDropDownButton: UIButton!
    @IBOutlet weak var nameTextField: TextField!
    @IBOutlet weak var addressTextField: TextField!
    @IBOutlet weak var cityTextField: TextField!
    @IBOutlet weak var stateTextField: TextField!
    @IBOutlet weak var countryDropDownButton: UIButton!
    @IBOutlet weak var zipcodeTextField: TextField!
    @IBOutlet weak var latTextField: TextField!
    @IBOutlet weak var longTextField: TextField!
    @IBOutlet weak var websiteUrlTextField: TextField!
    @IBOutlet weak var facebookUrlTextField: TextField!
    @IBOutlet weak var personNameTextField: TextField!
    @IBOutlet weak var personTitleTextField: TextField!
    @IBOutlet weak var emailTextField: TextField!
    @IBOutlet weak var genericEmailTextField: TextField!
    @IBOutlet weak var phoneNumberTextField: TextField!
    @IBOutlet weak var priceTextField: TextField!
    @IBOutlet weak var offersBoardingSwitch: UISwitch!
        
    let petDropDown = DropDown()
    let countryDropDown = DropDown()
    
    lazy var dropDowns: [DropDown] = {
        return [
            self.petDropDown,
            self.countryDropDown
        ]
    }()
    
    @IBAction func showPetDropDown(_ sender: AnyObject) {
        petDropDown.show()
    }
    
    @IBAction func showCountryDropDown(_ sender: AnyObject) {
        countryDropDown.show()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setScreenTitle(with: "Daycare", color: .black)
        // Do any additional setup after loading the view.
        
        setupPetDropDown()
        setupCountryDropDown()
        Utility.setupDropdownAppreance()
        
        dropDowns.forEach { $0.dismissMode = .onTap }
        dropDowns.forEach { $0.direction = .any }
        
        offersBoardingSwitch.onTintColor = Constants().themeColor
        
        Utility.setRightNavigationButton(target: self, image: UIImage(named: "save")!, action: #selector(self.saveDaycareAction))
    }

    func setupPetDropDown() {
        // Not setting the anchor view makes the drop down centered on screen
        petDropDown.anchorView = petDropDownButton
        
        // By default, the dropdown will have its origin on the top left corner of its anchor view
        // So it will come over the anchor view and hide it completely
        // If you want to have the dropdown underneath your anchor view, you can do this:
        petDropDown.bottomOffset = CGPoint(x: 0, y: petDropDownButton.bounds.height)
        
        // You can also use localizationKeysDataSource instead. Check the docs.
        //petDropDown.dataSource = Constants().frequencyList
        
        petDropDown.selectionAction = { [weak self] (index, item) in
            self?.petDropDownButton.setTitle(item, for: .normal)
        }
    }
    
    func setupCountryDropDown() {
        // Not setting the anchor view makes the drop down centered on screen
        countryDropDown.anchorView = countryDropDownButton
        
        // By default, the dropdown will have its origin on the top left corner of its anchor view
        // So it will come over the anchor view and hide it completely
        // If you want to have the dropdown underneath your anchor view, you can do this:
        countryDropDown.bottomOffset = CGPoint(x: 0, y: countryDropDownButton.bounds.height)
        
        // You can also use localizationKeysDataSource instead. Check the docs.
        countryDropDown.dataSource = Constants().countryList
        
        countryDropDown.selectionAction = { [weak self] (index, item) in
            self?.countryDropDownButton.setTitle(item, for: .normal)
        }
    }
    
    @objc func saveDaycareAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
}
