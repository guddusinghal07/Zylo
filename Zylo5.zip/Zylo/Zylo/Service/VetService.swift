//
//  VetService.swift
//  Zylo
//
//  Created by Sathish on 04/04/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class VetService {

    // method to get pet profile
    static func getVetList(vetId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "vet-management/\(vetId)"
        APIService.getRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
}
