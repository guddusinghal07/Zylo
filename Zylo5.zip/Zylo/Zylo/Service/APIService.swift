//
//  APIService.swift
//  Zylo
//
//  Created by Sathish on 16/06/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class APIService {

    // GET request
    static func getRequest(urlString: String, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        
        if(Utility.isInternetAvailable()) {
            guard let url = URL(string: urlString) else { return }
            var request = URLRequest(url: url)
            request.setValue(Utility.getCurrentUserToken(), forHTTPHeaderField: "token")
            request.setValue(String(Utility.getCurrentUserId()), forHTTPHeaderField: "user_id")
            request.setValue(Utility.zyloApiKey, forHTTPHeaderField: "x-api-key")
            
            request.httpMethod = "GET"
            
            URLSession.shared.dataTask(with: request) { data, response, error in
                DispatchQueue.main.async {
                    success(data!)
                }
            }.resume()
        } else {
            let error = NSError(domain: "", code: Constants().networkConnectionErrorCode, userInfo: [NSLocalizedDescriptionKey : "Network connection is not available."])
            failure(error)
        }
    }
    
    // POST request
    static func postRequest(urlString: String, postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        
        if(Utility.isInternetAvailable()) {
            guard let url = URL(string: urlString) else { return }
            var request = URLRequest(url: url)
            request.addValue(Utility.getCurrentUserToken(), forHTTPHeaderField: "token")
            request.setValue(String(Utility.getCurrentUserId()), forHTTPHeaderField: "user_id")
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue(Utility.zyloApiKey, forHTTPHeaderField: "x-api-key")
            
            request.httpMethod = "POST"
            do {
                request.httpBody = try JSONSerialization.data(withJSONObject: postData, options: .prettyPrinted)
            } catch let error {
                failure(error)
            }

            URLSession.shared.dataTask(with: request) { data, response, error in
              DispatchQueue.main.async {
                  success(data!)
              }
            }.resume()
        } else {
            let error = NSError(domain: "", code: Constants().networkConnectionErrorCode, userInfo: [NSLocalizedDescriptionKey : "Network connection is not available."])
            failure(error)
        }
    }
    
    // PUT request
    static func putRequest(urlString: String, postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        
        if(Utility.isInternetAvailable()) {
            guard let url = URL(string: urlString) else { return }
            var request = URLRequest(url: url)
            request.addValue(Utility.getCurrentUserToken(), forHTTPHeaderField: "token")
            request.setValue(String(Utility.getCurrentUserId()), forHTTPHeaderField: "user_id")
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue(Utility.zyloApiKey, forHTTPHeaderField: "x-api-key")
            
            request.httpMethod = "PUT"
            do {
                request.httpBody = try JSONSerialization.data(withJSONObject: postData, options: .prettyPrinted)
            } catch let error {
                failure(error)
            }

            URLSession.shared.dataTask(with: request) { data, response, error in
              DispatchQueue.main.async {
                  success(data!)
              }
            }.resume()
        } else {
            let error = NSError(domain: "", code: Constants().networkConnectionErrorCode, userInfo: [NSLocalizedDescriptionKey : "Network connection is not available."])
            failure(error)
        }
    }
    
    // DELETE request
    static func deleteRequest(urlString: String, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        
        if(Utility.isInternetAvailable()) {
            guard let url = URL(string: urlString) else { return }
            var request = URLRequest(url: url)
            request.addValue(Utility.getCurrentUserToken(), forHTTPHeaderField: "token")
            request.setValue(String(Utility.getCurrentUserId()), forHTTPHeaderField: "user_id")
            request.setValue(Utility.zyloApiKey, forHTTPHeaderField: "x-api-key")
            
            request.httpMethod = "DELETE"
            
            URLSession.shared.dataTask(with: request) { data, response, error in
              DispatchQueue.main.async {
                  success(data!)
              }
            }.resume()
        } else {
            let error = NSError(domain: "", code: Constants().networkConnectionErrorCode, userInfo: [NSLocalizedDescriptionKey : "Network connection is not available."])
            failure(error)
        }
    }
}
