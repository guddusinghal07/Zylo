//
//  VaccineService.swift
//  Zylo
//
//  Created by Sathish on 13/06/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class VaccineService {

    // method to get vaccine
    static func getVaccine(vaccineId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/vaccine-management/\(vaccineId)"
        APIService.getRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
    // method to get pet vaccine
    static func getPetVaccine(petId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/pet-vaccine-association"
        APIService.getRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
    // method to create vaccine association
    static func addVaccineAssociation(petId: Int, postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/pet-vaccine-association"
        APIService.postRequest(urlString: url, postData: postData, onSuccess: success, onFailure: failure)
    }
    
    // method to update vaccine association
    static func UpdateVaccineAssociation(petId: Int, postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/pet-vaccine-association"
        APIService.putRequest(urlString: url, postData: postData, onSuccess: success, onFailure: failure)
    }
    
    // method to create vaccine activity
    static func addVaccineActivity(petId: Int, postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/vaccine-activity-management"
        APIService.postRequest(urlString: url, postData: postData, onSuccess: success, onFailure: failure)
    }
    
    // method to get pet vaccine activity list
    static func getPetVaccineActivity(petId: Int, activityId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/vaccine-activity-management/\(activityId)"
        APIService.getRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
    // method to delete vaccine activity
    static func DeleteVaccineActivity(petId: Int, activityId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/vaccine-activity-management/\(activityId)"
        APIService.deleteRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
    // method to update vaccine activity
    static func updateVaccineActivity(petId: Int, activityId: Int, postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/vaccine-activity-management/\(activityId)"
        APIService.putRequest(urlString: url, postData: postData, onSuccess: success, onFailure: failure)
    }
    
    // method to get pet vaccine activity list
    static func getUpcomingVaccineActivity(petId: Int, vaccineId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/vaccine-activity-management/upcoming-vaccine?vaccine_id=\(vaccineId)"
        APIService.getRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
    // method to get pet vaccine Stats list
    static func getVaccineStats(petId: Int, vaccineId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/vaccine-activity-management/vaccine-insights/\(vaccineId)"
        APIService.getRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
}
