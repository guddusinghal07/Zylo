//
//  MedicineService.swift
//  Zylo
//
//  Created by Sathish on 22/05/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class MedicineService {
    
    // method to get medicine
    static func getMedicine(petId: Int, medId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/medicine-management/\(medId)"
        APIService.getRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
    // method to create medicine
    static func addMedicine (petId: Int, postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/medicine-management"
        APIService.postRequest(urlString: url, postData: postData, onSuccess: success, onFailure: failure)
    }
    
    // method to update pet profile
    static func UpdateMedicine(petId: Int, medId: Int, postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/medicine-management/\(medId)"
        APIService.putRequest(urlString: url, postData: postData, onSuccess: success, onFailure: failure)
    }
    
    // method to delete pet profile
    static func DeleteMedicine(petId: Int, medId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/medicine-management/\(medId)"
        APIService.deleteRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
    // method to get medicine log
    static func getMedicineLog(petId: Int, medicineId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/medicine-activity-management/0?medicine_id=\(medicineId)"
        APIService.getRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
    // method to add medicine administration
    static func addMedicineAdministration (petId: Int, postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/medicine-activity-management"
        APIService.postRequest(urlString: url, postData: postData, onSuccess: success, onFailure: failure)
    }
    
    // method to update medicine administration
    static func updateMedicineAdministration (petId: Int, actId: Int, postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/medicine-activity-management/\(actId)"
        APIService.putRequest(urlString: url, postData: postData, onSuccess: success, onFailure: failure)
    }
    
    // method to delete medicine activity
    static func DeleteActivity(petId: Int, actId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)/medicine-activity-management/\(actId)"
        APIService.deleteRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
    // method to Get Frequency Data
    static func getFrequencyData(onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "utilities/frequencies"
        APIService.getRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
}
