//
//  UserService.swift
//  Zylo
//
//  Created by Sathish on 23/03/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class UserService {
    
    // method to get user
    static func getUser(useOldData: Bool, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        
        if(Utility.isInternetAvailable()) {
            guard let url = URL(string: Constants().BaseUrl + "user-management/user/login") else { return }
            var request = URLRequest(url: url)
            request.setValue(Utility.getCurrentUserToken(), forHTTPHeaderField: "token")
            request.setValue(String(useOldData), forHTTPHeaderField: "use_old")
            request.setValue(Utility.zyloApiKey, forHTTPHeaderField: "x-api-key")
            
            request.httpMethod = "GET"
            
            URLSession.shared.dataTask(with: request) { data, response, error in
                DispatchQueue.main.async {
                    success(data!)
                }
            }.resume()
        } else {
            let error = NSError(domain: "", code: Constants().networkConnectionErrorCode, userInfo: [NSLocalizedDescriptionKey : "Network connection is not available."])
            failure(error)
        }
        
    }
    
    // method to create user
    static func CreateUser(postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        
        if(Utility.isInternetAvailable()) {
            guard let url = URL(string: Constants().BaseUrl + "user-management/user/register") else { return }
            var request = URLRequest(url: url)
            print(Utility.getCurrentUserToken())
            request.addValue(Utility.getCurrentUserToken(), forHTTPHeaderField: "token")
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue(Utility.zyloApiKey, forHTTPHeaderField: "x-api-key")

            request.httpMethod = "POST"
            do {
                request.httpBody = try JSONSerialization.data(withJSONObject: postData, options: .prettyPrinted)
            } catch let error {
                failure(error)
            }

            URLSession.shared.dataTask(with: request) { data, response, error in
              DispatchQueue.main.async {
                  success(data!)
              }
            }.resume()
        } else {
            let error = NSError(domain: "", code: Constants().networkConnectionErrorCode, userInfo: [NSLocalizedDescriptionKey : "Network connection is not available."])
            failure(error)
        }
    }
    
    // method to update user
    static func UpdateUser(userId: Int, postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        
        if(Utility.isInternetAvailable()) {
            guard let url = URL(string: Constants().BaseUrl + "user-management/user/update/\(userId)") else { return }
            var request = URLRequest(url: url)
            request.addValue(Utility.getCurrentUserToken(), forHTTPHeaderField: "token")
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("false", forHTTPHeaderField: "remove_old_user")
            request.setValue(Utility.zyloApiKey, forHTTPHeaderField: "x-api-key")
            
            request.httpMethod = "PUT"
            do {
                request.httpBody = try JSONSerialization.data(withJSONObject: postData, options: .prettyPrinted)
            } catch let error {
                failure(error)
            }

            URLSession.shared.dataTask(with: request) { data, response, error in
              DispatchQueue.main.async {
                  success(data!)
              }
            }.resume()
        } else {
            let error = NSError(domain: "", code: Constants().networkConnectionErrorCode, userInfo: [NSLocalizedDescriptionKey : "Network connection is not available."])
            failure(error)
        }
    }
    
    // method to delete user
    static func DeleteUser(onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        if(Utility.isInternetAvailable()) {
            guard let url = URL(string: Constants().BaseUrl + "user-management/user/delete/\(Utility.getCurrentUserId())") else { return }
            var request = URLRequest(url: url)
            request.addValue(Utility.getCurrentUserToken(), forHTTPHeaderField: "token")
            request.addValue("true", forHTTPHeaderField: "delete_permanently")
            request.setValue(Utility.zyloApiKey, forHTTPHeaderField: "x-api-key")
            
            request.httpMethod = "DELETE"
            
            URLSession.shared.dataTask(with: request) { data, response, error in
              DispatchQueue.main.async {
                  success(data!)
              }
            }.resume()
        } else {
            let error = NSError(domain: "", code: Constants().networkConnectionErrorCode, userInfo: [NSLocalizedDescriptionKey : "Network connection is not available."])
            failure(error)
        }
    }
}
