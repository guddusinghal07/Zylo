//
//  PetProfileService.swift
//  Zylo
//
//  Created by Sathish on 25/03/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class PetProfileService {

    // method to get pet profile
    static func getPetProfile(petId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)"
        APIService.getRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
    // method to create pet profile
    static func CreatePet(postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management"
        APIService.postRequest(urlString: url, postData: postData, onSuccess: success, onFailure: failure)
    }
    
    // method to update pet profile
    static func UpdatePet(petId: Int, postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)"
        APIService.putRequest(urlString: url, postData: postData, onSuccess: success, onFailure: failure)
    }
    
    // method to delete pet profile
    static func DeletePet(petId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "pet-management/\(petId)"
        APIService.deleteRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
}
