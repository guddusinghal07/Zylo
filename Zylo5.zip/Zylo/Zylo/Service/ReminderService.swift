//
//  ReminderService.swift
//  Zylo
//
//  Created by Sathish on 08/06/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class ReminderService {
    
    // method to get reminder
    static func getReminder(reminderId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "utilities/reminder-management/\(reminderId)"
        APIService.getRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
    // method to create reminder
    static func addReminder(postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "utilities/reminder-management"
        APIService.postRequest(urlString: url, postData: postData, onSuccess: success, onFailure: failure)
    }
    
    // method to update reminder
    static func UpdateReminder(reminderId: Int, postData: NSDictionary, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "utilities/reminder-management/\(reminderId)"
        APIService.putRequest(urlString: url, postData: postData, onSuccess: success, onFailure: failure)
    }
    
    // method to delete reminder
    static func DeleteReminder(reminderId: Int, onSuccess success: @escaping (_ result: Data) -> Void, onFailure failure: @escaping (_ error: Error?) -> Void) {
        let url = Constants().BaseUrl + "utilities/reminder-management/\(reminderId)"
        APIService.deleteRequest(urlString: url, onSuccess: success, onFailure: failure)
    }
    
}
