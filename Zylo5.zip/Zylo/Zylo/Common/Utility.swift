//
//  Utility.swift
//  Zylo
//
//  Created by Sathish on 13/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit
import SystemConfiguration
import DropDown

class Utility {    
    // Method to check internet connection
    static func isInternetAvailable() -> Bool {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        return (isReachable && !needsConnection)
    }
    
    static func setupDropdownAppreance() {
        let appearance = DropDown.appearance()
                
        appearance.cellHeight = 60
        appearance.backgroundColor = UIColor(white: 1, alpha: 1)
        appearance.selectionBackgroundColor = UIColor(red: 90.0/255.0, green: 74.0/255.0, blue: 152/255.0, alpha: 0.4)
        appearance.separatorColor = UIColor(white: 0.7, alpha: 0.8)
        appearance.cornerRadius = 10
        appearance.shadowColor = UIColor(white: 0.6, alpha: 1)
        appearance.shadowOpacity = 0.9
        appearance.shadowRadius = 25
        appearance.animationduration = 0.25
        appearance.textColor = .darkGray
        appearance.textFont = UIFont.openSansFontOfSize(size: 16)

        if #available(iOS 11.0, *) {
            appearance.setupMaskedCorners([.layerMaxXMaxYCorner, .layerMinXMaxYCorner])
        }
    }
    
    static func setView(view: UIView, hidden: Bool) {
        UIView.transition(with: view, duration: 0.5, options: .curveEaseIn, animations: {
            view.isHidden = hidden
        })
    }
    
    static func setRightNavigationButton(target:UIViewController, title: String, action: Selector) {
        let rightButtonItem: UIBarButtonItem = UIBarButtonItem(title: title, style: .done, target: target, action: action)
        rightButtonItem.setTitleTextAttributes([
            NSAttributedString.Key.font : UIFont.openSansSemiboldFontOfSize(size: 17)!,
            NSAttributedString.Key.foregroundColor : Constants().headerButtonColor,
        ], for: .normal)
        
        /*let button = UIButton(type: .custom)
        //set image for button
        if(title == "Save"){
            button.setImage(UIImage(named: "save"), for: .normal)
        } else if(title == "Add") {
            button.setImage(UIImage(named: "add"), for: .normal)
        }
        button.titleLabel?.font = UIFont.openSansSemiboldFontOfSize(size: 17)!
        button.tintColor = Constants().headerButtonColor
        //add function for button
        button.addTarget(target, action: action, for: .touchUpInside)
        let barButton = UIBarButtonItem(customView: button)*/
        
        target.navigationItem.rightBarButtonItem = rightButtonItem
    }
    
    static func setUserNavigationButton(target:UIViewController, action: Selector) {
        let size: Int = 30
        let v = ImageLoader(frame: CGRect(x: 0, y: 0, width: size, height: size))
        v.loadUserImage()
        v.layer.masksToBounds = true
        v.layer.cornerRadius = v.frame.height / 2
        v.layer.borderColor = UIColor.gray.cgColor
        v.layer.borderWidth = 2
        
        let barButton = UIBarButtonItem(customView: v)
        barButton.customView?.widthAnchor.constraint(equalToConstant: CGFloat(size)).isActive = true
        barButton.customView?.heightAnchor.constraint(equalToConstant: CGFloat(size)).isActive = true
        target.navigationItem.rightBarButtonItem = barButton
        barButton.customView?.addGestureRecognizer(UITapGestureRecognizer(target: target, action: action))
    }
    
    static func setRightNavigationButton(target:UIViewController, image: UIImage, action: Selector) {
        let size: Int = 30
        let v = ImageLoader(frame: CGRect(x: 0, y: 0, width: size, height: size))
        v.image = image
        v.layer.masksToBounds = true
        v.layer.cornerRadius = v.frame.height / 2
        v.layer.borderColor = UIColor.white.cgColor
        v.layer.borderWidth = 2
        
        let barButton = UIBarButtonItem(customView: v)
        barButton.customView?.widthAnchor.constraint(equalToConstant: CGFloat(size)).isActive = true
        barButton.customView?.heightAnchor.constraint(equalToConstant: CGFloat(size)).isActive = true
        target.navigationItem.rightBarButtonItem = barButton
        barButton.customView?.addGestureRecognizer(UITapGestureRecognizer(target: target, action: action))
    }
    
    static func setUserNameNavigationItem(target: UIViewController) {
        let title: String = "Hello " + Utility.getCurrentUserGivenName() + "!"
        let leftButtonItem: UIBarButtonItem = UIBarButtonItem(title: title, style: .done, target: target, action: nil)
        leftButtonItem.setTitleTextAttributes([
            NSAttributedString.Key.font : UIFont.openSansFontOfSize(size: 24)!,
            NSAttributedString.Key.foregroundColor : Constants().headerButtonColor,
        ], for: .normal)
        target.navigationItem.leftBarButtonItem = leftButtonItem
    }
    
    static func getRetinaScale(_ size:CGFloat) -> CGFloat {
        if UIDevice.current.userInterfaceIdiom == UIUserInterfaceIdiom.pad {
            return CGFloat(OpenSans.retinaScaleFactor) * size
        }
        return size
    }
    
    static func getDateFromString(dateString: String) -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let date = dateFormatter.date(from: dateString)
        return date!
    }
    
    static func getStringFromDate(dateString: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let date = dateFormatter.string(from: dateString)
        return date
    }
    
    public static func  convertImageToBase64String(image : UIImage ) -> String {
        let strBase64 =  image.pngData()?.base64EncodedString()
        return strBase64!
    }
    
    static func isKeyPresentInUserDefaults(key: String) -> Bool {
        return UserDefaults.standard.object(forKey: key) != nil
    }
    
    static func setLoggedInUserDetails(userToken: String, userName: String, givenName: String, familyName: String, email: String) {
        UserDefaults.standard.set(userToken, forKey: Constants().LoggedInUserToken)
        UserDefaults.standard.set(userName, forKey: Constants().LoggedInUserFullName)
        UserDefaults.standard.set(givenName, forKey: Constants().LoggedInUserGivenName)
        UserDefaults.standard.set(familyName, forKey: Constants().LoggedInUserFamilyName)
        UserDefaults.standard.set(email, forKey: Constants().LoggedInUserEmail)
    }
    
    static func setLoggedInUserDetails(userName: String, givenName: String, familyName: String) {
        UserDefaults.standard.set(userName, forKey: Constants().LoggedInUserFullName)
        UserDefaults.standard.set(givenName, forKey: Constants().LoggedInUserGivenName)
        UserDefaults.standard.set(familyName, forKey: Constants().LoggedInUserFamilyName)
    }
    
    static func setLoggedInUserId(userId: Int) {
        UserDefaults.standard.set(userId, forKey: Constants().LoggedInUserId)
    }
    
    static func setLoggedInUserImageUrl(userImageUrl: String) {
        UserDefaults.standard.set(userImageUrl, forKey: Constants().LoggedInUserImageUrl)
    }
    
    static func setDefaultPet(petId: Int, petName: String) {
        UserDefaults.standard.set(petId, forKey: Constants().defaultPetId)
        UserDefaults.standard.set(petName, forKey: Constants().defaultPetName)
    }
    
    static func getCurrentUserId() -> Int {
        if(self.isKeyPresentInUserDefaults(key: Constants().LoggedInUserId)) {
            return UserDefaults.standard.object(forKey: Constants().LoggedInUserId) as! Int
        }
        return -1
    }
    
    static func getCurrentUserToken() -> String {
        if(self.isKeyPresentInUserDefaults(key: Constants().LoggedInUserToken)) {
            return UserDefaults.standard.object(forKey: Constants().LoggedInUserToken) as! String
        }
        return ""
    }
    
    static func getCurrentUserFullName() -> String {
        if(self.isKeyPresentInUserDefaults(key: Constants().LoggedInUserFullName)) {
            return UserDefaults.standard.object(forKey: Constants().LoggedInUserFullName) as! String
        }
        return ""
    }
    
    static func getCurrentUserGivenName() -> String {
        if(self.isKeyPresentInUserDefaults(key: Constants().LoggedInUserGivenName)) {
            return UserDefaults.standard.object(forKey: Constants().LoggedInUserGivenName) as! String
        }
        return ""
    }
    
    static func getCurrentUserFamilyName() -> String {
        if(self.isKeyPresentInUserDefaults(key: Constants().LoggedInUserFamilyName)) {
            return UserDefaults.standard.object(forKey: Constants().LoggedInUserFamilyName) as! String
        }
        return ""
    }
    
    static func getCurrentUserEmail() -> String {
        if(self.isKeyPresentInUserDefaults(key: Constants().LoggedInUserEmail)) {
            return UserDefaults.standard.object(forKey: Constants().LoggedInUserEmail) as! String
        }
        return ""
    }
    
    static func getCurrentUserImageUrl() -> String {
        if(self.isKeyPresentInUserDefaults(key: Constants().LoggedInUserImageUrl)) {
            return (UserDefaults.standard.object(forKey: Constants().LoggedInUserImageUrl) as! String).addingPercentEncoding(withAllowedCharacters: .urlFragmentAllowed)!
        }
        return ""
    }
    
    static func getDefaultPetId() -> Int {
        if(self.isKeyPresentInUserDefaults(key: Constants().defaultPetId)) {
            return UserDefaults.standard.object(forKey: Constants().defaultPetId) as! Int
        }
        return -1
    }
    
    static func getDefaultPetName() -> String {
        if(self.isKeyPresentInUserDefaults(key: Constants().defaultPetName)) {
            return UserDefaults.standard.object(forKey: Constants().defaultPetName) as! String
        }
        return ""
    }
    
    static func LogoutCurrentUser() {
        UserDefaults.standard.removeObject(forKey: Constants().LoggedInUserId)
        UserDefaults.standard.removeObject(forKey: Constants().LoggedInUserFullName)
        UserDefaults.standard.removeObject(forKey: Constants().LoggedInUserGivenName)
        UserDefaults.standard.removeObject(forKey: Constants().LoggedInUserFamilyName)
        UserDefaults.standard.removeObject(forKey: Constants().LoggedInUserEmail)
        UserDefaults.standard.removeObject(forKey: Constants().LoggedInUserImageUrl)
    }
    
    static func setPetProfileToShow() {
        UserDefaults.standard.set(true, forKey: Constants().showPetProfileOnLoad)
    }
    
    static func removePetProfileToShow() {
        UserDefaults.standard.removeObject(forKey: Constants().showPetProfileOnLoad)
    }
    
    static func isPetProfileAllowedToShowOnLoad() -> Bool {
        if(self.isKeyPresentInUserDefaults(key: Constants().showPetProfileOnLoad)) {
            return UserDefaults.standard.object(forKey: Constants().showPetProfileOnLoad) as! Bool
        }
        return false
    }
    
    static func getImage(from url: URL, onSuccess success: @escaping (_ result: UIImage) -> Void) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() {
                success(image)
            }
        }.resume()
    }
    
    func getAllTextFields(fromView view: UIView)-> [UITextField] {
        return view.subviews.compactMap { (view) -> [UITextField]? in
            if view is UITextField {
                return [(view as! UITextField)]
            } else {
                return getAllTextFields(fromView: view)
            }
        }.flatMap({$0})
    }
    
    static var zyloApiKey: String? {
        return Bundle.main.object(forInfoDictionaryKey: "ZyloApiKey") as? String
    }
}
