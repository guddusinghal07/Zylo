//
//  ImageLoader.swift
//  Zylo
//
//  Created by Sathish on 03/04/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class ImageView: UIView {
    
    let activityIndicator = UIActivityIndicatorView()
    let shadowLayer = CALayer()
    var imageURL: URL?
    var imageLayer: CALayer!
    var image: UIImage? {
        didSet { refreshImage() }
    }
    
    /*override var intrinsicContentSize:
        CGSize {
        return CGSize(width: 200, height: 200)
    }*/
    
    func refreshImage() {
        if let imageLayer = imageLayer, let image = image {
            imageLayer.contents = image.cgImage
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.setupShadowLayer()
        refreshImage()
    }
    
    func setupShadowLayer() {
        if imageLayer == nil {
            let radius: CGFloat = 20
            
            shadowLayer.shadowColor = UIColor.white.cgColor
            shadowLayer.shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: radius).cgPath
            shadowLayer.shadowOffset = CGSize(width: Constants.shadowOffset, height: Constants.shadowOffset)
            shadowLayer.shadowOpacity = 0.7
            shadowLayer.shadowRadius = 4.0
            layer.addSublayer(shadowLayer)
            
            let maskLayer = CAShapeLayer()
            maskLayer.path = UIBezierPath(roundedRect: bounds, cornerRadius: radius).cgPath
            
            imageLayer = CALayer()
            imageLayer.mask = maskLayer
            imageLayer.frame = bounds
            imageLayer.backgroundColor = UIColor.clear.cgColor
            imageLayer.contentsGravity = CALayerContentsGravity.resizeAspectFill
            layer.addSublayer(imageLayer)
        }
    }

    func loadImageWithUrl(_ url: URL, defaultImage: UIImage) {
        // setup activityIndicator...
        activityIndicator.color = .darkGray

        addSubview(activityIndicator)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        activityIndicator.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true

        imageURL = url

        self.setupShadowLayer()
        
        image = nil
        activityIndicator.startAnimating()
        
        self.contentMode = .scaleAspectFill
        
        // retrieves image if already available in cache
        if let imageFromCache = Constants.imageCache.object(forKey: url as AnyObject) as? UIImage {
            self.image = imageFromCache
            activityIndicator.stopAnimating()
            self.shadowLayer.shadowColor = UIColor.gray.cgColor
            return
        }

        // image does not available in cache.. so retrieving it from url...
        URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
            if error != nil {
                DispatchQueue.main.async(execute: {
                    self.image = defaultImage
                    self.activityIndicator.stopAnimating()
                    self.shadowLayer.shadowColor = UIColor.gray.cgColor
                })
                return
            }

            DispatchQueue.main.async(execute: {
                if let unwrappedData = data, let imageToCache = UIImage(data: unwrappedData) {
                    if self.imageURL == url {
                        self.image = imageToCache
                    } else {
                        self.image = defaultImage
                    }
                    Constants.imageCache.setObject(imageToCache, forKey: url as AnyObject)
                } else {
                    self.image = defaultImage
                }
                self.activityIndicator.stopAnimating()
                self.shadowLayer.shadowColor = UIColor.gray.cgColor
            })
        }).resume()
    }
    
    func removeImageFromCache(_ url: URL) {
        Constants.imageCache.removeObject(forKey: url as AnyObject)
    }
    
}

class ImageLoader: UIImageView {
    var imageURL: URL?
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
    }

    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    let activityIndicator = UIActivityIndicatorView()

    func loadImageWithUrl(_ url: URL, defaultImage: UIImage) {
        // setup activityIndicator...
        activityIndicator.color = .darkGray

        addSubview(activityIndicator)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        activityIndicator.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true

        imageURL = url

        image = nil
        activityIndicator.startAnimating()
        
        self.contentMode = .scaleAspectFill
        
        // retrieves image if already available in cache
        if let imageFromCache = Constants.imageCache.object(forKey: url as AnyObject) as? UIImage {
            self.image = imageFromCache
            activityIndicator.stopAnimating()
            return
        }

        // image does not available in cache.. so retrieving it from url...
        URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
            if error != nil {
                DispatchQueue.main.async(execute: {
                    self.image = defaultImage
                    self.activityIndicator.stopAnimating()
                })
                return
            }

            DispatchQueue.main.async(execute: {
                if let unwrappedData = data, let imageToCache = UIImage(data: unwrappedData) {
                    if self.imageURL == url {
                        self.image = imageToCache
                    } else {
                        self.image = defaultImage
                    }
                    Constants.imageCache.setObject(imageToCache, forKey: url as AnyObject)
                } else {
                    self.image = defaultImage
                }
                self.activityIndicator.stopAnimating()
            })
        }).resume()
    }
    
    func removeImageFromCache(_ url: URL) {
        Constants.imageCache.removeObject(forKey: url as AnyObject)
    }
}
