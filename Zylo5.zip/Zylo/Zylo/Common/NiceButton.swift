//
//  NiceButton.swift
//  Zylo
//
//  Created by Sathish on 22/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class NiceButton: UIButton {
    let view = UIView()
    open var errorLabel: UILabel!
    var lineHeight: CGFloat = 0.0
    
    enum VerticalAlignment : String {
        case center, top, bottom, unset
    }

    enum HorizontalAlignment : String {
        case center, left, right, unset
    }

    let _border = CAShapeLayer()
     
    override func awakeFromNib() {
        super.awakeFromNib()
                
        self.createErrorLabel()
        
        if(!dashedBorder) {
            view.backgroundColor = UIColor.lightGray // UIColor(red: 0.6494, green: 0.8155, blue: 1.0, alpha: 1.0)
            
            view.translatesAutoresizingMaskIntoConstraints = false
            addSubview(view)
            
            view.addConstraint(NSLayoutConstraint(item: view, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: 1))
            addConstraint(NSLayoutConstraint(item: view, attribute: .left, relatedBy: .equal, toItem: self, attribute: .left, multiplier: 1, constant: 1))
            addConstraint(NSLayoutConstraint(item: view, attribute: .right, relatedBy: .equal, toItem: self, attribute: .right, multiplier: 1, constant: 1))
            addConstraint(NSLayoutConstraint(item: view, attribute: .bottom, relatedBy: .equal, toItem: self, attribute: .bottom, multiplier: 1, constant: 10.0))
        }
    }

    @IBInspectable
    var dashedBorder: Bool = false {
        didSet {
            setNeedsLayout()
        }
    }
    
    @IBInspectable
    var cornerRadius: CGFloat = 20.0 {
        didSet {
            setNeedsLayout()
        }
    }
    
    @IBInspectable
    var dashColor: UIColor = Constants().themeColor {
        didSet {
            setNeedsLayout()
        }
    }
    
    @IBInspectable
    var betweenDashesSpace: CGFloat = 6.0 {
        didSet {
            setNeedsLayout()
        }
    }
    
    @IBInspectable
    var dashLength: CGFloat = 16.0 {
        didSet {
            setNeedsLayout()
        }
    }
    
    @IBInspectable
    var imageToTitleSpacing: CGFloat = 8.0 {
        didSet {
            setNeedsLayout()
        }
    }
    
    var imageVerticalAlignment: VerticalAlignment = .unset {
        didSet {
            setNeedsLayout()
        }
    }

    var imageHorizontalAlignment: HorizontalAlignment = .unset {
        didSet {
            setNeedsLayout()
        }
    }
    
    @available(*, unavailable, message: "This property is reserved for Interface Builder. Use 'imageVerticalAlignment' instead.")
    @IBInspectable
    var imageVerticalAlignmentName: String {
        get {
            return imageVerticalAlignment.rawValue
        }
        set {
            if let value = VerticalAlignment(rawValue: newValue) {
                imageVerticalAlignment = value
            } else {
                imageVerticalAlignment = .unset
            }
        }
    }

    @available(*, unavailable, message: "This property is reserved for Interface Builder. Use 'imageHorizontalAlignment' instead.")
    @IBInspectable
    var imageHorizontalAlignmentName: String {
        get {
            return imageHorizontalAlignment.rawValue
        }
        set {
            if let value = HorizontalAlignment(rawValue: newValue) {
                imageHorizontalAlignment = value
            } else {
                imageHorizontalAlignment = .unset
            }
        }
    }
    
    var extraContentEdgeInsets: UIEdgeInsets = UIEdgeInsets.zero
    
    override var contentEdgeInsets: UIEdgeInsets {
        get {
            return super.contentEdgeInsets
        }
        set {
            super.contentEdgeInsets = newValue
            self.extraContentEdgeInsets = newValue
        }
    }
    
    var extraImageEdgeInsets: UIEdgeInsets = UIEdgeInsets.zero
    
    override var imageEdgeInsets: UIEdgeInsets {
        get {
            return super.imageEdgeInsets
        }
        set {
            super.imageEdgeInsets = newValue
            self.extraImageEdgeInsets = newValue
        }
    }
    
    var extraTitleEdgeInsets: UIEdgeInsets = UIEdgeInsets.zero
    
    override var titleEdgeInsets: UIEdgeInsets {
        get {
            return super.titleEdgeInsets
        }
        set {
            super.titleEdgeInsets = newValue
            self.extraTitleEdgeInsets = newValue
        }
    }
 
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        self.imageEdgeInsets = super.imageEdgeInsets
        self.titleEdgeInsets = super.titleEdgeInsets
        self.contentEdgeInsets = super.contentEdgeInsets
        
        self.setAppearance()
        self.setupDashedBorder()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setAppearance()
        self.setupDashedBorder()
    }
    
    override func prepareForInterfaceBuilder() {
        self.setAppearance()
        self.setupDashedBorder()
    }
    
    func setupDashedBorder() {
        if(dashedBorder) {
            _border.strokeColor = Constants().themeColor.cgColor
            _border.fillColor = UIColor.clear.cgColor
            _border.lineDashPattern = [16, 6]
            _border.lineWidth = 2
            _border.lineJoin = CAShapeLayerLineJoin.round
            self.layer.addSublayer(_border)
            self.layer.cornerRadius = cornerRadius
            self.layer.masksToBounds = true
        }
    }
    
    func setAppearance() {
        if let imageSize = self.imageView?.image?.size,
            let font = self.titleLabel?.font,
            let textSize = self.titleLabel?.attributedText?.size() ?? self.titleLabel?.text?.size(withAttributes: [NSAttributedString.Key.font: font]) {
            
            var imageEdgeInsets = UIEdgeInsets.zero
            var titleEdgeInsets = UIEdgeInsets.zero
            var contentEdgeInsets = UIEdgeInsets.zero
            
            let halfImageToTitleSpacing = imageToTitleSpacing / 2.0
            
            switch imageVerticalAlignment {
            case .bottom:
                imageEdgeInsets.top = (textSize.height + imageToTitleSpacing) / 2.0
                imageEdgeInsets.bottom = (-textSize.height - imageToTitleSpacing) / 2.0
                titleEdgeInsets.top = (-imageSize.height - imageToTitleSpacing) / 2.0
                titleEdgeInsets.bottom = (imageSize.height + imageToTitleSpacing) / 2.0
                contentEdgeInsets.top = (min(imageSize.height, textSize.height) + imageToTitleSpacing) / 2.0
                contentEdgeInsets.bottom = (min(imageSize.height, textSize.height) + imageToTitleSpacing) / 2.0
                //only works with contentVerticalAlignment = .center
                contentVerticalAlignment = .center
            case .top:
                imageEdgeInsets.top = (-textSize.height - imageToTitleSpacing) / 2.0
                imageEdgeInsets.bottom = (textSize.height + imageToTitleSpacing) / 2.0
                titleEdgeInsets.top = (imageSize.height + imageToTitleSpacing) / 2.0
                titleEdgeInsets.bottom = (-imageSize.height - imageToTitleSpacing) / 2.0
                contentEdgeInsets.top = (min(imageSize.height, textSize.height) + imageToTitleSpacing) / 2.0
                contentEdgeInsets.bottom = (min(imageSize.height, textSize.height) + imageToTitleSpacing) / 2.0
                //only works with contentVerticalAlignment = .center
                contentVerticalAlignment = .center
            case .center:
                //only works with contentVerticalAlignment = .center
                contentVerticalAlignment = .center
                break
            case .unset:
                break
            }
            
            switch imageHorizontalAlignment {
            case .left:
                imageEdgeInsets.left = -halfImageToTitleSpacing
                imageEdgeInsets.right = halfImageToTitleSpacing
                titleEdgeInsets.left = halfImageToTitleSpacing
                titleEdgeInsets.right = -halfImageToTitleSpacing
                contentEdgeInsets.left = halfImageToTitleSpacing
                contentEdgeInsets.right = halfImageToTitleSpacing
            case .right:
                imageEdgeInsets.left = self.frame.size.width - halfImageToTitleSpacing - 20
                imageEdgeInsets.right = -self.frame.size.width - halfImageToTitleSpacing
                titleEdgeInsets.left = -imageSize.width - halfImageToTitleSpacing
                titleEdgeInsets.right = imageSize.width + halfImageToTitleSpacing
                contentEdgeInsets.left = halfImageToTitleSpacing
                contentEdgeInsets.right = halfImageToTitleSpacing
            case .center:
                imageEdgeInsets.left = textSize.width / 2.0
                imageEdgeInsets.right = -textSize.width / 2.0
                titleEdgeInsets.left = -imageSize.width / 2.0
                titleEdgeInsets.right = imageSize.width / 2.0
                contentEdgeInsets.left = -((imageSize.width + textSize.width) - max(imageSize.width, textSize.width)) / 2.0
                contentEdgeInsets.right = -((imageSize.width + textSize.width) - max(imageSize.width, textSize.width)) / 2.0
            case .unset:
                break
            }
            
            contentEdgeInsets.top += extraContentEdgeInsets.top + (hasErrorMessage ? 18.0 : 0.0)
            contentEdgeInsets.bottom += extraContentEdgeInsets.bottom
            contentEdgeInsets.left += extraContentEdgeInsets.left
            contentEdgeInsets.right += extraContentEdgeInsets.right
            
            imageEdgeInsets.top += extraImageEdgeInsets.top
            imageEdgeInsets.bottom += extraImageEdgeInsets.bottom
            imageEdgeInsets.left += extraImageEdgeInsets.left
            imageEdgeInsets.right += extraImageEdgeInsets.right
            
            titleEdgeInsets.top += extraTitleEdgeInsets.top + (hasErrorMessage ? 18.0 : 0.0)
            titleEdgeInsets.bottom += extraTitleEdgeInsets.bottom
            titleEdgeInsets.left += extraTitleEdgeInsets.left
            titleEdgeInsets.right += extraTitleEdgeInsets.right
            
            super.imageEdgeInsets = imageEdgeInsets
            super.titleEdgeInsets = titleEdgeInsets
            super.contentEdgeInsets = contentEdgeInsets
        } else {
            super.imageEdgeInsets = extraImageEdgeInsets
            super.titleEdgeInsets = extraTitleEdgeInsets
            super.contentEdgeInsets = extraContentEdgeInsets
        }
    }
        
    override func layoutSubviews() {
        self.setAppearance()
        super.layoutSubviews()
        _border.path = UIBezierPath(roundedRect: self.bounds, cornerRadius:self.cornerRadius).cgPath
        _border.frame = self.bounds
        self.setupDashedBorder()
    }
    
    fileprivate func createErrorLabel() {
        let errorLabel = UILabel()
        errorLabel.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        errorLabel.font = UIFont.openSansFontOfSize(size: 13)
        errorLabel.alpha = 0.0
        errorLabel.textColor = UIColor.red

        addSubview(errorLabel)
        self.errorLabel = errorLabel
    }
    
    var hasErrorMessage: Bool {
        return errorMessage != nil && errorMessage != ""
    }
        
    open var errorMessage: String? {
        didSet {
            self.updateControl()
        }
    }
    
    var titleFormatter: ((String) -> String) = { (text: String) -> String in
        if #available(iOS 9.0, *) {
            return text.localizedUppercase
        } else {
            return text.uppercased()
        }
    }
    
    func updateControl() {
        var errorText: String?
        if hasErrorMessage {
            self.view.backgroundColor = .red
            errorText = titleFormatter(errorMessage!)
        } else {
            self.view.backgroundColor = Constants().themeColor
        }
        self.errorLabel.text = errorText
        self.updateErrorVisibility(true)
        self.setAppearance()
    }
    
    fileprivate func updateErrorVisibility(_ animated: Bool = false, completion: ((_ completed: Bool) -> Void)? = nil) {
        let alpha: CGFloat = hasErrorMessage ? 1.0 : 0.0
        let height: CGFloat = hasErrorMessage ? 15.0 : 0.0
        let frame: CGRect = CGRect(x: 0, y: 0, width: bounds.size.width, height: height)
        let updateBlock = { () -> Void in
            self.errorLabel.alpha = alpha
            self.errorLabel.frame = frame
        }
        if animated {
            #if swift(>=4.2)
            let animationOptions: UIView.AnimationOptions = .curveEaseOut
            #else
            let animationOptions: UIViewAnimationOptions = .curveEaseOut
            #endif
            let duration = hasErrorMessage ? 0.2 : 0.3
            UIView.animate(withDuration: duration, delay: 0, options: animationOptions, animations: { () -> Void in
                updateBlock()
            }, completion: completion)
        } else {
            updateBlock()
            completion?(true)
        }
    }
    
    let activityIndicator = UIActivityIndicatorView()
    var imageURL: URL?
    
    func loadImageWithUrl(_ url: URL) {

        // setup activityIndicator...
        activityIndicator.color = .darkGray

        addSubview(activityIndicator)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        activityIndicator.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true

        imageURL = url

        setBackgroundImage(nil, for: .normal)
        activityIndicator.startAnimating()
        
        self.contentMode = .scaleAspectFill
        
        // retrieves image if already available in cache
        if let imageFromCache = Constants.imageCache.object(forKey: url as AnyObject) as? UIImage {
            self.setBackgroundImage(imageFromCache, for: .normal)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: Constants.reloadDescription), object: nil)
            activityIndicator.stopAnimating()
            return
        }

        // image does not available in cache.. so retrieving it from url...
        URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
            if error != nil {
                DispatchQueue.main.async(execute: {
                    self.activityIndicator.stopAnimating()
                })
                return
            }
            
            if let httpUrlResponse = response as? HTTPURLResponse
            {
                if (error != nil) {
                    print("Error Occurred: \(error!.localizedDescription)")
                } else {
                    print("\(httpUrlResponse.allHeaderFields)") // Error
                    if let xDemAuth = httpUrlResponse.allHeaderFields["x-amz-meta-activity_description"] as? String {
                       // use X-Dem-Auth here
                        UserDefaults.standard.set(xDemAuth, forKey: Constants.url)
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: Constants.reloadDescription), object: nil)
                    }
                }
            }
        
            DispatchQueue.main.async(execute: {
                if let unwrappedData = data, let imageToCache = UIImage(data: unwrappedData) {
                    if self.imageURL == url {
                        self.setBackgroundImage(imageToCache, for: .normal)
                    }
                    Constants.imageCache.setObject(imageToCache, forKey: url as AnyObject)
                }
                self.activityIndicator.stopAnimating()
            })
        }).resume()
    }
    
    func removeImageFromCache(_ url: URL) {
        Constants.imageCache.removeObject(forKey: url as AnyObject)
    }
}
