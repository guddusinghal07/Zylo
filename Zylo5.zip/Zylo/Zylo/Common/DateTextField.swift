//
//  DateTextField.swift
//  Zylo
//
//  Created by Sathish on 07/06/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class DateTextField: TextField {

    var callback : ((Date)->())?
    
    var calendar = Calendar(identifier: Calendar.Identifier.iso8601)
    var selectedDate: Date! = Date() {
        didSet {
            setDate()
        }
    }
    
    func setDate() {
        let month = calendar.dateComponents([.month], from: selectedDate).month!
        let monthName = GetHumanDate(month: month, language: .english)
        let day = calendar.component(.day, from: selectedDate)
        let year = calendar.component(.year, from: selectedDate)
        self.text = monthName + " " + String(day) + ", " + String(year)
        callback?(selectedDate)
        self.endEditing(true)
    }
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        initDateField()
    }
    
    func initDateField() {
        
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image = UIImage(named: "calendar")
        imageView.image = image
        self.rightView?.frame = self.rightViewRect(forBounds: self.bounds)

              self.rightViewMode = UITextField.ViewMode.always
              self.rightView = imageView
              self.inputView = UIView() // Hide keyboard, but show blinking cursor
        selectedDate = Date()

    }
    
    override open func becomeFirstResponder() -> Bool {
        let result = super.becomeFirstResponder()
        self.endEditing(true)
        self.showCalendar()
        return result
    }
    
    func showCalendar() {
        let xibView = Bundle.main.loadNibNamed("CalendarPopUp", owner: nil, options: nil)?[0] as! CalendarPopUp
        xibView.calendarDelegate = self
        xibView.selected = selectedDate
    PopupContainer.generatePopupWithView(xibView).show(self.parentViewController!.view)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.clipsToBounds = true
        initDateField()
    }
    
    
    
}

extension DateTextField: CalendarPopUpDelegate {
    func dateChaged(date: Date) {
        selectedDate = date
    }
}
