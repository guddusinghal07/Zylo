//
//  OpenSans.swift
//  Zylo
//
//  Created by Sathish on 12/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

public class OpenSans {
    
    /// scale factor for retina devices.
    public static var retinaScaleFactor: Float = 1.5
    
    public class func registerFonts() {
        let fontNames = [
            "OpenSans-Regular",
            "OpenSans-Bold",
            "OpenSans-BoldItalic",
            "OpenSans-ExtraBold",
            "OpenSans-ExtraBoldItalic",
            "OpenSans-Italic",
            "OpenSans-Light",
            "OpenSans-LightItalic",
            "OpenSans-Semibold",
            "OpenSans-SemiboldItalic"
        ]
        
        var error: Unmanaged<CFError>? = nil
        
        for font in fontNames {
            let url = Bundle(for: OpenSans.self).url(forResource: font, withExtension: "ttf")
            if (url != nil) {
                CTFontManagerRegisterFontsForURL(url! as CFURL, CTFontManagerScope.none, &error)
            }
        }
    }
}
