//
//  Extension.swift
//  Zylo
//
//  Created by Sathish on 15/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit
import DropDown

extension UIFont {
    public class func openSansFontOfSize(size: Float) -> UIFont! {
        return UIFont(name: "OpenSans", size: makeSize(size))
    }
    
    public class func openSansBoldFontOfSize(size: Float) -> UIFont! {
        return UIFont(name: "OpenSans-Bold", size: makeSize(size))
    }
    
    public class func openSansBoldItalicFontOfSize(size: Float) -> UIFont! {
        return UIFont(name: "OpenSans-BoldItalic", size: makeSize(size))
    }
    
    public class func openSansExtraBoldFontOfSize(size: Float) -> UIFont! {
        return UIFont(name: "OpenSans-Extrabold", size: makeSize(size))
    }
    
    public class func openSansExtraBoldItalicFontOfSize(size: Float) -> UIFont! {
        return UIFont(name: "OpenSans-ExtraboldItalic", size: makeSize(size))
    }
    
    public class func openSansItalicFontOfSize(size: Float) -> UIFont! {
        return UIFont(name: "OpenSans-Italic", size: makeSize(size))
    }
    
    public class func openSansLightFontOfSize(size: Float) -> UIFont! {
        return UIFont(name: "OpenSans-Light", size: makeSize(size))
    }
    
    public class func openSansLightItalicFontOfSize(size: Float) -> UIFont! {
        return UIFont(name: "OpenSansLight-Italic", size: makeSize(size))
    }
    
    public class func openSansSemiboldFontOfSize(size: Float) -> UIFont! {
        return UIFont(name: "OpenSans-Semibold", size: makeSize(size))
    }
    
    public class func openSansSemiboldItalicFontOfSize(size: Float) -> UIFont! {
        return UIFont(name: "OpenSans-SemiboldItalic", size: makeSize(size))
    }
    
    class func makeSize(_ size: Float) -> CGFloat {
        if UIDevice.current.userInterfaceIdiom == UIUserInterfaceIdiom.pad {
            return CGFloat(size * OpenSans.retinaScaleFactor)
        }
        return CGFloat(size)
    }
}

extension UITextField {
    func setBottomBorder(borderColor: UIColor) {
        self.borderStyle = UITextField.BorderStyle.none
        self.backgroundColor = UIColor.clear
        let width = 1.0
        
        let borderLine = UIView()
        borderLine.frame = CGRect(x: 0, y: Double(self.frame.height+10) - width, width: Double(self.frame.width), height: width)
        
        borderLine.backgroundColor = borderColor
        
        /*let paddingView = UIView(frame: CGRect(x: 0, y: 10, width: 10, height: self.frame.height))
        self.leftView = paddingView
        self.leftViewMode = .always*/
        
        self.addSubview(borderLine)
        borderLine.autoresizingMask = [.flexibleLeftMargin,.flexibleTopMargin,.flexibleRightMargin,.flexibleWidth]
    }
    
    @IBInspectable var doneAccessory: Bool{
        get{
            return self.doneAccessory
        }
        set (hasDone) {
            if hasDone{
                addDoneButtonOnKeyboard()
            }
        }
    }
    
    func addDoneButtonOnKeyboard()
    {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        doneToolbar.barStyle = .default
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(self.doneButtonAction))
        
        let items = [flexSpace, done]
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        
        self.inputAccessoryView = doneToolbar
    }
    
    @objc func doneButtonAction() {
        self.resignFirstResponder()
    }
    
    func setInputViewDatePicker() {
        // Create a UIDatePicker object and assign to inputView
        let screenWidth = UIScreen.main.bounds.width
        let datePicker = UIDatePicker(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 216))//1
        datePicker.datePickerMode = .date //2
        self.inputView = datePicker //3
        
        // Create a toolbar and assign it to inputAccessoryView
        let toolBar = UIToolbar(frame: CGRect(x: 0.0, y: 0.0, width: screenWidth, height: 44.0)) //4
        let flexible = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil) //5
        let cancel = UIBarButtonItem(title: "Cancel", style: .plain, target: nil, action: #selector(tapCancel)) // 6
        let barButton = UIBarButtonItem(title: "Done", style: .plain, target: nil, action: #selector(tapDone)) //7
        toolBar.setItems([cancel, flexible, barButton], animated: false) //8
        self.inputAccessoryView = toolBar //9
    }
    
    @objc func tapCancel() {
        self.resignFirstResponder()
    }
    
    @objc func tapDone() {
        if let datePicker = self.inputView as? UIDatePicker { // 2-1
            self.setDate(dt: datePicker.date)
        }
        self.resignFirstResponder() // 2-5
    }
    
    func setDate(dt:Date) {
        let dateformatter = DateFormatter()
        dateformatter.dateStyle = .medium
        self.text = dateformatter.string(from: dt)
    }
    
    func getDate() -> String {
        if(self.text!.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            let dateformatter = DateFormatter()
            dateformatter.dateStyle = .medium
            let dat = dateformatter.date(from: self.text!)
            dateformatter.dateFormat = "yyyy-MM-dd"
            return dateformatter.string(from: dat!)
        } else {
            return ""
        }
    }
    
    func isEmpty() -> Bool {
        return self.text!.isEmpty
    }
    
    func fixCaretPosition() {
        // Moving the caret to the correct position by removing the trailing whitespace
        // http://stackoverflow.com/questions/14220187/uitextfield-has-trailing-whitespace-after-securetextentry-toggle
        let beginning = beginningOfDocument
        selectedTextRange = textRange(from: beginning, to: beginning)
        let end = endOfDocument
        selectedTextRange = textRange(from: end, to: end)
    }
    
    func setDateImage() {
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        let image = UIImage(named: "calendar")
        imageView.image = image
        
        self.rightViewMode = UITextField.ViewMode.always
        self.rightView = imageView
    }
}

extension String {
    struct NumberFormat
    {
        static let instance = NumberFormatter()
    }
    var integerValue:Int? {
        if self.isEmpty {
            return 0
        } else {
            return (NumberFormat.instance.number(from: self)?.intValue) ?? 0
        }
    }
    
    var toDate:Date? {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy-MM-dd"
        return dateformatter.date(from: self)
    }
    
    func attributedText(boldString: String, font: UIFont) -> NSAttributedString {
        let attributedString = NSMutableAttributedString(string: self,
                                                     attributes: [NSAttributedString.Key.font: font])
        let boldFontAttribute: [NSAttributedString.Key: Any] = [NSAttributedString.Key.font: UIFont.openSansBoldFontOfSize(size: Float(font.pointSize)) as Any]
        let range = (self as NSString).range(of: boldString)
        attributedString.addAttributes(boldFontAttribute, range: range)
        return attributedString
    }
}

extension UIImageView {
    func downloaded(from url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFit) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() {
                self.image = image
            }
        }.resume()
    }
    
    func downloaded(from link: String, contentMode mode: UIView.ContentMode = .scaleAspectFit) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
    
    private func roundedPolygonPath(rect: CGRect, lineWidth: CGFloat, sides: NSInteger, cornerRadius: CGFloat)
     -> UIBezierPath {
        let path = UIBezierPath()
        let theta: CGFloat = CGFloat(2.0 * Double.pi) / CGFloat(sides) // How much to turn at every corner
        //let offset: CGFloat = cornerRadius * tan(theta / 2.0)     // Offset from which to start rounding corners
        let width = min(rect.size.width, rect.size.height)        // Width of the square

        let center = CGPoint(x: rect.origin.x + width / 2.0, y: rect.origin.y + width / 2.0)

        // Radius of the circle that encircles the polygon
        // Notice that the radius is adjusted for the corners, that way the largest outer
        // dimension of the resulting shape is always exactly the width - linewidth
        let radius = (width - lineWidth + cornerRadius - (cos(theta) * cornerRadius)) / 2.0

        // Start drawing at a point, which by default is at the right hand edge
        // but can be offset
        var angle: CGFloat = CGFloat(Double.pi / 2.0)

        let corner = CGPoint(x: center.x + (radius - cornerRadius) * cos(angle), y: center.y + (radius - cornerRadius) * sin(angle))
        path.move(to: CGPoint(x: corner.x + cornerRadius * cos(angle + theta), y: corner.y + cornerRadius * sin(angle + theta)))

        for _ in 0 ..< sides {
            angle += theta

            let corner = CGPoint(x: center.x + (radius - cornerRadius) * cos(angle), y: center.y + (radius - cornerRadius) * sin(angle))
            let tip = CGPoint(x: center.x + radius * cos(angle), y: center.y + radius * sin(angle))
            let start = CGPoint(x: corner.x + cornerRadius * cos(angle - theta), y: corner.y + cornerRadius * sin(angle - theta))
            let end = CGPoint(x: corner.x + cornerRadius * cos(angle + theta), y: corner.y + cornerRadius * sin(angle + theta))

            path.addLine(to: start)
            path.addQuadCurve(to: end, controlPoint: tip)
        }

        path.close()

        // Move the path to the correct origins
        let bounds = path.bounds
        //let transform = CGAffineTransform(translationX: -bounds.origin.x + rect.origin.x + lineWidth / 2.0, y: -bounds.origin.y + rect.origin.y + lineWidth / 2.0)
        let transform = CGAffineTransform(translationX: -bounds.origin.x + rect.origin.x + lineWidth, y: -bounds.origin.y + rect.origin.y + lineWidth / 2)
        
        path.apply(transform)

        return path
    }
    
    func setHexagonImageView() {
        let lineWidth: CGFloat = 5
        let path = self.roundedPolygonPath(rect: self.bounds, lineWidth: lineWidth, sides: 6, cornerRadius: 10)

        let mask = CAShapeLayer()
        mask.path = path.cgPath
        mask.lineWidth = lineWidth
        mask.strokeColor = UIColor.clear.cgColor
        mask.fillColor = Constants().themeColor.cgColor
        self.layer.mask = mask

        let border = CAShapeLayer()
        border.path = path.cgPath
        border.lineWidth = lineWidth
        border.strokeColor = Constants().themeColor.cgColor
        border.fillColor = UIColor.clear.cgColor
        self.layer.addSublayer(border)
    }
    
    func setImageFromBase64String(_ base64String: String) {
        let dataDecoded:NSData = NSData(base64Encoded: base64String, options: NSData.Base64DecodingOptions(rawValue: 0))!
        let decodedimage:UIImage = UIImage(data: dataDecoded as Data)!
        self.image = decodedimage
    }
}

public enum ImageFormat {
    case png
    case jpeg(CGFloat)
}

extension UIImage {
    func isEqualToImage(image: UIImage) -> Bool {
        let data1: NSData = self.pngData()! as NSData
        let data2: NSData = image.pngData()! as NSData
        return data1.isEqual(data2)
    }
    
    public func toBase64(format: ImageFormat) -> String? {
        var imageData: Data?

        switch format {
        case .png:
            imageData = self.pngData()
        case .jpeg(let compression):
            imageData = self.jpegData(compressionQuality: compression)
        }

        return imageData?.base64EncodedString()
    }
    
    static func from(color: UIColor) -> UIImage {
        let rect = CGRect(x: 0, y: 0, width: 1, height: 1)
        UIGraphicsBeginImageContext(rect.size)
        let context = UIGraphicsGetCurrentContext()
        context!.setFillColor(color.cgColor)
        context!.fill(rect)
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return img!
    }
    
    func resizeImage(_ dimension: CGFloat, opaque: Bool, contentMode:
        UIView.ContentMode = .scaleAspectFit) -> UIImage {
        var width: CGFloat
        var height: CGFloat
        var newImage: UIImage

        let size = self.size
        let aspectRatio =  size.width/size.height

        switch contentMode {
        case .scaleAspectFit:
            if aspectRatio > 1 {                            // Landscape image
                width = dimension
                height = dimension / aspectRatio
            } else {                                        // Portrait image
                height = dimension
                width = dimension * aspectRatio
            }

        default:
            fatalError("UIIMage.resizeToFit(): FATAL: Unimplemented ContentMode")
        }

        if #available(iOS 10.0, *) {
            let renderFormat = UIGraphicsImageRendererFormat.default()
            renderFormat.opaque = opaque
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: width, height: height), format: renderFormat)
            newImage = renderer.image {
                (context) in
                self.draw(in: CGRect(x: 0, y: 0, width: width, height: height))
            }
        } else {
            UIGraphicsBeginImageContextWithOptions(CGSize(width: width, height: height), opaque, 0)
            self.draw(in: CGRect(x: 0, y: 0, width: width, height: height))
            newImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
        }

        return newImage
    }
}

extension NiceButton {
    func loadPetImage(petId:Int) {
        let imageUrl: String = "https://zylo-app-data.s3.amazonaws.com/zylo_app_data/\(Utility.getCurrentUserId())/pet_profile_image/\(petId)"
        if let imgUrl = URL(string: imageUrl) {
            self.loadImageWithUrl(imgUrl)
        }
    }
    
    func removePetImageFromCache(petId:Int) {
        let imageUrl: String = "https://zylo-app-data.s3.amazonaws.com/zylo_app_data/\(Utility.getCurrentUserId())/pet_profile_image/\(petId)"
        if let imgUrl = URL(string: imageUrl) {
            self.removeImageFromCache(imgUrl)
        }
    }
    
    func loadUserImage() {
        let imageUrl: String = Utility.getCurrentUserImageUrl()
        if(!imageUrl.isEmpty) {
            if let imgUrl = URL(string: imageUrl) {
                self.loadImageWithUrl(imgUrl)
            }
        }
    }
    
    func removeUserImageFromCache() {
        let imageUrl: String = Utility.getCurrentUserImageUrl()
        if(!imageUrl.isEmpty) {
            if let imgUrl = URL(string: imageUrl) {
                self.removeImageFromCache(imgUrl)
            }
        }
    }
    
    func loadVaccineImage(petId:Int, activityId:Int) {
        let imageUrl: String = "https://zylo-app-data.s3.amazonaws.com/zylo_app_data/\(Utility.getCurrentUserId())/vaccine_certificates/\(petId)/\(activityId)"
        if let imgUrl = URL(string: imageUrl) {
            Constants.url = imageUrl
            self.loadImageWithUrl(imgUrl)
        }
    }
    
    func removeVaccineImageFromCache(petId:Int, activityId:Int) {
        let imageUrl: String = "https://zylo-app-data.s3.amazonaws.com/zylo_app_data/\(Utility.getCurrentUserId())/vaccine_certificates/\(petId)/\(activityId)"
        if let imgUrl = URL(string: imageUrl) {
            self.removeImageFromCache(imgUrl)
        }
    }
}

extension DropDown {
    func setSelectedItem(list:[String], value:String) {
        for (index, _) in list.enumerated() { self.deselectRow(at:index) }
        if let index = list.firstIndex(where: {$0.range(of: value, options: [.caseInsensitive, .anchored]) != nil}) {
            self.reloadAllComponents()
            self.selectRow(index)
            self.selectionAction?(index, list[index])
        }
    }
    
    func selectedItem(list:[String], value:String) {
        for (index, _) in list.enumerated() { self.deselectRow(at:index) }
        if let index = list.firstIndex(where: {$0.range(of: value, options: [.caseInsensitive, .anchored]) != nil}) {
            self.reloadAllComponents()
            self.selectRow(index, scrollPosition: .top)
        }
    }
        
    public var selectedValue: String {
        if(self.selectedItem != nil) {
            return self.selectedItem!
        }
        return ""
    }
}

extension ImageView {
    func loadUserImage() {
        let imageUrl: String = Utility.getCurrentUserImageUrl()
        if(!imageUrl.isEmpty) {
            if let imgUrl = URL(string: imageUrl) {
                self.loadImageWithUrl(imgUrl, defaultImage: UIImage(named: "avatar")!)
            }
        } else {
            self.image = UIImage(named: "avatar")
        }
    }
    
    func removeUserImageFromCache() {
        let imageUrl: String = Utility.getCurrentUserImageUrl()
        if(!imageUrl.isEmpty) {
            if let imgUrl = URL(string: imageUrl) {
                self.removeImageFromCache(imgUrl)
            }
        }
    }
    
    func loadPetImage(petId:Int) {
        let imageUrl: String = "https://zylo-app-data.s3.amazonaws.com/zylo_app_data/\(Utility.getCurrentUserId())/pet_profile_image/\(petId)"
        if let imgUrl = URL(string: imageUrl) {
            self.loadImageWithUrl(imgUrl, defaultImage: UIImage(named: "defaultPet")!)
        } else {
            self.image = UIImage(named: "defaultPet")
        }
    }
    
    func removePetImageFromCache(petId:Int) {
        let imageUrl: String = "https://zylo-app-data.s3.amazonaws.com/zylo_app_data/\(Utility.getCurrentUserId())/pet_profile_image/\(petId)"
        if let imgUrl = URL(string: imageUrl) {
            self.removeImageFromCache(imgUrl)
        }
    }
}

extension ImageLoader {
    func loadUserImage() {
        let imageUrl: String = Utility.getCurrentUserImageUrl()
        if(!imageUrl.isEmpty) {
            if let imgUrl = URL(string: imageUrl) {
                self.loadImageWithUrl(imgUrl, defaultImage: UIImage(named: "avatar")!)
            }
        } else {
            self.image = UIImage(named: "avatar")
        }
    }
    
    func removeUserImageFromCache() {
        let imageUrl: String = Utility.getCurrentUserImageUrl()
        if(!imageUrl.isEmpty) {
            if let imgUrl = URL(string: imageUrl) {
                self.removeImageFromCache(imgUrl)
            }
        }
    }
    
    func loadPetImage(petId:Int) {
        let imageUrl: String = "https://zylo-app-data.s3.amazonaws.com/zylo_app_data/\(Utility.getCurrentUserId())/pet_profile_image/\(petId)"
        if let imgUrl = URL(string: imageUrl) {
            self.loadImageWithUrl(imgUrl, defaultImage: UIImage(named: "defaultPet")!)
        } else {
            self.image = UIImage(named: "defaultPet")
        }
    }
    
    func removePetImageFromCache(petId:Int) {
        let imageUrl: String = "https://zylo-app-data.s3.amazonaws.com/zylo_app_data/\(Utility.getCurrentUserId())/pet_profile_image/\(petId)"
        if let imgUrl = URL(string: imageUrl) {
            self.removeImageFromCache(imgUrl)
        }
    }
}

enum CalendarLanguage {
    case turkmen
    case english
    case spanish
    case deutsch
    case italian
}

func GetWeekByLang(weekDay: Int, language: CalendarLanguage = .spanish) -> String
{
    switch language {
    case .turkmen:
        return weekArr_Tk[weekDay]!
    case .deutsch:
        return weekArr_De[weekDay]!
    case .english:
        return weekArr_En[weekDay]!
    case .italian:
        return weekArr_It[weekDay]!
    case .spanish:
        return weekArr_Sp[weekDay]!
    }
}

//
// Get humanDate
// Turkmen month
//

func GetHumanDate(month: Int, language: CalendarLanguage = .spanish) -> String
{
    switch language {
    case .turkmen:
        return monthArr_Tk[month]!
    case .deutsch:
        return monthArr_De[month]!
    case .english:
        return monthArr_En[month]!
    case .italian:
        return monthArr_It[month]!
    case .spanish:
        return monthArr_Sp[month]!
    }
}

extension Date {
    
    //period -> .WeekOfYear, .Day
    func rangeOfPeriod(period: Calendar.Component) -> (Date, Date) {
        
        var startDate = Date()
        var interval : TimeInterval = 0
        let _ = Calendar.current.dateInterval(of: period, start: &startDate, interval: &interval, for: self)
        let endDate = startDate.addingTimeInterval(interval - 1)
        
        return (startDate, endDate)
    }
    
    func calcStartAndEndOfDay() -> (Date, Date) {
        return rangeOfPeriod(period: .day)
    }
    
    func calcStartAndEndOfWeek() -> (Date, Date) {
        return rangeOfPeriod(period: .weekday)
    }
    
    func calcStartAndEndOfMonth() -> (Date, Date) {
        return rangeOfPeriod(period: .month)
    }
    
    func getSpecificDate(interval: Int) -> Date {
        var timeInterval = DateComponents()
        timeInterval.day = interval
        return Calendar.current.date(byAdding: timeInterval, to: self)!
    }
    
    func getStart() -> Date {
        let (start, _) = calcStartAndEndOfDay()
        return start
    }
    
    func getEnd() -> Date {
        let (_, end) = calcStartAndEndOfDay()
        return end
    }
    
    func isBigger(to: Date) -> Bool {
        return Calendar.current.compare(self, to: to, toGranularity: .day) == .orderedDescending ? true : false
    }
    
    func isSmaller(to: Date) -> Bool {
        return Calendar.current.compare(self, to: to, toGranularity: .day) == .orderedAscending ? true : false
    }
    
    func isEqual(to: Date) -> Bool {
        return Calendar.current.isDate(self, inSameDayAs: to)
    }
    
    func isElement(of: [Date]) -> Bool {
        for element in of {
            if self.isEqual(to: element) {
                return true
            }
        }
        return false
    }
    
    func getElement(of: [Date]) -> Date {
        for element in of {
            if self.isEqual(to: element) {
                return element
            }
        }
        return Date()
    }
    
    func addMonth(n: Int) -> Date {
        let cal = NSCalendar.current
        return cal.date(byAdding: .month, value: n, to: self)!
    }
    
    func addDay(n: Int) -> Date {
        let cal = NSCalendar.current
        return cal.date(byAdding: .day, value: n, to: self)!
    }
    
    func addSec(n: Int) -> Date {
        let cal = NSCalendar.current
        return cal.date(byAdding: .second, value: n, to: self)!
    }
    
    func getDate() -> String {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy-MM-dd"
        return dateformatter.string(from: self)
    }
}

class AnimationView: UIView {
    func animateWithFlipEffect(withCompletionHandler completionHandler:(() -> Void)?) {
        AnimationClass.flipAnimation(self, completion: completionHandler)
    }
    func animateWithBounceEffect(withCompletionHandler completionHandler:(() -> Void)?) {
        let viewAnimation = AnimationClass.BounceEffect()
        viewAnimation(self) { _ in
            completionHandler?()
        }
    }
    func animateWithFadeEffect(withCompletionHandler completionHandler:(() -> Void)?) {
        let viewAnimation = AnimationClass.fadeOutEffect()
        viewAnimation(self) { _ in
            completionHandler?()
        }
    }
}

extension UIColor {
    convenience init(red: Int, green: Int, blue: Int, a: CGFloat = 1.0) {
        self.init(
            red: CGFloat(red) / 255.0,
            green: CGFloat(green) / 255.0,
            blue: CGFloat(blue) / 255.0,
            alpha: a
        )
    }

    convenience init(rgb: Int, a: CGFloat = 1.0) {
        self.init(
            red: (rgb >> 16) & 0xFF,
            green: (rgb >> 8) & 0xFF,
            blue: rgb & 0xFF,
            a: a
        )
    }
    
    convenience init(hex: Int, alpha: CGFloat = 1.0) {
        let red = CGFloat((hex & 0xFF0000) >> 16) / 255.0
        let green = CGFloat((hex & 0xFF00) >> 8) / 255.0
        let blue = CGFloat((hex & 0xFF)) / 255.0
        self.init(red:red, green:green, blue:blue, alpha:alpha)
    }
    
    /// Converts this `UIColor` instance to a 1x1 `UIImage` instance and returns it.
    ///
    /// - Returns: `self` as a 1x1 `UIImage`.
    func as1ptImage() -> UIImage {
        UIGraphicsBeginImageContext(CGSize(width: 1, height: 1))
        setFill()
        UIGraphicsGetCurrentContext()?.fill(CGRect(x: 0, y: 0, width: 1, height: 1))
        let image = UIGraphicsGetImageFromCurrentImageContext() ?? UIImage()
        UIGraphicsEndImageContext()
        return image
    }
    
    public convenience init?(hex: String) {
        let r, g, b, a: CGFloat

        if hex.hasPrefix("#") {
            let start = hex.index(hex.startIndex, offsetBy: 1)
            let hexColor = String(hex[start...])

            if hexColor.count == 8 {
                let scanner = Scanner(string: hexColor)
                var hexNumber: UInt64 = 0

                if scanner.scanHexInt64(&hexNumber) {
                    r = CGFloat((hexNumber & 0xff000000) >> 24) / 255
                    g = CGFloat((hexNumber & 0x00ff0000) >> 16) / 255
                    b = CGFloat((hexNumber & 0x0000ff00) >> 8) / 255
                    a = CGFloat(hexNumber & 0x000000ff) / 255

                    self.init(red: r, green: g, blue: b, alpha: a)
                    return
                }
            }
        }

        return nil
    }
}

/*extension UITabBar {
    static let height: CGFloat = 60.0

    override open func sizeThatFits(_ size: CGSize) -> CGSize {
        guard let window = UIApplication.shared.keyWindow else {
            return super.sizeThatFits(size)
        }
        var sizeThatFits = super.sizeThatFits(size)
        if #available(iOS 11.0, *) {
            sizeThatFits.height = UITabBar.height + window.safeAreaInsets.bottom
        } else {
            sizeThatFits.height = UITabBar.height
        }
        return sizeThatFits
    }
    
    // Workaround for iOS 11's new UITabBar behavior where on iPad, the UITabBar inside
    // the Master view controller shows the UITabBarItem icon next to the text
    override open var traitCollection: UITraitCollection {
        if UIDevice.current.userInterfaceIdiom == .pad {
            return UITraitCollection(horizontalSizeClass: .compact)
        }
        return super.traitCollection
    }
}*/

extension UIView {
    func addDashedBorder() {
        let color = Constants().themeColor

        let shapeLayer:CAShapeLayer = CAShapeLayer()
        let frameSize = self.frame.size
        let shapeRect = CGRect(x: 0, y: 0, width: frameSize.width, height: frameSize.height)

        shapeLayer.bounds = shapeRect
        shapeLayer.position = CGPoint(x: frameSize.width/2, y: frameSize.height/2)
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeColor = color.cgColor
        shapeLayer.lineWidth = 2
        shapeLayer.lineJoin = CAShapeLayerLineJoin.round
        shapeLayer.lineDashPattern = [16,6]
        shapeLayer.path = UIBezierPath(roundedRect: shapeRect, cornerRadius: 20).cgPath

        self.layer.addSublayer(shapeLayer)
        self.layer.cornerRadius = 20
        //self.layer.masksToBounds = false
    }
    
    func dropShadow(radius: CGFloat = 20.0) {
        // corner radius
        layer.cornerRadius = radius
        // border
        //layer.borderWidth = 1.0
        //layer.borderColor = UIColor.lightGray.cgColor
        // shadow
        layer.shadowColor = UIColor.gray.cgColor
        //layer.shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: radius).cgPath
        layer.shadowOffset = CGSize(width: Constants.shadowOffset, height: Constants.shadowOffset)
        layer.shadowOpacity = 0.7
        layer.shadowRadius = 4.0
    }
    
    func topCornorRadius(radius: CGFloat = 20.0) {
        layer.cornerRadius = radius
        if #available(iOS 11.0, *) {
            layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        } else {
            let rectShape = CAShapeLayer()
             rectShape.bounds = frame
             rectShape.position = center
             rectShape.path = UIBezierPath(roundedRect: bounds,    byRoundingCorners: [.topLeft , .topRight], cornerRadii: CGSize(width: radius, height: radius)).cgPath
            layer.backgroundColor = UIColor.clear.cgColor
            layer.mask = rectShape
        }
    }
    
    func topAndBottomRightCornorRadius(radius: CGFloat = 20.0) {
        layer.cornerRadius = radius
        if #available(iOS 11.0, *) {
            layer.maskedCorners = [.layerMaxXMinYCorner, .layerMaxXMaxYCorner]
        } else {
            let rectShape = CAShapeLayer()
             rectShape.bounds = frame
             rectShape.position = center
             rectShape.path = UIBezierPath(roundedRect: bounds,    byRoundingCorners: [.topRight , .bottomRight], cornerRadii: CGSize(width: radius, height: radius)).cgPath
            layer.backgroundColor = UIColor.clear.cgColor
            layer.mask = rectShape
        }
    }
    
    func bottomCornorRadius(radius: CGFloat = 20.0) {
        layer.cornerRadius = radius
        if #available(iOS 11.0, *) {
            layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        } else {
            let rectShape = CAShapeLayer()
             rectShape.bounds = frame
             rectShape.position = center
             rectShape.path = UIBezierPath(roundedRect: bounds,    byRoundingCorners: [.bottomLeft , .bottomRight], cornerRadii: CGSize(width: radius, height: radius)).cgPath
            layer.backgroundColor = UIColor.clear.cgColor
            layer.mask = rectShape
        }
    }
    
    func addTopBorderWithColor(color: UIColor, width: CGFloat) {
        let border = CALayer()
        border.backgroundColor = color.cgColor
        border.frame = CGRect(x:0,y: 0, width:self.frame.size.width, height:width)
        self.layer.addSublayer(border)
    }

    func addRightBorderWithColor(color: UIColor, width: CGFloat) {
        let border = CALayer()
        border.backgroundColor = color.cgColor
        border.frame = CGRect(x: self.frame.size.width - width,y: 0, width:width, height:self.frame.size.height)
        self.layer.addSublayer(border)
    }

    func addBottomBorderWithColor(color: UIColor, width: CGFloat) {
        let border = CALayer()
        border.backgroundColor = color.cgColor
        border.frame = CGRect(x:0, y:self.frame.size.height - width, width:self.frame.size.width, height:width)
        self.layer.addSublayer(border)
    }

    func addLeftBorderWithColor(color: UIColor, width: CGFloat) {
        let border = CALayer()
        border.backgroundColor = color.cgColor
        border.frame = CGRect(x:0, y:0, width:width, height:self.frame.size.height)
        self.layer.addSublayer(border)
    }
    
    var parentViewController: UIViewController? {
        var parentResponder: UIResponder? = self
        while parentResponder != nil {
            parentResponder = parentResponder?.next
            if let viewController = parentResponder as? UIViewController {
                return viewController
            }
        }
        return nil
    }
    
    func viewOfType<T:UIView>(type:T.Type, process: (_ view:T) -> Void)
    {
        if let view = self as? T
        {
            process(view)
        }
        else {
            for subView in subviews
            {
                subView.viewOfType(type:type, process:process)
            }
        }
    }
    
    func asImage() -> UIImage {
        if #available(iOS 10.0, *) {
            let renderer = UIGraphicsImageRenderer(bounds: bounds)
            return renderer.image { rendererContext in
                layer.render(in: rendererContext.cgContext)
            }
        } else {
            UIGraphicsBeginImageContext(self.frame.size)
            self.layer.render(in:UIGraphicsGetCurrentContext()!)
            let image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            return UIImage(cgImage: image!.cgImage!)
        }
    }
    
    final func sizeToFitCustom() {
        var w: CGFloat = 0,
            h: CGFloat = 0
        for view in subviews {
            if view.frame.origin.x + view.frame.width > w { w = view.frame.origin.x + view.frame.width }
            if view.frame.origin.y + view.frame.height > h { h = view.frame.origin.y + view.frame.height }
        }
        frame.size = CGSize(width: w, height: h)
    }
    
    var allSubviews: [UIView] {
        return self.subviews.flatMap { [$0] + $0.allSubviews }
    }
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action:    #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
       view.endEditing(true)
    }
}

extension UIImage {

    func addShadow(blurSize: CGFloat = 6.0) -> UIImage {

        let shadowColor = UIColor(white:0.0, alpha:0.8).cgColor

        let context = CGContext(data: nil,
                                width: Int(self.size.width + blurSize),
                                height: Int(self.size.height + blurSize),
                                bitsPerComponent: self.cgImage!.bitsPerComponent,
                                bytesPerRow: 0,
                                space: CGColorSpaceCreateDeviceRGB(),
                                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!

        context.setShadow(offset: CGSize(width: blurSize/2,height: -blurSize/2),
                          blur: blurSize,
                          color: shadowColor)
        context.draw(self.cgImage!,
                     in: CGRect(x: 0, y: blurSize, width: self.size.width, height: self.size.height),
                     byTiling:false)

        return UIImage(cgImage: context.makeImage()!)
    }
}

/*extension UIView {
    func applyCircleShadow(shadowRadius: CGFloat = 2,
                           shadowOpacity: Float = 0.3,
                           shadowColor: CGColor = UIColor.blackColor().CGColor,
                           shadowOffset: CGSize = CGSize.zero) {
        layer.cornerRadius = frame.size.height / 2
        layer.masksToBounds = false
        layer.shadowColor = shadowColor
        layer.shadowOffset = shadowOffset
        layer.shadowRadius = shadowRadius
        layer.shadowOpacity = shadowOpacity
    }
}
extension UIImageView {
    override func applyCircleShadow(shadowRadius: CGFloat = 2,
                                    shadowOpacity: Float = 0.3,
                                    shadowColor: CGColor = UIColor.blackColor().CGColor,
                                    shadowOffset: CGSize = CGSize.zero) {

        // Use UIImageView.hashvalue as background view tag (should be unique)
        let background: UIView = superview?.viewWithTag(hashValue) ?? UIView()
        background.frame = frame
        background.backgroundColor = backgroundColor
        background.tag = hashValue
        background.applyCircleShadow(shadowRadius, shadowOpacity: shadowOpacity, shadowColor: shadowColor, shadowOffset: shadowOffset)
        layer.cornerRadius = background.layer.cornerRadius
        layer.masksToBounds = true
        superview?.insertSubview(background, belowSubview: self)
    }
} //image?.applyCircleShadow(5, shadowOpacity: 1)*/
