//
//  CalendarPopUp.swift
//  Zylo
//
//  Created by Sathish on 10/05/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit
import JTAppleCalendar
import DropDown

protocol CalendarPopUpDelegate: class {
    func dateChaged(date: Date)
}

class CalendarPopUp: UIView {
    
    @IBOutlet weak var calendarView: JTAppleCalendarView!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var monthDropdownButton: UIButton!
    @IBOutlet weak var yearDropdownButton: UIButton!

    weak var calendarDelegate: CalendarPopUpDelegate?
    
    let calLanguage: CalendarLanguage = .english
    var endDate: Date!
    var startDate: Date = Date().getStart()
    var testCalendar = Calendar(identifier: .gregorian)
    var selectedDate: Date! = Date() {
        didSet {
            setDate()
        }
    }
    
    var selected:Date = Date() {
        didSet {
            calendarView.scrollToDate(selected)
            calendarView.selectDates([selected])
        }
    }

    @IBAction func closePopupButtonPressed(_ sender: AnyObject) {
        if let superView = self.superview as? PopupContainer {
            (superView ).close()
        }
    }
    
    @IBAction func GetDateOk(_ sender: Any) {
        calendarDelegate?.dateChaged(date: selectedDate)
        if let superView = self.superview as? PopupContainer {
            (superView ).close()
        }
    }
    
    let monthDropDown = DropDown()
    let yearDropDown = DropDown()
    
    lazy var dropDowns: [DropDown] = {
        return [
            self.monthDropDown,
            self.yearDropDown
        ]
    }()
    
    @IBAction func showMonthDropDown(_ sender: AnyObject) {
        monthDropDown.show()
    }
    
    @IBAction func showYearDropDown(_ sender: AnyObject) {
        yearDropDown.show()
    }
    
    func setupMonthDropDown() {
        monthDropDown.anchorView = monthDropdownButton
        monthDropDown.bottomOffset = CGPoint(x: 0, y: monthDropdownButton.bounds.height)
        monthDropDown.dataSource = Constants.monthList
        monthDropDown.selectionAction = { [weak self] (index, item) in
            self?.monthDropdownButton.setTitle(item, for: .normal)
            self?.setCalenderSelection()
        }
    }
    
    func setCalenderSelection() {
        let month = self.monthDropDown.selectedValue
        let year = self.yearDropDown.selectedValue
        let mn = Constants.monthList.firstIndex(of: month)
        let str = String(format: "\(year)-%02d-%02d", mn!+1, 1)
        let dt = Utility.getDateFromString(dateString: str)
        self.calendarView.scrollToDate(dt)
    }
    
    func setupYearDropDown() {
        yearDropDown.anchorView = yearDropdownButton
        yearDropDown.bottomOffset = CGPoint(x: 0, y: yearDropdownButton.bounds.height)
        yearDropDown.dataSource = Constants.yearList
        yearDropDown.selectionAction = { [weak self] (index, item) in
            self?.yearDropdownButton.setTitle(item, for: .normal)
            self?.setCalenderSelection()
        }
    }
    
    override func awakeFromNib() {
        setupMonthDropDown()
        setupYearDropDown()
        Utility.setupDropdownAppreance()
        
        dropDowns.forEach { $0.dismissMode = .onTap }
        dropDowns.forEach { $0.direction = .any }
        
        //Calendar
        // You can also use dates created from this function
        startDate = Utility.getDateFromString(dateString: "1900-01-01")
        endDate = Calendar.current.date(byAdding: .year, value: 100, to: Date())!
        setCalendar()
        setDate()
        self.calendarView.visibleDates {[unowned self] (visibleDates: DateSegmentInfo) in
            self.setupViewsOfCalendar(from: visibleDates)
        }
        let cornerRadius = CGFloat(10.0)
        let shadowOpacity = Float(1)
        self.layer.cornerRadius = cornerRadius
        let shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: cornerRadius)
        layer.masksToBounds = false
        layer.shadowColor = UIColor.gray.cgColor
        layer.shadowOffset = CGSize(width: 2, height: 5)
        layer.shadowOpacity = shadowOpacity
        layer.shadowPath = shadowPath.cgPath
        
        self.monthDropdownButton.layer.cornerRadius = cornerRadius
    }

    func setDate() {
        let month = testCalendar.dateComponents([.month], from: selectedDate).month!
        let weekday = testCalendar.component(.weekday, from: selectedDate)
        let monthName = GetHumanDate(month: month, language: calLanguage) // DateFormatter().monthSymbols[(month-1) % 12] //
        let week = GetWeekByLang(weekDay: weekday, language: calLanguage) // DateFormatter().shortWeekdaySymbols[weekday-1]
        let day = testCalendar.component(.day, from: selectedDate)
        dateLabel.text = "\(week), " + monthName + " " + String(day)
    }

    func setupViewsOfCalendar(from visibleDates: DateSegmentInfo) {
        guard let startDate = visibleDates.monthDates.first?.date else {
            return
        }
        let month = testCalendar.dateComponents([.month], from: startDate).month!
        let monthName = GetHumanDate(month: month, language: calLanguage) // DateFormatter().monthSymbols[Int(month.month!)-1]
        let year = testCalendar.component(.year, from: startDate)
        //calendarHeaderLabel.text = monthName + ", " + String(year)
        self.monthDropDown.selectedItem(list: Constants.monthList, value: monthName)
        self.monthDropdownButton.setTitle(monthName, for: .normal)
        self.yearDropDown.selectedItem(list: Constants.yearList, value: String(year))
        self.yearDropdownButton.setTitle(String(year), for: .normal)
    }
    
    func setCalendar() {
        self.calendarView.calendarDataSource = self
        self.calendarView.calendarDelegate = self
        let nibName = UINib(nibName: "CellView", bundle:nil)
        self.calendarView.register(nibName, forCellWithReuseIdentifier: "CellView")
        self.calendarView.minimumLineSpacing = 0
        self.calendarView.minimumInteritemSpacing = 0
    }
}

// MARK : JTAppleCalendarDelegate
extension CalendarPopUp: JTAppleCalendarViewDelegate, JTAppleCalendarViewDataSource {

    func configureCalendar(_ calendar: JTAppleCalendarView) -> ConfigurationParameters {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy MM dd"

        let parameters = ConfigurationParameters(startDate: startDate,
                                                 endDate: endDate,
                                                 numberOfRows: 6,
                                                 calendar: testCalendar,
                                                 generateInDates: .forAllMonths,
                                                 generateOutDates: .tillEndOfGrid,
                                                 firstDayOfWeek: DaysOfWeek.sunday)

        return parameters
    }
    
    func calendar(_ calendar: JTAppleCalendarView, willDisplay cell: JTAppleCell, forItemAt date: Date, cellState: CellState, indexPath: IndexPath) {
        (cell as? CellView)?.handleCellSelection(cellState: cellState, date: date, selectedDate: selectedDate)
    }
    
    
    func calendar(_ calendar: JTAppleCalendarView, cellForItemAt date: Date, cellState: CellState, indexPath: IndexPath) -> JTAppleCell {
        let myCustomCell = calendar.dequeueReusableCell(withReuseIdentifier: "CellView", for: indexPath) as! CellView
        myCustomCell.handleCellSelection(cellState: cellState, date: date, selectedDate: selectedDate)
        return myCustomCell
    }
    
    func calendar(_ calendar: JTAppleCalendarView, didSelectDate date: Date, cell: JTAppleCell?, cellState: CellState) {
        selectedDate = date
        (cell as? CellView)?.cellSelectionChanged(cellState, date: date)
    }

    func calendar(_ calendar: JTAppleCalendarView, didDeselectDate date: Date, cell: JTAppleCell?, cellState: CellState) {
        (cell as? CellView)?.cellSelectionChanged(cellState, date: date)
    }

    func calendar(_ calendar: JTAppleCalendarView, willResetCell cell: JTAppleCell) {
        (cell as? CellView)?.selectedView.isHidden = true
    }

    func calendar(_ calendar: JTAppleCalendarView, didScrollToDateSegmentWith visibleDates: DateSegmentInfo) {
        self.setupViewsOfCalendar(from: visibleDates)
    }
}
