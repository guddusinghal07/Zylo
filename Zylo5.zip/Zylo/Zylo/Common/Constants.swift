//
//  Constants.swift
//  Zylo
//
//  Created by Sathish on 10/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class Constants {
    
    static let imageCache = NSCache<AnyObject, AnyObject>()
    
    public let BaseUrl: String = "https://1j3a887io8.execute-api.us-east-1.amazonaws.com/dev/"
    public let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
    
    let dateFormatter: String = "yyyy-MM-dd HH:mm:ss zzz"
    let headerColor: UIColor = UIColor(red: 248.0/255.0, green: 248.0/255.0, blue: 248.0/255.0, alpha: 1.0)
    static let backgroundColor: UIColor = UIColor.init(red: 249.0/255.0, green: 249.0/255.0, blue: 249.0/255.0, alpha: 1.0)
    let themeColor: UIColor = UIColor(red: 90.0/255.0, green: 74.0/255.0, blue: 152/255.0, alpha: 1.0)
    let headerButtonColor: UIColor = UIColor(red: 51.0/255.0, green: 51.0/255.0, blue: 51.0/255.0, alpha: 1.0)
    let labelSelectionColor: UIColor = UIColor(red: 28/255.0, green: 128/255.0, blue: 236/255.0, alpha: 1.0)
    
    let petCount: Int = 4
    
    let LoggedInUserToken: String = "ZyloLoggedInUserToken"
    let LoggedInUserFullName: String = "ZyloLoggedInUserFullName"
    let LoggedInUserGivenName: String = "ZyloLoggedInUserGivenName"
    let LoggedInUserFamilyName: String = "ZyloLoggedInUserFamilyName"
    let LoggedInUserEmail: String = "ZyloLoggedInUserEmail"
    let LoggedInUserImageUrl: String = "ZyloLoggedInUserImageUrl"
    let defaultPetId: String = "ZyloDefaultPetId"
    let defaultPetName: String = "ZyloDefaultPetName"
    let LoggedInUserId: String = "ZyloLoggedInUserId"
    let showPetProfileOnLoad: String = "ZyloShowPetProfileOnLoad"
    
    let vetFacility = "vet facility"
    let petDogBreed = "pet dog breed"
    let petCatBreed = "pet cat breed"
    
    let frequency = "frequnecy"
    
    let petParentCountry = "pet parent country"
    let vetCountry = "vet country"
    static let userCountry = "user country"
    
    let dogBreedsList = ["Afador", "Affenpinscher", "Afghan Hound", "Airedale Terrier", "Akbash", "Akita", "Alaskan Klee Kai", "Alaskan Malamute", "American Bulldog", "American English Coonhound", "American Eskimo Dog", "American Foxhound", "American Leopard Hound", "American Pit Bull Terrier", "American Pugabull", "American Staffordshire Terrier", "American Water Spaniel", "Anatolian Shepherd Dog", "Appenzeller Sennenhunde", "Auggie", "Aussiedoodle", "Aussiepom", "Australian Cattle Dog", "Australian Kelpie", "Australian Retriever", "Australian Shepherd", "Australian Shepherd Husky", "Australian Shepherd Lab Mix", "Australian Shepherd Pit Bull Mix", "Australian Terrier", "Azawakh", "Barbet", "Basenji", "Bassador", "Basset Fauve de Bretagne", "Basset Hound", "Basset Retriever", "Bavarian Mountain Scent Hound", "Beabull", "Beagle", "Beaglier", "Bearded Collie", "Bedlington Terrier", "Belgian Malinois", "Belgian Sheepdog", "Belgian Tervuren", "Berger Picard", "Bernedoodle", "Bernese Mountain Dog", "Bichon Frise", "Biewer Terrier", "Black and Tan Coonhound", "Black Mouth Cur", "Black Russian Terrier", "Bloodhound", "Blue Lacy", "Bluetick Coonhound", "Bocker", "Boerboel", "Boglen Terrier", "Bolognese", "Borador", "Border Collie", "Border Sheepdog", "Border Terrier", "Bordoodle", "Borzoi", "BoShih", "Bossie", "Boston Boxer", "Boston Terrier", "Bouvier des Flandres", "Boxador", "Boxer", "Boxerdoodle", "Boxmatian", "Boxweiler", "Boykin Spaniel", "Bracco Italiano", "Braque du Bourbonnais", "Briard", "Brittany", "Broholmer", "Brussels Griffon", "Bugg", "Bull Terrier", "Bullador", "Bullboxer Pit", "Bulldog", "Bullmastiff", "Bullmatian", "Cairn Terrier", "Canaan Dog", "Cane Corso", "Cardigan Welsh Corgi", "Catahoula Bulldog", "Catahoula Leopard Dog", "Caucasian Shepherd Dog", "Cav-a-Jack", "Cavachon", "Cavador", "Cavalier King Charles Spaniel", "Cavapoo", "Cesky Terrier", "Chabrador", "Cheagle", "Chesapeake Bay Retriever", "Chi Chi", "Chi-Poo", "Chigi", "Chihuahua", "Chilier", "Chinese Crested", "Chinese Shar-Pei", "Chinook", "Chion", "Chipin", "Chiweenie", "Chorkie", "Chow Chow", "Chow Shepherd", "Chug", "Chusky", "Cirneco dell’Etna", "Clumber Spaniel", "Cockalier", "Cockapoo", "Cocker Spaniel", "Collie", "Corgi Inu", "Corgidor", "Corman Shepherd", "Coton de Tulear", "Curly-Coated Retriever", "Dachsador", "Dachshund", "Dalmatian", "Dandie Dinmont Terrier", "Daniff", "Deutscher Wachtelhund", "Doberdor", "Doberman Pinscher", "Docker", "Dogo Argentino", "Dogue de Bordeaux", "Dorgi", "Dorkie", "Doxiepoo", "Doxle", "Drentsche Patrijshond", "Drever", "Dutch Shepherd", "English Cocker Spaniel", "English Foxhound", "English Setter", "English Springer Spaniel", "English Toy Spaniel", "Entlebucher Mountain Dog", "Estrela Mountain Dog", "Eurasier", "Field Spaniel", "Finnish Lapphund", "Finnish Spitz", "Flat-Coated Retriever", "Fox Terrier", "French Bulldog", "French Spaniel", "Frenchton", "Frengle", "German Pinscher", "German Shepherd Dog", "German Sheprador", "German Shorthaired Pointer", "German Spitz", "German Wirehaired Pointer", "Giant Schnauzer", "Glen of Imaal Terrier", "Goberian", "Goldador", "Golden Cocker Retriever", "Golden Mountain Dog", "Golden Retriever", "Golden Retriever Corgi", "Golden Shepherd", "Goldendoodle", "Gollie", "Gordon Setter", "Great Dane", "Great Pyrenees", "Greater Swiss Mountain Dog", "Greyhound", "Hamiltonstovare", "Hanoverian Scenthound", "Harrier", "Havanese", "Hokkaido", "Horgi", "Huskita", "Huskydoodle", "Ibizan Hound", "Icelandic Sheepdog", "Irish Red and White Setter", "Irish Setter", "Irish Terrier", "Irish Water Spaniel", "Irish Wolfhound", "Italian Greyhound", "Jack-A-Poo", "Jack Chi", "Jack Russell Terrier", "Japanese Chin", "Japanese Spitz", "Korean Jindo Dog", "Karelian Bear Dog", "Keeshond", "Kerry Blue Terrier", "Komondor", "Kooikerhondje", "Kuvasz", "Kyi-Leo", "Lab Pointer", "Labernese", "Labmaraner", "Labrabull", "Labradane", "Labradoodle", "Labrador Retriever", "Labrastaff", "Labsky", "Lagotto Romagnolo", "Lakeland Terrier", "Lancashire Heeler", "Leonberger", "Lhasa Apso", "Lhasapoo", "Lowchen", "Maltese", "Maltese Shih Tzu", "Maltipoo", "Manchester Terrier", "Mastador", "Mastiff", "Miniature Pinscher", "Miniature Schnauzer", "Morkie", "Mudi", "Mutt", "Neapolitan Mastiff", "Newfoundland", "Norfolk Terrier", "Norwegian Buhund", "Norwegian Elkhound", "Norwegian Lundehund", "Norwich Terrier", "Nova Scotia Duck Tolling Retriever", "Old English Sheepdog", "Otterhound", "Papillon", "Papipoo", "Peekapoo", "Pekingese", "Pembroke Welsh Corgi", "Petit Basset Griffon Vendeen", "Pharaoh Hound", "Pitsky", "Plott", "Pocket Beagle", "Pointer", "Polish Lowland Sheepdog", "Pomapoo", "Pomchi", "Pomeagle", "Pomeranian", "Pomsky", "Poochon", "Poodle", "Portuguese Podengo Pequeno", "Portuguese Water Dog", "Pug", "Pugalier", "Puggle", "Puli", "Pyrenean Shepherd", "Rat Terrier", "Redbone Coonhound", "Rhodesian Ridgeback", "Rottador", "Rottle", "Rottweiler", "Saint Berdoodle", "Saint Bernard", "Saluki", "Samoyed", "Samusky", "Schipperke", "Schnoodle", "Scottish Deerhound", "Scottish Terrier", "Sealyham Terrier", "Sheepadoodle", "Shepsky", "Shetland Sheepdog", "Shiba Inu", "Shichon", "Shih-Poo", "Shih Tzu", "Shiranian", "Shollie", "Shorkie", "Siberian Husky", "Silken Windhound", "Silky Terrier", "Skye Terrier", "Sloughi", "Small Munsterlander Pointer", "Soft Coated Wheaten Terrier", "Spanish Mastiff", "Springador", "Stabyhoun", "Staffordshire Bull Terrier", "Standard Schnauzer", "Sussex Spaniel", "Swedish Vallhund", "Terripoo", "Tibetan Mastiff", "Tibetan Spaniel", "Tibetan Terrier", "Toy Fox Terrier", "Treeing Tennessee Brindle", "Treeing Walker Coonhound", "Valley Bulldog", "Vizsla", "Weimaraner", "Welsh Springer Spaniel", "Welsh Terrier", "West Highland White Terrier", "Westiepoo", "Whippet", "Whoodle", "Wirehaired Pointing Griffon", "Xoloitzcuintli", "Yorkipoo", "Yorkshire Terrier"]
    let catBreedsList = ["Abyssinian", "Aegean", "American Bobtail", "American Curl", "American Shorthair", "American Wirehair", "Aphrodite Giant", "Arabian Mau", "Asian cat", "Asian Semi-longhair", "Australian Mist", "Balinese", "Bambino", "Bengal", "Birman", "Bombay", "Brazilian Shorthair", "British Longhair", "British Shorthair", "Burmese", "Burmilla", "California Spangled", "Chantilly-Tiffany", "Chartreux", "Chausie", "Colourpoint Shorthair", "Cornish Rex", "Cymric", "Cyprus", "Devon Rex", "Donskoy", "Dragon Li", "Dwelf", "Egyptian Mau", "European Shorthair", "Exotic Shorthair", "Foldex", "German Rex", "Havana Brown", "Highlander", "Himalayan", "Japanese Bobtail", "Javanese", "Khao Manee", "Korat", "Korean Bobtail", "Kurilian Bobtail", "LaPerm", "Lykoi", "Maine Coon", "Manx", "Mekong Bobtail", "Minskin", "Napoleon", "Munchkin", "Nebelung", "Norwegian Forest Cat", "Ocicat", "Ojos Azules", "Oregon Rex", "Oriental Bicolor", "Oriental Longhair", "Oriental Shorthair", "Persian (modern)", "Persian (traditional)", "Peterbald", "Pixie-bob", "Ragamuffin", "Ragdoll", "Raas", "Russian Blue", "Russian White, Black, and Tabby", "Sam sawet", "Savannah", "Scottish Fold", "Selkirk Rex", "Serengeti", "Serrade Petit", "Siamese", "Thai", "Siberian", "Singapura", "Snowshoe", "Sokoke", "Somali", "Sphynx", "Suphalak", "Thai", "Thai Lilac", "Tonkinese", "Toyger", "Turkish Angora", "Turkish Van", "Ukrainian Levkoy", "York Chocolate"]
    let petTypeList = ["Dog", "Cat"]
    let petColorList = ["Brown", "Red", "Black", "White", "Gold", "Yellow", "Cream", "Grey"]
    let petFoodTypeList = ["Dry", "Canned", "Semi-Moist", "Home Cooked", "Raw"]
    let frequencyList = ["Daily", "Weekly", "Monthly", "Quarterly", "Half Yearly", "Yearly"]
    //let languageList = Locale.isoLanguageCodes.compactMap { Locale.current.localizedString(forLanguageCode: $0) }
    let countryList = Locale.isoRegionCodes.compactMap { Locale.current.localizedString(forRegionCode: $0) }
    let networkConnectionErrorCode: Int = 12007
    
    let reloadUser: String = "reloadUser"
    let reloadMedicineDetails: String = "reloadMedicineDetails"
    let reloadReminderDetails: String = "reloadReminderDetails"
    let reloadActivityDetails: String = "reloadActivityDetails"
    static let reloadMedicineAdministration: String = "reloadMedicineAdministration"

    static let reloadDescription: String = "reloadDescription"
    
    static var url : String = ""

    
    static let monthList = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    static let year = Calendar.current.component(.year, from: Date())
    static let yearList = (1900...year).map(String.init)
    
    static let shadowOffset: CGFloat = 5.0
}

// calendar language constants
let weekArr_Tk: [Int: String] =
    [ 01 : "Duşenbe",
      02 : "Sişenbe",
      03 : "Çarşenbe",
      04 : "Penşenbe",
      05 : "Anna",
      06 : "Şenbe",
      07 : "Ýekşenbe",
]
let monthArr_Tk: [Int: String] =
    [ 01 : "Ýanwar",
      02 : "Fewral",
      03 : "Mart",
      04 : "Aprel",
      05 : "Maý",
      06 : "Iýun",
      07 : "Iýul",
      08 : "Awgust",
      09 : "Sentýabr",
      10 : "Oktýabr",
      11 : "Noýabr",
      12 : "Dekabr"]

let weekArr_Sp: [Int: String] =
    [ 01 : "Lunes",
      02 : "Martes",
      03 : "Miércoles",
      04 : "Jueves",
      05 : "Viernes",
      06 : "Sábado",
      07 : "Domingo",
]
let monthArr_Sp: [Int: String] =
    [ 01 : "Enero",
      02 : "Febrero",
      03 : "Marzo",
      04 : "Abril",
      05 : "Mayo",
      06 : "Junio",
      07 : "Julio",
      08 : "Agosto",
      09 : "Septiembre",
      10 : "Octubre",
      11 : "Noviembre",
      12 : "Diciembre"]


let weekArr_En: [Int: String] =
    [ 01 : "Sunday",
      02 : "Monday",
      03 : "Tuesday",
      04 : "Wednesday",
      05 : "Thursday",
      06 : "Friday",
      07 : "Saturday",
]
let monthArr_En: [Int: String] =
    [ 01 : "January",
      02 : "February",
      03 : "March",
      04 : "April",
      05 : "May",
      06 : "June",
      07 : "July",
      08 : "August",
      09 : "September",
      10 : "October",
      11 : "November",
      12 : "December"]


let weekArr_De: [Int: String] =
    [ 01 : "Montag",
      02 : "Dienstag",
      03 : "Mittwoch",
      04 : "Donnerstag",
      05 : "Freitag",
      06 : "Samstag",
      07 : "Sonntag",
]
let monthArr_De: [Int: String] =
    [ 01 : "Januar",
      02 : "Februar",
      03 : "Marz",
      04 : "April",
      05 : "Mai",
      06 : "Juni",
      07 : "Juli",
      08 : "August",
      09 : "September",
      10 : "Oktober",
      11 : "November",
      12 : "Dezember"]


let weekArr_It: [Int: String] =
    [ 01 : "lunedì",
      02 : "martedì",
      03 : "mercoledì",
      04 : "giovedì",
      05 : "venerdì",
      06 : "sabato",
      07 : "domenica",
]
let monthArr_It: [Int: String] =
    [ 01 : "Gennaio",
      02 : "Febbraio",
      03 : "Marzo",
      04 : "Aprile",
      05 : "Maggio",
      06 : "Giugno",
      07 : "Luglio",
      08 : "Agosto",
      09 : "Settembre",
      10 : "Ottobre",
      11 : "Novembre",
      12 : "Dicembre"]
