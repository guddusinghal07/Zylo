//
//  VaccineAdministrativeTableViewCell.swift
//  Zylo
//
//  Created by Sathish on 15/04/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class VaccineAdministrativeTableViewCell: UITableViewCell {
    @IBOutlet weak var vaccineAdministrativeLabel: UILabel!
    @IBOutlet weak var visitDateTextFiled: DateTextField!
    @IBOutlet weak var facilityTextField: TextField!
    @IBOutlet weak var vetHospital: TextField!
    @IBOutlet weak var doctorNameTextField: TextField!
    @IBOutlet weak var doctorLicenseNumberTextField: TextField!
    
    var activityId: Int = 0
}

class VaccineAdministrativeDetailTableViewCell: UITableViewCell {
    @IBOutlet weak var vaccineLabel: UILabel!
    @IBOutlet weak var associationSwitch: UISwitch!
    @IBOutlet weak var dateGivenTextField: DateTextField!
    @IBOutlet weak var dateDueTextField: DateTextField!
    @IBOutlet weak var titleView: UIView!
    @IBOutlet weak var rabiesInfoButton: UIButton!
    @IBOutlet weak var rabiesView: UIView!
    @IBOutlet weak var rabiesHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var tagNumberTextField: UITextField!
    @IBOutlet weak var serialNumberTextField: UITextField!
    @IBOutlet weak var vaccineTypeTextField: UITextField!
    @IBOutlet weak var vaccineNameTextField: UITextField!
    @IBOutlet weak var vaccineProducerTextField: UITextField!
    
    var isExpanded: Bool = false
    var rabiesViewHeight: CGFloat!
    var associationId: Int = 0
    
    var callback : ((Bool)->())?
    @IBAction func switchChanged(_ sender : UISwitch) {
        callback?(sender.isOn)
    }
    
    var tagNumberChangeCallback : ((String)->())?
    @IBAction func tagNumberChanged(_ sender : UITextField) {
        tagNumberChangeCallback?(sender.text ?? "")
    }
    
    var serialNumberChangeCallback : ((Int)->())?
    @IBAction func serialNumberChanged(_ sender : UITextField) {
        serialNumberChangeCallback?(sender.text?.integerValue ?? 0)
    }
    
    var vaccineTypeChangeCallback : ((String)->())?
    @IBAction func vaccineTypeChanged(_ sender : UITextField) {
        vaccineTypeChangeCallback?(sender.text ?? "")
    }
    
    var vaccineNameChangeCallback : ((String)->())?
    @IBAction func vaccineNameChanged(_ sender : UITextField) {
        vaccineNameChangeCallback?(sender.text ?? "")
    }
    
    var vaccineProducerChangeCallback : ((String)->())?
    @IBAction func vaccineProducerChanged(_ sender : UITextField) {
        vaccineProducerChangeCallback?(sender.text ?? "")
    }
    
    var rabiesCallback : ((Bool)->())?
    @IBAction func rabiesAction(_ sender : UIButton) {
        if(self.isExpanded) {
            self.isExpanded = false
            self.collapse()
        } else {
            self.isExpanded = true
            self.expand()
        }
        rabiesCallback?(true)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.titleView?.dropShadow()
        rabiesViewHeight = rabiesHeightConstraint.constant
        self.rabiesView?.isHidden = true
        rabiesHeightConstraint.constant = 0.0
        isExpanded = false
        
        self.tagNumberTextField?.setBottomBorder(borderColor: .lightGray)
        self.serialNumberTextField?.setBottomBorder(borderColor: .lightGray)
        self.vaccineTypeTextField?.setBottomBorder(borderColor: .lightGray)
        self.vaccineNameTextField?.setBottomBorder(borderColor: .lightGray)
        self.vaccineProducerTextField?.setBottomBorder(borderColor: .lightGray)
    }
    
    func expand() {
        UIView.animate(withDuration: 0.2, delay: 0.0, options: .curveLinear, animations: {
            self.rabiesView?.isHidden = false
            self.rabiesHeightConstraint.constant = self.rabiesViewHeight
            self.layoutIfNeeded()
        }, completion: { finished in
            
        })
    }

    func collapse() {
        UIView.animate(withDuration: 0.2, delay: 0.0, options: .curveLinear, animations: {
            self.rabiesView?.isHidden = true
            self.rabiesHeightConstraint.constant = 0.0
            self.layoutIfNeeded()
        }, completion: { finished in
            
        })
    }
}

class VaccineAdministrativeListTableViewCell: UITableViewCell {
    var activityId: Int = 0
    @IBOutlet weak var vetFacilityLabel: UILabel!
    @IBOutlet weak var vetFacilityAddressLabel: UILabel!
    @IBOutlet weak var visitDateLabel: UILabel!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var sectionView: UIView!
    @IBOutlet weak var actionView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        sectionView?.dropShadow()
        actionView?.topAndBottomRightCornorRadius()
    }
}

class UpcomingVaccineListTableViewCell: UITableViewCell {
    var activityId: Int = 0
    @IBOutlet weak var vaccineNameLabel: UILabel!
    @IBOutlet weak var lastAdministrationLabel: UILabel!
    @IBOutlet weak var nextAdministrationLabel: UILabel!
    @IBOutlet weak var sectionView: UIView!
    @IBOutlet weak var statusView : UIView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        sectionView?.dropShadow()
        statusView.topAndBottomRightCornorRadius(radius: 15)
    }
}

