//
//  PopupTableViewCell.swift
//  Zylo
//
//  Created by Sathish on 17/05/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class PopupTableViewCell: UITableViewCell {

    @IBOutlet weak var sectionView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var detailLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        sectionView?.dropShadow()
    }
    
}
