//
//  PetCollectionViewCell.swift
//  Zylo
//
//  Created by Sathish on 21/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class PetCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var petImage: ImageLoader!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var breadLabel: UILabel!
    @IBOutlet weak var breadImage: UIImageView!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var shadowImage: UIImageView!
    @IBOutlet weak var sectionView: UIView!
    @IBOutlet weak var defaultView: UIView!
    
    var petProfileId: Int = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        petImage?.dropShadow(radius: 15.0)
        if(shadowImage != nil) {
            shadowImage?.bottomCornorRadius(radius: 15.0)
        }
        if(sectionView != nil) {
            sectionView?.dropShadow(radius: 15.0)
        }
        if(defaultView != nil) {
            defaultView?.dropShadow(radius: 15.0)
        }
        if(deleteButton != nil) {
            deleteButton.dropShadow()
        }
    }
}
