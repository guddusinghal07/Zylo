//
//  VaccineAssociationTableViewCell.swift
//  Zylo
//
//  Created by Sathish on 15/04/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class VaccineAssociationTableViewCell: UITableViewCell {

    @IBOutlet weak var petImageView: ImageView!
    @IBOutlet weak var titleLabel: UILabel!
    
    var associationId: Int = 0
}

class VaccineAssociationDetailTableViewCell: UITableViewCell {

    @IBOutlet weak var vaccineLabel: UILabel!
    @IBOutlet weak var associationSwitch: UISwitch!
    @IBOutlet weak var sectionView: UIView!
    
    var associationId: Int = 0
    
    var callback : ((Bool)->())?
    @IBAction func switchChanged(_ sender : UISwitch) {
        callback?(sender.isOn)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        sectionView?.dropShadow()
    }
}
