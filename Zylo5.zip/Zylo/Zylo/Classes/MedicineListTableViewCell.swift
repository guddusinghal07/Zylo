//
//  MedicineListTableViewCell.swift
//  Zylo
//
//  Created by Sathish on 14/04/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class MedicineListTableViewCell: UITableViewCell {

    @IBOutlet weak var medNameLabel: UILabel!
    @IBOutlet weak var brandLabel: UILabel!
    @IBOutlet weak var sectionView: UIView!
    @IBOutlet weak var frequencyLabel: UILabel!
    @IBOutlet weak var lastAdministrationLabel: UILabel!
    @IBOutlet weak var nextAdministrationLabel: UILabel!
    @IBOutlet weak var actionView: UIView!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var addAdministrationLogButton: UIButton!
    @IBOutlet weak var showAdministrationLogButton: UIButton!
    
    var medicineId: Int = 0
    var activityId: Int = 0
    var activityDate: String = ""
    
    override func awakeFromNib() {
        super.awakeFromNib()
        sectionView?.dropShadow()
        actionView?.topAndBottomRightCornorRadius()
    }
}
