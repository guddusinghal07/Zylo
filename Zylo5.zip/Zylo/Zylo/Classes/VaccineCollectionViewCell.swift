//
//  VaccineCollectionViewCell.swift
//  Zylo
//
//  Created by Sathish on 15/04/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class VaccineCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var vaccineImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
}
