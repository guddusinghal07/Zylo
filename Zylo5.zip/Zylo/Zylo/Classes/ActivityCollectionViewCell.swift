//
//  ActivityCollectionViewCell.swift
//  Zylo
//
//  Created by Sathish on 13/05/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class ActivityCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var activityImage: UIImageView!
    @IBOutlet weak var activityLabel: UILabel!
}
