//
//  ReminderListTableViewCell.swift
//  Zylo
//
//  Created by Sathish on 09/06/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class ReminderListTableViewCell: UITableViewCell {

    @IBOutlet weak var sectionView: UIView!
    @IBOutlet weak var profileNameLabel: UILabel!
    @IBOutlet weak var reminderFromDateLabel: UILabel!
    @IBOutlet weak var reminderToDateLabel: UILabel!
    @IBOutlet weak var frequencyLabel: UILabel!
    @IBOutlet weak var actionView: UIView!
    @IBOutlet weak var deleteButton: UIButton!
    
    var reminderId: Int = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        sectionView?.dropShadow()
        actionView?.topAndBottomRightCornorRadius()
    }

}
