//
//  MedicineCollectionViewCell.swift
//  Zylo
//
//  Created by Sathish on 10/04/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class MedicineCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var medicineImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
}
