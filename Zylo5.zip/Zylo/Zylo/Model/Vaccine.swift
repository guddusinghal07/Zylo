//
//  Vaccine.swift
//  Zylo
//
//  Created by Sathish on 15/04/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class Vaccine: Codable {
    let vaccineId: Int?
    let vaccineName: String?
    let vaccineAdminFreq: Int?
    let isDeleted: Bool?
    let isRabies: Bool?
    let isActive: Bool?
}

struct VaccineList: Codable {
    var status: Int?
    var success: Bool?
    var message: String?
    var data: [Vaccine]?
}

class VaccineAdditional {
    var vaccineId: Int?
    var vaccineName: String?
    var vaccineAdminFreq: Int?
    var isDeleted: Bool?
    var isRabies: Bool?
    var isSelected: Bool? = false
}

class PetVaccine: Codable {
    var vaccineId: Int?
    var vaccineName: String?
    var vaccineAdminFreq: Int?
    var isDeleted: Bool?
    var isActive: Bool?
    var isRabies: Bool?
    var isSelected: Bool? = true
    var givenDate: Date? = Date()
    var dueDate: Date? = Date()
    var rabiesTagNumber: String? = ""
    var rabiesSerialNumber: Int? = 0
    var rabiesVaccineType: String? = ""
    var rabiesVaccineName: String? = ""
    var rabiesVaccineProducer: String? = ""
    var isGiven: Bool?
}

struct PetVaccineList: Codable {
    var status: Int?
    var success: Bool?
    var message: String?
    var data: PetVaccineData?
}

struct PetVaccineData: Codable {
    var vaccineAssociation: [PetVaccine]?
    var vetDetails: vetData?
}

struct associationResponse: Codable {
    var status: Int?
    var success: Bool?
    var message: String?
}

struct activityResponse: Codable {
    var status: Int?
    var success: Bool?
    var message: String?
    var activityId: Int?
}

struct activityInformation: Codable {
    var activityId: Int?
    var userId: Int?
    var profileId: Int?
    var activityDate: String?
    var vaccineId: Int?
    var dateVaccineGiven: String?
    var dateVaccineDue: String?
    var isRabiesGiven: Bool?
    var rabiesVaccineId: Int?
    var vetFacilityName: String?
    var vetDoctorName: String?
    var vetDoctorLicenceNumber: String?
    var vetFacilityAddress: String?
    var isDeleted: Bool?
    var vaccineName: String?
    var vaccineAdminFreq: Int?
    var isRabies: Bool?
}

struct vaccineLogs: Codable {
    var vaccineId: Int?
    var vaccineName: String?
    var dateVaccineGiven: String?
    var dateVaccineDue: String?
    var vaccineAdminFreq: Int?
    var isRabies: Bool?
    var isActive: Bool?
    var isGiven: Bool?
}

struct rabiesData: Codable {
    var rabiesVaccineId: Int?
    var userId: Int?
    var profileId: Int?
    var activityDate: String?
    var dateGiven: String?
    var tagNumber: String?
    var serialNumber: Int?
    var vaccineType: String?
    var vaccineName: String?
    var vaccineProducer: String?
    var isDeleted: Bool?
}

struct vaccineActivityList: Codable {
    var status: Int?
    var success: Bool?
    var message: String?
    var data: [activityInformation]?
}

struct vaccineActivityResponse: Codable {
    var success: Bool?
    var status: Int?
    var message: String?
    var data: Int?
}

struct vaccine_certificate_data: Codable {
    var vaccinecertificatemetadata : vaccine_certificate_metadata?
    var certificate : String?
}

struct vaccine_certificate_metadata: Codable {
    var pet_name: String?
    var user_name : String?
    var activity_date :  Date? = Date()
    var activity_description : String?
    var given_vaccine : String?
}

struct vaccineActivityData: Codable {
    var activityInformation: activityInformation?
    var vaccineLogs: [vaccineLogs]?
    var rabiesData: rabiesData?
    var vaccineCertificateData : vaccine_certificate_data?
}

struct vaccineActivity: Codable {
    var success: Bool?
    var status: Int?
    var message: String?
    var data: vaccineActivityData?
}

struct upcomingVaccine: Codable {
    var activityId: Int?
    var userId: Int?
    var profileId: Int?
    var activityDate: String?
    //var vaccineId: Int?
    var dateVaccineGiven: String?
    var dateVaccineDue: String?
    var isRabiesGiven: Bool?
    //var rabiesVaccineId: Int?
    var vetFacilityName: String?
    var vetDoctorName: String?
    var vetDoctorLicenceNumber: String?
    var vetFacilityAddress: String?
    var isDeleted: Bool?
    var vaccineName: String?
    var profilePetName: String?
}

struct upcomingData: Codable {
    var profileId: Int?
    var vaccineData: [upcomingVaccine]?
}

struct upcomingVaccineList: Codable {
    var status: Int?
    var success: Bool?
    var message: String?
    var data: [upcomingData]?
}

struct upcomingDataStats: Codable {
        var activityId: Int?
       var userId: Int?
       var profileId: Int?
       var activityDate: String?
       var vaccineId: Int?
       var dateVaccineGiven: String?
       var dateVaccineDue: String?
//       var isRabiesGiven: Bool?
//       var rabiesVaccineId: Int?
//       var vetFacilityName: String?
//       var vetDoctorName: String?
//       var vetDoctorLicenceNumber: String?
//       var vetFacilityAddress: String?
       var isDeleted: Bool?
       var vaccineName: String?
//       var profilePetName: String?
//       var vaccineFreqency : Int?
       var color : String?
//    var recordCreationDate : String?
//    var recordUpdateDate : String?
}

struct upcomingVaccineStats: Codable {
    var status: Int?
    var success: Bool?
    var message: String?
    var data: [upcomingDataStats]?
}

struct vaccineStat: Codable {
    var activityId: Int?
    var userId: Int?
    var profileId: Int?
    var activityDate: String?
    var vaccineId: Int?
    var dateVaccineGiven: String?
    var dateVaccineDue: String?
    var isRabiesGiven: Bool?
    var rabiesVaccineId: Int?
    var vetFacilityName: String?
    var vetDoctorName: String?
    var vetDoctorLicenceNumber: String?
    var vetFacilityAddress: String?
    var isDeleted: Bool?
    var vaccineName: String?
    var profilePetName: String?
    var vaccineFreqency : Int?
    var color : String?
}
