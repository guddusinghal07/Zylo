//
//  Reminder.swift
//  Zylo
//
//  Created by Sathish on 09/06/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

class Reminder: Codable {
    var reminderId: Int?
    var userId: Int?
    var profileId: Int?
    var reminderStartDate: String?
    var reminderEndDate: String?
    var reminderFrequency: Int?
    var advanceReminderDay: Int?
    var advanceReminderFrequency: Int?
    var advanceReminderNextDate: String?
    var previousReminderDate: String?
    var nextReminderDate: String?
    var isCompleted: Bool?
    var reminderPushNotification: Bool?
    var reminderInAppNotification: Bool?
    var reminderAlexa: Bool?
    var reminderEmail: Bool?
    var reminderEmailAddress: String?
    var isDeleted: Bool?
    var medicineId: Int?
    var vaccineId: Int?
    var dcId: Int?
    var dismissManually: Bool?
    var dismissAtAdmin: Bool?
    var dismissAfterNCount: Bool?
    var dismissCount: Int?
    var dismissRemainingCount: Int?
    var medName: String?
    var vaccineName: String?
    var dcName: String?
    var profilePetName: String?
}

struct ReminderList: Codable {
    var status: Int?
    var success: Bool?
    var message: String?
    var data: [Reminder]?
}

struct ReminderResponse: Codable {
    var success: Bool?
    var status: Int?
    var message: String?
    var reminderId: Int?
}

struct ReminderItem {
    var itemId: Int?
    var itemText: String?
}
