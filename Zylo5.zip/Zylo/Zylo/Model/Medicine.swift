//
//  Medicine.swift
//  Zylo
//
//  Created by Sathish on 23/05/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

struct Medicine: Codable {
    var medicineId: Int?
    var profileId: Int?
    var userId: Int?
    var medName: String?
    var medCategory: String?
    var medAdminType: String?
    var medBrand: String?
    var medAdminFrequency: Int?
    var lastAdministrationDate: String?
    var medActiveStatus: Bool?
    var reminder: Bool?
    var isDeleted: Bool?
    var nextAdminDate: String?
}

struct MedicineList: Codable {
    var status: Int?
    var success: Bool?
    var message: String?
    var data: [Medicine]?
}

struct MedicineResponse: Codable {
    var success: Bool?
    var status: Int?
    var message: String?
    var medicineId: Int?
}

struct MedicineProfile: Codable {
    var activityId: Int?
    var userId: Int?
    var profileId: Int?
    var medicineId: Int?
    var medicineAdministrationDate: String?
    var isDeleted: Int?
    var medCategory: String?
    var medAdminType: String?
    var medBrand: String?
    var medAdminFrequency: Int?
    var medName: String?
}

struct MedicineProfileList: Codable {
    var status: Int?
    var success: Bool?
    var message: String?
    var data: [MedicineProfile]?
}

struct MedicineAdministration: Codable {
    var status: Int?
    var success: Bool?
    var message: String?
    var activityId: Int?
}

struct Frequency: Codable {
    var frequencyDays: Int?
    var frequencyDaysValue: String?
    var isDeleted: Bool?
}

struct FrequencyList: Codable {
   var status: Int?
    var success: Bool?
    var message: String?
    var data: [Frequency]?
}
