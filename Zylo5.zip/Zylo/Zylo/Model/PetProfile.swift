//
//  PetProfile.swift
//  Zylo
//
//  Created by Sathish on 25/03/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

struct PetProfile: Codable {
    var profileId: Int?
    var userId: Int?
    var profilePetType: String?
    var profilePetName: String?
    var profilePetBreed: String?
    var profilePetColor: String?
    var profileMicrochipId: String?
    var profileSex: String?
    var profilePetAdoptedInd: Bool?
    var isDefault: Bool?
    var vetId: Int?
    var isDeleted: Bool?
}

struct PetProfileData: Codable {
    var success: Bool?
    var status: Int?
    var message: String?
    var data: [PetProfile]?
}

struct PetDetailData: Codable {
    var success: Bool?
    var status: Int?
    var message: String?
    var data: PetDetail?
}

struct PetDetail: Codable {
    var summaryData: PetProfile?
    var dynamicData: dynamicData?
    var trainerData: trainerData?
    var petParent: petParentData?
    var vetData: vetData?
}

struct dynamicData: Codable {
    var profilePetDob: String?
    var profilePetAge: Int?
    var profilePetWeight: Int?
    var profilePetEmergencyContactNo: String?
    var profilePetAllergies: String?
    var profilePetFoodType: String?
    var profilePetFoodBrand: String?
    var profilePetAddressCity: String?
    var profilePetAddressState: String?
    var profileAddressCountry: String?
    var isVaccinated: Bool?
    var profilePetNotes: String?
    var profilePetInsuranceInd: Bool?
    var profilePetInsuranceCompany: String?
    var profilePetInsurancePolicyNo: String?
    var profilePetInsuranceCompanyContactInfo: String?
    var isDeleted: Bool?
}

struct trainerData: Codable {
    var trainerId: Int?
    var userId: Int?
    var profileId: Int?
    var trainerName: String?
    var trainerPhoneNumber: String?
    var trainerAddress: String?
    var isDeleted: Bool?
}

struct petParentData: Codable {
    var parentId: Int?
    var userId: Int?
    var profileId: Int?
    var parentName: String?
    var parentPhoneNumber: String?
    var parentStreetAddress: String?
    var isDeleted: Bool?
    var parentCity: String?
    var parentState: String?
    var parentZipcode: String?
    var parentCountry: String?
    var parentEmail: String?
}

struct vetData: Codable {
    var vetId: Int?
    var vetName: String?
    var vetHospital: String?
    var vetPhoneNumber: String?
    var vetHospitalAddress: String?
    var vetCity: String?
    var vetState: String?
    var vetCountry: String?
    var vetZipcode: String?
    var vetEmailAddress: String?
    var vetPocName: String?
    var vetPocContactNumber: String?
    var createdByUser: Bool?
    var userId: Int?
    var isDeleted: Bool?
}

struct CreatePet: Codable {
    var success: Bool?
    var status: Int?
    var message: String?
    var profileId: Int?
}

struct UpdatePet: Codable {
    var success: Bool?
    var status: Int?
    var message: String?
}

struct VetListData: Codable {
    var success: Bool?
    var status: Int?
    var message: String?
    var data: [vetData]?
}
