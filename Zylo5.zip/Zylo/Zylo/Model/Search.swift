//
//  Search.swift
//  Zylo
//
//  Created by Sathish on 17/03/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit

struct Search {
    let id: Int
    let name: String
    let address: String
    let city: String
    let state: String
    let zipcode: String
    let country: String
    let phoneNumber: String
    let ContactName: String
}
