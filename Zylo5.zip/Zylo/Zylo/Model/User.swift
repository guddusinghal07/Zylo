//
//  User.swift
//  Zylo
//
//  Created by Sathish on 22/03/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import Foundation

struct User: Codable {
    var userId: Int?
    var userEmail: String?
    var userFirstName: String?
    var userLastName: String?
    var userProfileName: String?
    var userDob: String?
    var userPhoneNumber: String?
    var userAddress: String?
    var userCity: String?
    var userState: String?
    var userCountry: String?
    var userZipcode: String?
    var isDeleted: Bool?
}

struct UserData: Codable {
    var success: Bool?
    var status: Int?
    var message: String?
    var data: User?
}

struct SaveUser: Codable {
    var success: Bool?
    var status: Int?
    var message: String?
    var userId: Int?
}
