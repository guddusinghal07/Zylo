//
//  AppDelegate.swift
//  Zylo
//
//  Created by Sathish on 09/02/20.
//  Copyright © 2020 Sathish. All rights reserved.
//

import UIKit
import Firebase
import IQKeyboardManagerSwift
import GoogleSignIn
import UserNotifications
import DropDown

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
   
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        UIBarButtonItem.appearance().setTitleTextAttributes([NSAttributedString.Key.font: UIFont.openSansBoldFontOfSize(size: 16.0) as Any], for: .normal)
        
        self.window = UIWindow(frame: UIScreen.main.bounds)
        
        IQKeyboardManager.shared.enable = true
        
        // Use Firebase library to configure APIs
        FirebaseApp.configure()
        
        GIDSignIn.sharedInstance().clientID = FirebaseApp.app()?.options.clientID
        GIDSignIn.sharedInstance().restorePreviousSignIn()
        
        OpenSans.registerFonts()
        DropDown.startListeningToKeyboard()
        
        if #available(iOS 13.0, *) {
            // In iOS 13 setup is done in SceneDelegate
        } else {
            let window = UIWindow(frame: UIScreen.main.bounds)
            self.window = window
            if(GIDSignIn.sharedInstance().hasPreviousSignIn()){
                let vc = Constants().storyBoard.instantiateViewController(withIdentifier: "Home") as! HomeViewController
                vc.modalPresentationStyle = .fullScreen
                self.window!.rootViewController = vc
            } else {
                let vc : SignUpViewController = Constants().storyBoard.instantiateViewController(withIdentifier: "SignUp") as! SignUpViewController
                vc.modalPresentationStyle = .fullScreen
                self.window!.rootViewController = vc
            }
        }
        self.window?.makeKeyAndVisible()
        
        return true
    }
    
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        return GIDSignIn.sharedInstance().handle(url)
    }
}
